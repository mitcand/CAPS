---
tags: [todo, obsidian, template]
status: parked
---

# Admonition layout — findings & TODO

Status: **APPLIED to `New Product Template.md`** (2026-07-06) — full conversion done:
Missions/Targets → `ad-note`, Work block → `ad-subtasks`/`ad-phase`, prose sections
(Notes/Sourcing/Coordination/Feedback/Journal) → `ad-note`. Controls left as a plain
`## Controls` header. Test note: [[Admonition Interaction Test]].

## Bases refactor (2026-07-06)
- ✅ Inline `\`\`\`base` inside `ad-note` **confirmed rendering** in a test product.
- ✅ Moved Missions/Targets view logic into reusable files
  `_Views/Product — Missions.base` and `_Views/Product — Targets.base`; the
  template now **embeds** them (`![[Product — Missions.base]]`). `this` resolves to
  the embedding product note, so per-product filters still work. Edit the .base
  once → propagates to all products.
- ✅ Added view-only toolbar-hiding CSS (`.product .bases-toolbar{display:none}`)
  in `production.css`.

## Embed layout — ✅ RESOLVED (DOM-confirmed via Inspect)
- Embedded `.base` inside `ad-note` renders AND stays filtered to the product. ✅
- Two CSS issues fixed in `production.css`, scoped to `.product`:
  - **Width / horizontal scroll:** the embed is an inline `span.internal-embed
    .bases-embed`, and its wrapper `.el-pre.admonition-parent` sizes to
    fit-content (shrinks + centers a wide table). Fix: force
    `.el-pre.admonition-parent` full-width + left, and make the embed `display:
    block; width:100%`.
  - **Empty gap:** the toolbar's parent `.bases-header` kept its 40px height.
    Fix: `.product .bases-header { display: none }` (removes toolbar + gap).

## Verify — ✅ DONE
- [x] Full-width, no toolbar, no gap, tables hug their rows (collapsed the
  embedded `.bases-view` reserved height with `min-height:0; height:auto`).

## Controls — ✅ boxed in `ad-note` (color 40,93,171).

## Brand colours (org palette) — applied per-block in the template
Set via each block's Admonition `color:` line, so colours **deploy with the
template** (no per-machine re-set). Also removed the `--callout-color` overrides
from `production.css` (that resolves the old two-source issue — CSS no longer
fights the per-block colours; `admonition-types.json` defaults updated to match).

Mapping:
- Deep blue **285DAB** (40,93,171) → Work container, Controls.
- Light blue **5EA5DA** (94,165,218) → Missions, Targets, and all prose sections.
- Warm ramp on the phases: **F1DCAA** (241,220,170) Preproduction →
  **F9A63F** (249,166,63) Production → **CD5821** (205,88,33) Postproduction.

- [x] **Per-block `color:` renders** — confirmed; all boxes match the mapping.
- [ ] Optional, NOT done: global accent is still gold (`#ccb72e` in
  appearance.json) — vault-wide, so left alone. Change to a brand colour (e.g.
  285DAB or 5EA5DA) if you want links/active states on-brand everywhere.

## Meta Bind buttons — brand colours
Each button definition tagged with a custom `class:` (`mb-brand-primary` on Mark
Published, `mb-brand-danger` on Reset time, `mb-brand-step` on the six ±10s); CSS
in `production.css` colours them: Publish → 285DAB, Reset → CD5821, steppers →
5EA5DA outline. Forgiving selectors (`.mb-brand-x button, button.mb-brand-x`).
- [x] Buttons confirmed — custom class reaches the inline instances; all three
  brand styles apply (Publish 285DAB, Reset CD5821, steppers 5EA5DA outline).
- [ ] **Controls** left as a bare header among boxed sections — box it in `ad-note`
  for consistency, or leave as-is? (Judgment call; easily changed.)
- [ ] **Deploy to PWS:** import `admonition-types.json` AND re-set each type's color
  in the Edit dialog (import alone doesn't apply the color).
- [ ] Reconcile the two color sources (`production.css` vs Admonition UI) — see below.

## Why we looked at this

Goal: better-organized project template page layout — divide space vertically
(sections) and horizontally (columns) — with **clean fenced syntax** (`\`\`\`ad-`)
instead of the `>`/`>>` blockquote-callout syntax, and **without hand-writing CSS**
(CSS is a pain point). Admonition (`ebullient/obsidian-admonition`, v12.0.5,
maintained) was the candidate.

## What the test PROVED (all confirmed in-app)

- **Admonition renders all our interactive content** inside an `ad-note` block:
  - Meta Bind **block** fields (`INPUT[textArea:…]`) ✅
  - Meta Bind **inline** fields (`VIEW[…]`, `BUTTON[…]`) ✅
  - `js-engine` blocks (incl. reactive counters) ✅
  - Checkboxes ✅
- Nesting works (`ad-note` inside `ad-note`) with **escalating backticks**:
  outer Work box = **5** backticks, each phase box = **4**, inner
  `js-engine`/`meta-bind` = **3**.
- The Work/tasks block was fully rebuilt in Admonition (TEST C) and **works** —
  overall readout, per-phase counts, time views, ±10 buttons all functional.

## The BLOCKER — no columns

- The three phases **stack vertically** in Admonition; they do **not** form
  columns.
- Reason: `production.css` lays out columns by targeting **native callout**
  markup — `.product .callout[data-callout="subtasks"] > .callout-content`
  (grid) and `.callout[data-callout="phase"]`. Admonition renders **different
  markup**, so those selectors don't match.
- Net: to get columns back with Admonition we'd have to write **new CSS** — the
  opposite of the "avoid CSS" goal. Native callouts give the columns **for free**
  from a rule that's already written and working.

## Decision so far

- **Prose sections** (Notes / Sourcing / Coordination / Feedback / Journal):
  `ad-note` is a clean boxed win, needs no columns → good candidate to convert.
- **Work/phase block**: **stays on native callouts** — it already has columns +
  per-phase styling with zero extra CSS. Converting loses columns.

## TODO for "later" — the custom `ad-` types work

If we want the Work block (or other multi-column areas) in Admonition anyway:

1. **Create/register custom admonition types** — ✅ **DONE (generated, pending
   import).** `admonition-types.json` at the vault root defines `subtasks`
   (title "Work", icon `fas list-check`) and `phase` (icon `fas layer-group`),
   both color `130, 130, 210` to match the CSS. Import via Settings → Admonition
   → Import. Verify the icons render; adjust in-UI if the `fas` names don't match.
2. **DOM question — ✅ ANSWERED: Admonition emits native-callout markup.** After
   importing the types, the three phases rendered **in columns**, which means
   Admonition produces `.callout[data-callout="subtasks"/"phase"]` and the
   **existing `production.css` grid matched for free** — the best case. No
   selector rewrite needed.
   - **Background gap — real cause found:** the missing tint wasn't a CSS problem.
     **Colors from a JSON import don't apply until each type is re-saved in the
     "Edit Admonition" dialog.** After re-setting the color there, Admonition
     applies the body tint itself. (The CSS band-aid I briefly added was reverted
     — not needed.)
   - **⚠️ Deployment note:** importing `admonition-types.json` on the PWS won't be
     enough — after import, open each type (`subtasks`, `phase`) in Edit
     Admonition and re-set/confirm the **color** so it takes.
   - **⚠️ Two sources of color to reconcile:** `production.css` sets
     `--callout-color: 130,130,210` on these types, AND Admonition's UI now stores
     its own color (set to ~131,180,210 during testing). Pick ONE owner to avoid
     drift — simplest is to let the Admonition UI own the color for these types
     and later drop the `--callout-color` lines from `production.css`.
3. **Rewrite `production.css` column selectors** to target that markup instead of
   `.callout[data-callout="phase"]`. This is the real work and it *is* CSS.
4. **Rewrite the js-engine phase counters** to key off Admonition's `title:`
   lines instead of `[!phase]` — already prototyped in TEST C (the original
   counters look for `[!phase]` and would read 0/0 in Admonition).
5. **Live with backtick escalation** (5/4/3) in the Work block, or keep that one
   block native and use `ad-` only for flat sections.
6. **Convert prose sections** to `ad-note` in `New Product Template.md` (4
   backticks each, since each contains a Meta Bind block).
7. **Decide** whether to box Missions / Targets (Bases tables) too, or leave them
   plain.

## Open questions

- Is the columns benefit worth writing/maintaining CSS against Admonition's
  markup, when native callouts already do it free? (Leaning: no — keep Work
  native, use `ad-` only for prose.)
- Air-gap: Admonition would need manual sideloading onto the PWS (plugin folder
  copy), vs. native callouts needing nothing.

## Cleanup

- Delete [[Admonition Interaction Test]] once this is settled (kept for now as
  reference for the DOM inspection in step 2).
