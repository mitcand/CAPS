# Video Production Process Planning

Status: **DRAFT / surface-level** — working document for the video production unit.

## Environment

- **Network:** Air-gapped.
- **Production Workstations (PWS):**
  - PWS-1, PWS-2 — DaVinci Resolve Studio, FFmpeg, Obsidian
  - PWS-3 — **DaVinci Resolve Project Server 21** (project database host)
- **Storage:**
  - PWS local drives: `C:` 1 TB (OS), `D:` 1 TB, `E:` 2 TB
  - NetApp SAN — large capacity, **slow**; long-term storage only
- **Goal:** Edit off fast local PWS drives; migrate finished projects to the SAN for long-term storage. Keep the Obsidian project notes in the vault permanently.

---

## Key concept that reshapes the plan: Project Server ≠ project files

DaVinci **Project Server** stores projects in a **PostgreSQL database** on PWS-3, *not* as `.drp` files you double-click. This changes two of your questions:

- You **cannot** "double-click a `.drp` on the network to create a project on the server." Loose `.drp` files only apply to Resolve's local **disk database**. On a networked Project Server you open Resolve → connect to the PWS-3 database → work inside the Project Library.
- Therefore the **project lives in the database (PWS-3)**; the **media lives on disk** (PWS `E:` while editing, SAN when archived). The Obsidian vault folder holds media + notes, never the live project.

Mental model — keep these three things separate:
1. **Project** (timeline, edits, metadata) → Project Server DB on PWS-3
2. **Media** (source video, proxies, renders, cache) → PWS `E:` now, SAN later
3. **Notes** (the Obsidian markdown) → Obsidian vault, stays put

---

## Open question 1: Best way to do a DaVinci project template?

**Recommended: template project *inside the Project Server database*, then Duplicate.**

1. In Resolve connected to the PWS-3 server, create a project named `_TEMPLATE`.
2. Configure it once: project settings (timeline res/fps, color science, cache location, optimized-media location pointing to a local drive), bins/folder structure, standard timelines, render presets.
3. For each new job: right-click `_TEMPLATE` in the Project Library → **Duplicate** → rename to the job. Everything carries over, no re-setup.
4. Optionally keep a Project Server **folder** per job/client in the Project Library to stay organized.

Alternative (export a master `.drp`, import + rename each time) works but is more clicks and easier to get wrong than Duplicate. Use `.drp` export only as an off-server backup of the template.

> Note: Resolve project *presets* (Save As Preset in Project Settings) cover settings but **not** bin structure. The Duplicate-a-template approach captures both.

---

## Open question 2: Should media live inside the Obsidian vault?

**Caution — this is the riskiest part of the plan.** Obsidian watches the entire vault folder tree and builds an index/cache. Dropping GB-to-TB of video, proxies, and renders inside the vault can make Obsidian slow to load, bloat `.obsidian` cache, and churn the file watcher.

The *reason* to put media in the vault was "keep everything in one place / one automatic action." **That reason goes away** once Templater builds the external media folder for you (see Automation section) — so we get the automation *and* keep the vault lean.

**Option A (recommended): keep media *beside* the vault, created automatically.**
```
E:\Projects\0042-ProjectName\          <- media root (Resolve points here); Templater mkdir's this
  ├─ 01_Source\
  ├─ 02_S-Roll\        (FFmpeg-encoded clips land here)
  ├─ 03_Proxies\
  ├─ 04_Renders\
  └─ 05_Exports\
<vault>\Projects\0042-ProjectName.md   <- Obsidian note; frontmatter stores the media path above
```
Same auto-number drives both names, so note ↔ media folder always match. Obsidian stays lean; media moves to SAN independently; the note stays forever.

**Option B: media inside the vault, but excluded.**
Put media under the vault and add those subfolders to Obsidian **Settings → Files & Links → Excluded files**. Reduces *link/search* noise but Obsidian still watches the files on disk — risky at TB scale. Now that automation removes the "one place" motivation, this option is no longer worth its downside. Lower confidence than A.

Decision: **Option A** (automation makes it the clear winner).

---

## Automation: Templater creating the external media tree

Templater's *built-in* file helpers are vault-scoped, **but** a `<%* %>` execution block runs in Obsidian's Node/Electron context on desktop and can call `fs` directly — so it can create folders anywhere the Windows user can write (e.g. `E:\Projects\…`). Add a block like this to your existing project template, reusing the number/name you already compute:

```js
<%*
const fs = require('fs');
const path = require('path');

// --- reuse whatever your template already computes ---
const projNum  = "0042";                                   // your auto-number
const projName = await tp.system.prompt("Project name");   // or your existing var
const folderName = `${projNum}-${projName}`;

// --- external media root (same E: path on PWS-1 and PWS-2) ---
const mediaRoot  = "E:\\Projects";
const subfolders = ["01_Source", "02_S-Roll", "03_Proxies", "04_Renders", "05_Exports"];

const projectPath = path.join(mediaRoot, folderName);
for (const sub of subfolders) {
  fs.mkdirSync(path.join(projectPath, sub), { recursive: true });
}

// record the path in the note so it's clickable/copyable later
tR += `\nMedia folder: \`${projectPath}\`\n`;
%>
```

Notes / caveats:
- Runs only on the workstation where the script fires (where `E:` is local) — correct here, since editing happens on the PWS.
- `recursive: true` makes it idempotent (safe to re-run; won't error if it exists).
- When you migrate to SAN later, just rewrite that `Media folder:` path in the note to the SAN location — one line to update.
- If the vault itself lives on the SAN and is shared between PWS-1/2, the script still writes to whichever machine's local `E:` — which is what you want.

---

## Open question 3: Archiving to SAN — will Resolve's archive work with the vault?

> **DECISION:** Default archive method is **Path 1 — Project Archive (`.dra`)** for all finished projects. It's self-contained, restores cleanly to the PWS-3 DB, and preserves the **full** Media Pool (whole source clips, including footage never cut to a timeline — archive copies media referenced by the project, it does *not* trim clips to used ranges). Since all source is always imported, everything is captured. Use Path 2 only for the rare project you want browsable on disk without opening Resolve.
>
> Caveats when exporting a `.dra`:
> - **Exclude the regenerables** (Render Cache / Optimized Media / Proxy Media) at export to keep archives lean — they rebuild on demand. Keep source + project + gallery/PowerGrade stills.
> - **Confirm custom LUTs are bundled** (classic archive gap) — or archive the LUT folder to the SAN once alongside projects.
> - **Do one restore drill** to a scratch project before trusting the workflow, and verify a `.dra` restores *before* deleting the local working copy on `E:`.
> - Only way you'd lose unused source: never importing it (N/A here — all source is imported) or deliberately running Media Management → Consolidate/Trim (don't, for anything revisitable).

**Resolve doesn't care about Obsidian.** `.dra` archive and media relinking operate on plain folders on disk; the vault is invisible to them. Two ways to migrate a finished project to the SAN:

**Path 1 — Project Archive (`.dra`), self-contained (recommended for true long-term storage):**
- Project Library → right-click project → **Export Project Archive** → write the `.dra` to the SAN.
- The `.dra` bundles the project + all media into one portable folder. Fully self-contained, ideal for cold storage.
- To resume later: **Restore Project Archive** back to the server DB, relink to media. Confirmed to move in/out cleanly because it's self-contained.
- Trade-off: it *copies* media into the archive (duplication until you delete the working copy).

**Path 2 — Manual move + relink (keeps your folder structure):**
- Export the project as `.drp` to the SAN (backup), then **move the media folder** from `E:` to the SAN.
- Keep the project in the server DB (or archive it). When reopened, Resolve shows offline media → **relink** to the new SAN path once.
- Keeps your `01_Source / 02_S-Roll / …` structure intact rather than repackaging it.

**Either way:** move only the heavy media (source, proxies, renders, cache). **Leave the Obsidian `.md` note in the vault** and update the path link inside it to point at the SAN. This satisfies "keep the note, move the big files."

Recommendation: use **Path 1 (`.dra`)** for projects you're truly done with and may never touch again; use **Path 2** for projects you might revisit and want to keep browsable.

---

## Draft end-to-end process (v0.1)

1. **New project note** in Obsidian → creates note + (Option A) a parallel media folder tree on `E:`.
2. **Duplicate `_TEMPLATE`** in Project Server → rename to job.
3. **FFmpeg encode** source → output into `02_S-Roll\` → import into the Resolve project.
4. **Edit / grade / finish** → export to `05_Exports\`.
5. **Archive to SAN:** Export Project Archive (`.dra`, regenerables excluded) → SAN. Verify it restores → delete the local working copy on `E:`. Update the path link in the Obsidian note. Recover later via Restore Project Archive.

---

## Check-In / Check-Out Tool — Plan

> **DECISION (dropped):** Not being built. Handoffs between PWS-1/PWS-2 are rare, so the exclusive-lease tooling isn't worth the build/test cost or the single-copy risk. Media exchange with the SAN is handled by DaVinci's built-in Project Archive (see Open question 3). The plan below is retained for reference only; if the team ever needs frequent simultaneous handoffs, revisit the scripts-downscope in "Alternative considered" before the full GUI.

A small PowerShell + WinForms GUI on each PWS that governs where a project's **media** lives. The SAN is the exchange hub; a project's media exists in exactly one authoritative place at a time.

### Model
- **Exclusive lease, single copy** (matches "move to/from SAN"): media is either **parked on the SAN** or **checked out to one PWS**, never both.
- Check-out = move SAN → local `E:\Projects\<name>`. Check-in = move local → SAN.
- **Enabler:** every PWS uses the identical local root `E:\Projects\` → media always lands at the path Resolve already stored → **no relinking**.
- The tool moves **media only**. The Resolve project stays in the PWS-3 database (always reachable).
- ⚠️ **Risk:** while checked out, the only copy sits on a single non-redundant local drive. Mitigate by (a) backing up the DB project to SAN on check-in, (b) checking in promptly, (c) a future "sync copy" mode (Model 2) that keeps a SAN copy. Active projects live dangerously *by design* — that's why you check in.

### State model (lives on the SAN, not in the tool)
One JSON file per project in `<SAN>\...\_state\`, plus an append-only `_audit.log`:
```json
{ "project": "0042-Name", "status": "available|checked-out|in-transit|unregistered",
  "location": "SAN|PWS01|PWS02", "lockedBy": "user", "machine": "PWS01", "since": "2026-07-06T14:03:00" }
```
Rules enforced by the GUI:
- Check out only if `status == available`.
- Check in only if `location == this machine` (else must be done on the holding machine, or Force-Released).
- An **atomic transit lock** (`<project>.lock`, created with exclusive `CreateNew`) guards against two workstations transferring the same project at once.

### Core flows
- **Check-out:** validate available → take transit lock → set `in-transit` → robocopy SAN→local → verify dest exists + exit code < 8 → delete SAN copy → set `checked-out@PWSxx` → release lock → audit.
- **Check-in:** mirror of the above, local→SAN → set `available@SAN`.
- **Copy-verify-delete ordering** means an interrupted transfer never loses data: source survives and the lock/state flag the incomplete move for recovery.

### Failure handling
- **Stale lock / forgotten check-in:** admin-only **Force Release** clears the lock state (does *not* move media — operator must confirm actual media location). Logged loudly.
- **Interrupted transfer:** source retained; re-run repairs via robocopy `/MIR`.
- **Handoff cost:** a PWS→PWS move is two slow SAN transfers. Future option: direct PWS-to-PWS over SMB to halve it.

### Tech / deployment
- **Windows PowerShell 5.1 + WinForms** — built into Windows, zero external modules (air-gap friendly). **robocopy** as the transfer engine (`/MIR /MT /R /W /LOG`).
- Deploy the same folder to each PWS; edit `CheckInOut.config.psd1` per site (paths, admins). Launch via the `.cmd` (runs with `-STA -ExecutionPolicy Bypass`).

### Roadmap beyond scaffold
- [ ] Background/async transfer with a live progress bar (scaffold blocks the UI during robocopy).
- [ ] Optional hash verification before delete.
- [ ] DB project backup on check-in.
- [ ] Model 2 "sync copy" mode (keep SAN copy as backup while checked out).
- [ ] Direct PWS-to-PWS handoff.

See `checkin-checkout-tool/` for the scaffold.

### Alternative considered: share D/E drives over the network (undecided)

Instead of moving media through the SAN, just SMB-share each PWS's `D:`/`E:` so any PWS can reach any project directly. Simpler on the surface, but it discards the parts of the model that make this setup work:

- **Breaks the zero-relink invariant.** Resolve stores *absolute* media paths in the PWS-3 DB. No-relink depends on media always sitting at the literal `E:\Projects\<job>` on whichever machine opens it. Over a share the path becomes `\\PWS-1\E\Projects\...` (or a mapped letter) ≠ `E:\Projects\...` → relink on every handoff. Worse, `E:\Projects\0042` on PWS-2 could resolve to a *different* local project with the same number — a real collision footgun.
- **Editing over SMB, off a busy disk.** The whole premise is "SAN slow → edit off fast local drives." Reading source/proxies over the LAN from PWS-1's `E:` *while PWS-1 also edits off it* reintroduces the contention we're avoiding (stutter, dropped frames). Might survive on 10GbE with proxies; it's a gamble local-first was built to skip.
- **Availability coupling.** PWS-1 powered off / reimaged / locked up → its projects are unreachable to everyone. SAN-as-hub decouples data from machine uptime.
- **No single source of truth.** Loses the exclusive lease + audit trail; media scatters across PWS-1 / PWS-2 / SAN with no authoritative location, and two editors can open or delete the same media.
- **Doesn't solve archiving.** The SAN is still the long-term store, so the move-to-SAN step remains — sharing removes the governance around moving media without removing the move.

**Narrow safe use:** a share as an occasional **direct PWS-to-PWS transfer shortcut** (the roadmap's "Direct PWS-to-PWS over SMB" item) — not as the place you edit from.

**Middle-ground downscope (if the full tool feels like overkill):** keep the model (SAN hub, one copy, identical `E:\Projects` = no relink) but replace the WinForms GUI + JSON state machine with two dead-simple scripts — `checkout.cmd` (`robocopy \\SAN\...\<job> E:\Projects\<job> /MOVE /MT /R:2 /W:5 /LOG+`), `checkin.cmd` (mirror + append one line to a shared `who-has-what.txt` on the SAN). Preserves no-relink and the SAN hub, gives a crude audit trail, ~20 lines you can actually test — versus the untested scaffold with the blocking UI and single-copy risk already flagged above.

> **TODO / come back to this:** Two next steps on the tool are parked, not done:
> 1. **Async transfer + live progress bar** — the scaffold's UI blocks (shows "not responding") during a robocopy move. Move the transfer to a background runspace and surface progress.
> 2. **DB project backup on check-in** — covers the single-copy risk (only copy sits on one local drive while checked out).
>
> Also still untested: the scaffold has not been run on Windows yet — validate against a scratch SAN folder + dummy projects before trusting it with real media.

---

## Decisions still open
- [x] Media location: **Option A** (beside vault, Templater-created) — decided.
- [x] Media exchange: **no tool** — handoffs are rare; SAN exchange handled by `.dra` archive/restore. (Network drive shares rejected; scripts-downscope parked for if handoffs ever become frequent.)
- [x] Archive strategy default: **Path 1 — `.dra` Project Archive** (self-contained, no relink). Path 2 (manual move + relink) reserved for projects wanted browsable on disk.
- [ ] Drive roles: `E:` (2 TB) = active media; `D:` (1 TB) = cache/proxies/optimized media? (keeps read/write off the media drive)
- [ ] Who hosts the Project Server DB backups, and where (SAN)?
- [ ] Does the Obsidian "new project" step get automated (template plugin / script), or done by hand?
