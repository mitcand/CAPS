---
type: planning-doc
status: draft
created: 2026-06-18
updated: 2026-06-18
tags:
  - meta/planning
---

# Production Project Management — Redmine Deployment Plan

> [!note] Status
> **Draft plan for discussion — build in progress.** This is the third revision of the tool
> choice (Obsidian → YouTrack → Redmine). See Context for the decision trail.

## Context

Need: a project-management system for an intelligence production shop (primarily FMV/video from
airborne collection, plus graphics, maps, reports) on an **air-gapped Windows/Linux production
workstation**, used by one operator at a time but requiring **continuity across shifts**. Must
track **metrics** (volume/throughput, turnaround/cycle time, status/backlog, by requester/
collection) and hold **software how-to docs** (DaVinci Resolve Studio, FFMPEG, R/RStudio, expandable).

**Decision trail (why Redmine):**
1. **Obsidian (rejected)** — would've been the 3rd attempt; a hand-built notes-app tracker is
   high-maintenance for the operator and the prior two attempts didn't stick.
2. **YouTrack (rejected)** — purpose-built and Docker-friendly, but the free license requires a
   **JetBrains account**, which this environment cannot use. No account = no activation = dead end.
3. **Redmine (chosen)** — open-source (GPL), **no license, no account, no activation, no phone-home**.
   Runs in Docker, mature/stable ("install once, runs for years"), strong free custom fields, a
   built-in wiki for the KB, and grouped queries that cover most metrics. Considered OpenProject CE
   (paywalls drag-to-change-status boards, workflow automation, and per-type form config) and Plane
   (modern but youngest/heaviest to keep alive air-gapped). Redmine best fits a low-maintenance,
   accredited, offline box with zero vendor entanglement.

Trade we accept: **no native kanban** (use saved filtered views, or add a free agile plugin) and a
**dated UI**, in exchange for zero licensing friction and maximum longevity.

---

## 1. Deployment (Docker, air-gapped)

Two containers via `docker compose`: **Redmine** (app) + **PostgreSQL** (data). Persistent volumes
for the DB and Redmine's uploaded files. Bind to localhost.

**Air-gapped image transfer** (do this for both `redmine` and `postgres`, pinned versions):
```bash
# on an internet-connected machine
docker pull redmine:6        # pin a specific tag in practice, e.g. redmine:6.0.x
docker pull postgres:16
docker save redmine:6 postgres:16 -o redmine-stack.tar
# move redmine-stack.tar over the one-way path, then on the workstation:
docker load -i redmine-stack.tar
```

**docker-compose.yml** (illustrative):
```yaml
services:
  db:
    image: postgres:16
    restart: unless-stopped
    environment:
      POSTGRES_DB: redmine
      POSTGRES_USER: redmine
      POSTGRES_PASSWORD: <strong-password>
    volumes:
      - ./redmine/db:/var/lib/postgresql/data

  redmine:
    image: redmine:6
    restart: unless-stopped
    depends_on: [db]
    ports:
      - "127.0.0.1:3000:3000"      # localhost only
    environment:
      REDMINE_DB_POSTGRES: db
      REDMINE_DB_DATABASE: redmine
      REDMINE_DB_USERNAME: redmine
      REDMINE_DB_PASSWORD: <strong-password>
      REDMINE_SECRET_KEY_BASE: <random-64-char-hex>
    volumes:
      - ./redmine/files:/usr/src/redmine/files    # attachments
      - ./redmine/plugins:/usr/src/redmine/plugins # optional, only if using plugins
```

- **First run:** Redmine auto-creates the schema. Log in as **admin / admin** and **change the
  password immediately**; create your operator account(s).
- **Access:** over the SSH tunnel (`ssh -L 3000:localhost:3000 user@host`) → `http://localhost:3000`.
- **Pin versions** (no `latest`) so upgrades are deliberate.
- *Simpler alternative:* Redmine can run single-container on **SQLite** (drop the `db` service) —
  fewer moving parts, fine for this low-concurrency scale, but Postgres is the safer long-term store
  with clean `pg_dump` backups. **Recommendation: Postgres.**

---

## 2. Project & issue model

- One **project: Production**.
- One **tracker**: **Product** — the deliverable *is* the task/job. There is no separate "Tasking"
  tracker.
  - Each incoming request produces exactly **one** Product issue; every Product is standalone (no
    parent/child, no subtasks). Sub-components are part of that single deliverable, not separately
    tracked — there is only one deliverable per task; the map is part of the video.
- Product type is a **custom field**, not a tracker (one workflow to maintain; "by type" metric =
  group by that field).
- **Product ID** is auto-generated as `<program:1char><type:2char><year:2digit><seq:3digit>` —
  e.g. `AVD26001` (program A, video = VD, year 2026, sequence 001). The sequence is **global** across
  all programs and product types and **resets each calendar year**. It's derived by scanning existing
  records for the highest sequence in the current year and adding 1 — no stored counter, so there are
  no duplicates and it survives deletions.

---

## 3. Workflow (statuses)

Create global statuses, then define the **workflow** (allowed transitions) for the Product tracker:

`Inbox → Backlog → Preproduction → Production → Postproduction → Draft → Published → Archived`

- Flag **Published** and **Archived** as **closed** statuses → Redmine stamps a **closed-on** date →
  turnaround = closed_on − created_on.
- Allow back-transitions (e.g. Draft → Production) for **rework** loops.
- **Created date** = "date received." **Blocked** = a boolean custom field (+ "Blocked reason"),
  so a stuck issue keeps its real stage and still appears in a "Blocked" filter.

---

## 4. Custom fields (Product tracker)

Built-in: **Priority**, **Due date** (built-in), **Start date**, **Assignee**, **Status**, **created/closed** dates.
Add issue custom fields:

| Field | Type | Notes |
|---|---|---|
| Product type | list | video / graphic / map / report |
| Requester | list | enables clean "by requester" grouping |
| Collection platform | list | collection source/platform |
| Target | text | target information |
| Collection date | date | Redmine custom dates are date-only; add a "Collection time" text field if time is needed |
| Duration | int/float | runtime, videos |
| Classification | list | marking + caveats (metadata only — §10) |
| Software used | list (multiple) | values mirror KB wiki page names |

---

## 5. Boards & saved queries

Redmine core has **no kanban**. Two paths:
- **Plugin-free (recommended start):** public **saved queries**, grouped by Status, serve as the
  board/work views: *Inbox triage*, *Active (not closed)*, *Overdue* (due date < today, open),
  *Blocked* (Blocked = yes). Put them on **My Page** blocks for a dashboard feel.
- **Optional later:** a free agile-board plugin for drag-kanban. Air-gapped cost: transfer the
  plugin, match the Redmine version, run `rake redmine:plugins:migrate`. Adds upkeep — only if the
  board is worth it.

---

## 6. Metrics

- **Volume / throughput** — saved query: Status = Published, closed within period, **grouped by
  Product type**; the issue count is your throughput. Also project **Reports** (issues by tracker/
  status).
- **Status / backlog** — query/Reports grouped by **Status**.
- **By requester / collection** — query grouped by **Requester** / **Collection platform**.
- **Turnaround / cycle time** — closed_on − created_on. Not a native column; options: a free
  reporting plugin, or a periodic **CSV export** of created/closed dates → compute in your
  R/RStudio workflow (fits this shop). Enable lightweight **time tracking** for effort-hours.

---

## 7. Knowledge base (software how-tos)

A separate **project: Knowledge Base** with its **Wiki** enabled. One top wiki page per tool —
**DaVinci Resolve Studio, FFMPEG, R & RStudio, This-System (operator guide)** — with child pages per
procedure (Redmine wikis support page hierarchy + attachments). The **Software used** field on
products mirrors these page names so you can cross-link issues ↔ how-tos.

---

## 8. Daily logging & shift continuity

Native to Redmine — no manual rollup:
- Operators log progress as issue **notes/comments** (and optionally **spent time**); every entry
  is timestamped + attributed in the issue **journal** = the per-product history.
- **Shift handoff** = the **Activity** feed (project or global), filterable by date range → "what
  moved since last shift." End-of-shift convention: a short note on each in-flight issue.
- Optional: a wiki **Shift Log** page for narrative handoff notes.

---

## 9. Backups, updates, maintenance

- **Back up BOTH:** the database (`pg_dump`) **and** the `files` volume (attachments) — Redmine
  splits data across them. Schedule it, copy off-box to approved storage.
- **Restore drill** once into a throwaway stack before go-live.
- **Updates:** transfer a newer `redmine` image tar → `docker load` → **back up first** → recreate
  the redmine container on the same volumes (it runs DB migrations on start). Pinned versions keep
  this deliberate. Periodic, not daily.

---

## 10. Security / accreditation

- **Big win for accreditation:** open-source, no vendor account, no license server, **no outbound
  connections** needed ever. Source is reviewable.
- Bind to `127.0.0.1` only; reach it via SSH tunnel. Change default `admin/admin` immediately;
  configure roles/permissions for least privilege.
- **Classification** is a metadata field (records the marking, doesn't enforce handling). Put the
  `db` and `files` volumes on storage approved for the highest marking any issue will carry; follow
  local policy for what content may be stored.

---

## 11. Implementation phases

1. **Provision** — transfer + `docker load` the `redmine`/`postgres` images; bring the stack up with
   `docker compose`; first-run login; change admin password; create operator account(s).
2. **Project + tracker** — create the Production project; ensure the Product tracker; enable
   the modules you need (issue tracking, time tracking, wiki off here).
3. **Statuses + workflow** — create the 8 statuses (Published/Archived = closed); define the Product
   workflow incl. rework back-transitions; set up the Blocked field.
4. **Custom fields** — add the §4 fields to the Product tracker; populate list values.
5. **Queries + My Page** — build the public saved queries (§5) and lay them on My Page.
6. **Knowledge Base** — create the KB project, enable its wiki, seed a page per tool + the operator guide.
7. **Backups** — script `pg_dump` + files copy off-box; run a restore drill.
8. **Pilot** — create several Products and run them through the pipeline; confirm auto-generated IDs
   are sequential with no duplicates; confirm metrics queries populate; clean up samples.
9. **Cutover** — finalize the operator guide (intake → work/log → deliver → handoff) and go live.

---

## 12. Verification

- Create several Products in succession → confirm each gets an auto-generated ID that is sequential
  (global across programs/types, resetting per year) with no duplicates.
- Move a Product through statuses → confirm the workflow allows the path + back-transitions for rework.
- Set it to **Published** → confirm a closed-on date is recorded and it drops from the "Active" query.
- Add a **note/spent-time** → confirm it appears in the issue journal and the **Activity** feed.
- Set a past **due date** on another issue → confirm it shows in the "Overdue" query.
- Run the metric queries → confirm volume (by product type), backlog (by status), and by-requester
  groupings populate.
- `pg_dump` + restore into a throwaway stack → confirm data + attachments integrity.

---

## Open / assumed defaults (tell me to change any)

- One Production project; a single Product tracker (the deliverable is the task); product type as a
  custom field.
- **Postgres** over SQLite (durability) — say the word if you'd rather run single-container SQLite.
- **Priority** values assumed `routine / priority / immediate` — swap for your real terms.
- **Blocked** as a field, not a status.
- Start **plugin-free** (saved queries instead of a kanban); add a free agile plugin only if the
  board earns its upkeep.
- Turnaround/throughput via CSV export → R, unless we add a reporting plugin.

---

## Discussion notes
<!-- Jot questions/changes here as you read; we'll work through them next session. -->
