---
type: build-log
status: in-progress
created: 2026-06-18
updated: 2026-06-18
tags:
  - meta/build
---

# Redmine Build Log & Handoff

> [!summary] Where we left off (2026-06-18)
> Redmine is **installed and running** on the eval box and we're logged in. We paused mid–**dark
> mode plugin install**. Goal for the next session: finish **(1) Redmine install hardening, (2) dark
> mode, (3) a kanban plugin** — get all the infrastructure/plugins in place — *then* do the actual
> PM configuration (statuses, trackers, fields, etc.). Design reference: [[PM System Design Plan]].

---

## Current state

**Host (eval/lab box):** `nimcraft` @ `192.168.1.111`. Internet-capable (can `docker pull` and
`git clone`). **NOTE:** this is *not* the final air-gapped production box — we're learning the setup
here, then re-deploying on the locked-down box via `docker save`/`load`.

**Container — running:**
- Image: `redmine:6` (single container, **SQLite** backend — chosen to minimize hand-typing on an
  air-gapped console; Postgres is the production-hardening option per the plan).
- Name: `redmine`, `--restart unless-stopped`.
- Port: `-p 3000:3000` (all interfaces, **plain HTTP** — fine for this eval box; production must go
  back to `127.0.0.1` + SSH tunnel or a TLS reverse proxy).
- Access: **http://192.168.1.111:3000** (couldn't SSH-tunnel, so we exposed the port directly).
- Login: `admin` / *(password was changed during setup — recorded by operator, not here)*.

**Persistent volumes:**
- `redmine_files`  → `/usr/src/redmine/files`   (attachments)
- `redmine_sqlite` → `/usr/src/redmine/sqlite`  (the database)
- `~/redmine/plugins` → `/usr/src/redmine/plugins` (bind mount, for plugins — added for dark mode)

**Standard run command** (use this for any recreate; data persists in the volumes):
```
docker run -d --name redmine --restart unless-stopped -p 3000:3000 \
  -v redmine_files:/usr/src/redmine/files \
  -v redmine_sqlite:/usr/src/redmine/sqlite \
  -v ~/redmine/plugins:/usr/src/redmine/plugins \
  redmine:6
```

---

## ✅ Done

- [x] Pulled `redmine:6`, ran it (first attempt had a line-break typo + a `127.0.0.1` bind that
      blocked LAN access — both resolved).
- [x] Reached the web UI at `http://192.168.1.111:3000`, logged in as admin, changed the password.

## 🔜 Next session — finish infrastructure & plugins first

### 1. Dark mode (`fraoustin/redmine_dark`) — IN PROGRESS, resume here
It's a **plugin** (adds a per-user **"dark mode" toggle, top-right**, not a global theme).
- [ ] Plugin folder present at `~/redmine/plugins/redmine_dark` (git clone or curl tarball — see
      detailed steps below).
- [ ] `chmod -R a+rX ~/redmine/plugins`
- [ ] Recreate the container with the **standard run command** above.
- [ ] Hard-refresh browser, log in, click **"dark mode"** top-right.
- [ ] If toggle shows but isn't styled: `docker exec redmine bash -lc "RAILS_ENV=production bundle exec rake assets:precompile"` then `docker restart redmine`.

### 2. Kanban / agile board plugin — NOT STARTED
Redmine core has no kanban board. Need a free, Redmine-6-compatible one (drag a card → changes the
issue status, mapping to our pipeline).
- [ ] **Pick the plugin.** Leading candidate: **RedmineUP Agile (light/free)** — most popular free
      agile board. *Must verify Redmine 6 compatibility before installing.* Alternatives to weigh:
      other open-source kanban plugins on redmine.org/plugins.
- [ ] Install: drop into `~/redmine/plugins/<plugin>`, then run migrations + restart:
      `docker exec redmine bundle exec rake redmine:plugins:migrate RAILS_ENV=production` →
      `docker restart redmine`.
- [ ] Confirm the board renders and dragging cards changes status.

### 3. Confirm a clean baseline
- [ ] Both plugins load without errors in `docker logs redmine`.
- [ ] Snapshot/back up the current state before starting config (copy the two named volumes +
      `~/redmine/plugins`).

---

## ⏸ Deferred — the actual PM configuration (after plugins are in)
Maps to [[PM System Design Plan]] §3–§9. We'll do these in the web UI:

- [ ] **Statuses (Stage 1):** create 8 — Inbox, Backlog, Preproduction, Production, Postproduction,
      Draft, Published *(closed)*, Archived *(closed)*. Reorder to pipeline order.
- [ ] **Trackers (Stage 2):** create a single **Product** tracker (default status = Inbox) — the
      deliverable *is* the task; each request yields exactly one Product (sub-components like a map
      inside a video live inside that one Product, not as separate issues).
- [ ] **Workflow (Stage 3):** transitions along the pipeline + rework back-transitions; add the
      **Blocked** boolean custom field (+ reason).
- [ ] **Custom fields (Stage 4):** Product type, Requester, Collection platform, Target, Collection
      date, Duration, Classification, Software used (see plan §4 for types).
- [ ] **Project (Stage 5):** create **Production**; enable trackers, modules, custom fields.
- [ ] **Queries + My Page (Stage 6):** saved queries (Inbox, Active, Overdue, Blocked) on My Page.
- [ ] **Knowledge Base (Stage 7):** separate project + wiki; a page per tool (DaVinci Resolve,
      FFMPEG, R/RStudio, operator guide).
- [ ] **Backups (Stage 8):** script copying `redmine_sqlite` + `redmine_files` (+ plugins) off-box;
      run a restore drill.
- [ ] **Pilot (Stage 9):** create several Products and run them through the pipeline; confirm
      auto-generated IDs are sequential with no duplicates (format
      `<program:1char><type:2char><year:2digit><seq:3digit>`, e.g. `AVD26001`; the sequence is
      global across programs/types and resets each calendar year); confirm metric queries populate;
      clean up samples.

---

## Detailed steps to resume dark mode (copy/paste ready)

```
# A. get the plugin onto the box
mkdir -p ~/redmine/plugins
git clone https://github.com/fraoustin/redmine_dark.git ~/redmine/plugins/redmine_dark
#   (no git? ->  curl -L https://github.com/fraoustin/redmine_dark/archive/refs/heads/master.tar.gz -o /tmp/rd.tar.gz
#                tar -xzf /tmp/rd.tar.gz -C ~/redmine/plugins
#                mv ~/redmine/plugins/redmine_dark-master ~/redmine/plugins/redmine_dark )
chmod -R a+rX ~/redmine/plugins
ls ~/redmine/plugins/redmine_dark        # expect: init.rb lib assets README.md

# B. recreate container with the plugins mount (standard run command)
docker rm -f redmine
docker run -d --name redmine --restart unless-stopped -p 3000:3000 -v redmine_files:/usr/src/redmine/files -v redmine_sqlite:/usr/src/redmine/sqlite -v ~/redmine/plugins:/usr/src/redmine/plugins redmine:6

# C. watch boot, then hard-refresh browser + click "dark mode" top-right
docker logs -f redmine
```

---

## Notes / decisions made during build (deviations from plan)
- **SQLite instead of Postgres** for now — simpler to stand up by hand. Plan's Postgres compose is
  the production target; revisit before the real air-gapped deployment.
- **Port exposed on all interfaces over HTTP** on the eval box (no SSH tunnel available). Production
  reverts to localhost-bind + tunnel/TLS.
- **Dark mode requires a plugin** (stock Redmine 6 has no dark theme). If the production box blocks
  the per-user toggle or we want it forced, revisit. Browser-side Dark Reader is the fallback.
- Box can pull images + clone from GitHub directly, so plugin install is easy here; on the real
  air-gapped box, download on an internet machine and transfer the plugin folder into `~/redmine/plugins`.

## Discussion notes
<!-- anything to revisit -->
