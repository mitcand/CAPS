# Focalboard Deployment Log

Running record of installing and configuring Focalboard for a small team (<10 people)
producing short-form video products from airborne intelligence collection platforms.

- **Started:** 2026-06-19
- **Target host:** Ubuntu headless server (accessed via SSH)
- **Operator:** mitcand@pm.me (local machine: macOS, dir `/Users/mitcan/Documents/CAPS`)
- **Prereqs already present on server:** Docker, docker-compose

> Note: Claude cannot reach the server directly. Commands are authored here and run
> by the operator over SSH. This file is the source of truth for what was done and why.

---

## Decisions

| Date | Decision | Rationale |
|------|----------|-----------|
| 2026-06-19 | Deploy Focalboard **standalone Personal Server** via Docker Compose | Simplest fit for a <10 person team; no Mattermost dependency |
| 2026-06-19 | Use prebuilt image `mattermost/focalboard:latest` (v7.11.x, last published Oct 2023) | Avoids building from source on the server; final stable release of standalone |
| 2026-06-19 | Persist data via named volume `fbdata` → `/opt/focalboard/data` | Confirmed correct mount path from upstream compose; survives restarts/upgrades |
| 2026-06-19 | Host port **8000** (not 80) | Avoids needing root-bound port and conflicts; easy to change/proxy later |

### ⚠️ Important caveat
Standalone Focalboard is **EOL / maintenance only** — the Docker image hasn't been
updated since late 2023 and will get **no security patches**. Given the sensitive
mission context, keep it **LAN-only or behind a VPN; never expose directly to the
internet**. Revisit alternatives (e.g. Mattermost Boards, Planka, Wekan, Vikunja)
if active maintenance/TLS/SSO become requirements.

## ⚠️ New hard requirement discovered (2026-06-20): TIME TRACKING per phase

Operator wants to retrospectively see **how much time products spend in each
production phase** to find process improvements. **Focalboard cannot do this** (no
time tracking, not extensible). This likely changes the platform choice.

### Alternatives evaluated (minimal, self-hostable, Docker)
| Tool | Per-phase time? | How | Footprint | Maintained | Notes |
|------|-----------------|-----|-----------|-----------|-------|
| **Kanboard** ⭐ | **Yes, automatic** | "Time spent in each column" chart + lead/cycle time, from task transitions; plus manual task/subtask spent-vs-estimated + start/stop timer | Tiny: single PHP container, SQLite default | Active (MIT) | Best fit. Utilitarian UI. Needs ≥2 days data for graphs. |
| Planka | Partial | Manual per-card stopwatch timer (no per-column rollup) | Needs Postgres | Active | Modern Trello-like UI |
| Wekan | Partial | start/received/due/end dates; limited | Heavy: app + MongoDB, 2 containers | Active but governance churn | Most features, most weight |
| Vikunja | No native time tracking | — | Single binary/container, SQLite | Active | Great app, lacks the core requirement |
| Focalboard | **No** | — | Single container | **EOL** | Currently installed |

**Leaning: pivot to Kanboard.** Also a security plus — actively maintained vs EOL Focalboard.

## 🔮 Future backlog (parked 2026-06-20 — pick up later)

Captured for future sessions. Rough approach notes included so we don't start cold.

1. **Per-product completion report → ObsidianMD** (nice-to-have).
   On project/card close, export a nice-looking **Markdown** report (metadata, timeline,
   per-phase time, per-subtask time spent vs estimated, lessons learned) that drops into an
   Obsidian vault. Likely approaches: (a) small script via Kanboard **API** (`getTask`,
   `getAllSubtasks`, time data) rendering an `.md` file per product; (b) a custom plugin adding
   an "Export report" action. Obsidian just needs `.md` + maybe frontmatter. Decide template/layout.

2. **Customizable classification banner across top of page** (CSS).
   Add a top (and/or bottom) banner with classification text + color, site-wide. Approach:
   custom Kanboard **plugin** using template hooks (`template:layout:head` for CSS, a layout
   hook to inject the banner div). Make text/color configurable (plugin config or settings).
   Standard pattern for classified systems. Ties in with item 5 (air-gapped/classified net).

3. **Add fields: Customer (one or many), Country/Countries, Target(s).**
   These are potentially MULTI-valued, which Kanboard core doesn't do natively (Category = one
   only). Options: **Tags** (quick, flat), or the community **Custom Fields / Metadata** plugin
   for structured multi-value fields. Decide data model before item 4 — reporting depends on it.
   Note interplay: customer was previously mapped to Category; multi-customer breaks that.

4. **Simple reports by customer / target / country / type.**
   "How many products for customer X this year", "which countries/targets", etc. Feasible via
   Kanboard filters + analytics IF item 3 uses tags/categories; richer reports likely need a
   **script via the API** or a reporting plugin. Depends entirely on item 3's data model.

5. **★ BIG ONE: replicate entire stack on an AIR-GAPPED network.**
   Target: Windows workstation, **Docker Desktop** (WSL2 backend), WSL distro **RHEL 9**.
   Air-gapped = NO internet, so everything must be pre-staged and carried in:
   - Pull `kanboard/kanboard:<pinned-version>` on a connected machine, `docker save` to a tar,
     transfer, `docker load` on the air-gapped host. (Pin the version — no `latest` pulls offline.)
   - Carry in: compose file, the `TrackingNumber` plugin folder, any future plugins (banner, etc.),
     this runbook.
   - Windows specifics: Docker Desktop + WSL2 integration enabled for the RHEL 9 distro; bind-mount
     path/line-ending (CRLF!) and file-permission gotchas; `localhost:8000` access from Windows browser.
   - Classification banner (item 2) becomes important here.
   - Consider building a single **offline install bundle** (images tar + compose + plugins + README).

6. **Auto-remove the duplication link (fold into TrackingNumber plugin).**
   When a card is duplicated from the template, Kanboard auto-creates a "this task duplicates →
   TEMPLATE" internal link (and an "is duplicated by" back-link that accumulates on the template
   card). Add cleanup to the existing plugin's "move to Queued" action: on fire, find and remove
   the duplicate-type internal link(s) on the task (TaskLinkModel: getAll → remove by link type
   "duplicates"). Keeps product cards and the template card clean, zero extra clicks. Deploy via
   the proven scp → `docker cp` → restart path. Low-risk, ~one extra method in
   `Action/GenerateTrackingNumber.php`.

## Open questions / TODO

- [ ] Confirm whether access is LAN-only or needs internet exposure (affects TLS/reverse proxy)
- [ ] Decide on backups cadence for the board data
- [ ] Decide on user accounts / who administers

## Board design (Kanboard) — agreed 2026-06-20

**Principle:** phases = columns (auto time-tracked), detailed steps = subtasks (own time tracking + assignee).

**Columns (pipeline):**
1. Inbox — idea/request
2. Approved / Queued — passed threshold to be worked; awaiting capacity (separates wait-to-start from work time)
3. Pre-Production — gather info; build folder structure; pull raw; encode to intermediate→source roll; create DaVinci Resolve project shell
4. Production — cut · stabilize · color · fusion · build · draft
5. Post-Production — render draft/final; review; publish
6. Lessons Learned — capture takeaways before close
7. Done / Archived

**Subtasks per phase** (reusable checklist, each time-tracked):
- Pre-Prod: gather info · build folders · pull raw · encode→intermediate · create Resolve project
- Production: cut · stabilize · color · fusion · build · draft
- Post-Prod: render · review · publish

**Field mapping (native, no plugin):**
- Customer → Category
- Classification, Source platform/sensor → Tags (color-coded)
- Priority → native Priority field
- Lead/analyst → task assignee; Editor(s) → subtask assignee
- Due → native start+due date
- Target/location/source timestamps/context/folder path/Resolve project → description template (markdown)
- Time per phase → automatic from column transitions

**Naming:** Kanboard auto `#ID` guarantees uniqueness; human convention in title (+ optional Reference field).
Auto-generated custom naming = future plugin/automation if wanted.

**Optional later:** Custom Fields plugin (structured fields), Reference field for formal product #, Review as its own column if approvals bounce a lot.

## Tracking-number convention (requirement added 2026-06-20)

Format: **`P TT YY NNN`** e.g. `ASG26001`
- **P** = platform letter (A, B, C, …) — full list TBD
- **TT** = product type code: SG=significant observation, SP=special project, DS=drone safari,
  TR=target rollup, HS=historical summary, MS=mission summary, … (full list TBD)
- **YY** = 2-digit year
- **NNN** = sequential number (3-digit, zero-padded? TBD), resets yearly (TBD)

User wants this **auto-generated** if feasible (manual is acceptable fallback).
Kanboard has NO native auto-numbering → needs **custom plugin** (PHP, into plugins volume) OR
**API helper script** OR manual + cheat-sheet.

### Decisions (resolved 2026-06-20)
- **Counter scope:** GLOBAL per year (one running total; per-type counts still derivable via Kanboard filters).
- **When assigned:** on move to **Approved / Queued** column (only committed products get numbered).
- **Implementation:** custom Kanboard **Automatic Action plugin** (`TrackingNumber`), triggered via UI ("when moved to column X").
- **Customizable / no hardcoded lists:** codes are sourced from Kanboard data the user manages:
  - Product type = **Category**; platform = **Swimlane**.
  - Generator uses the **first word** of the category/swimlane name as the code.
  - e.g. category `SG Significant Observation` + swimlane `A MQ-9` → `ASG26001`.
- **Sequence:** 3-digit zero-padded (`%03d`), resets each January (derived from references ending in current `YY`).
- **Idempotent:** only assigns if the task has no reference yet; skips if no platform/type set (default swimlane ignored).

### Plugin install method
- Switch `plugins` volume from named volume to **bind mount** `./plugins` so files are nano-editable on the host.
- Files: `~/kanboard/plugins/TrackingNumber/Plugin.php` + `~/kanboard/plugins/TrackingNumber/Action/GenerateTrackingNumber.php`.
- PHP is whitespace-insensitive → nano auto-indent mangling is cosmetic only, still runs.

### Gotcha (2026-06-20): PHP "Namespace declaration ... very first statement"
Cause was an invisible **UTF-8 BOM** prepended to the pasted PHP files (before `<?php`).
`sed '1s/^[[:space:]]*//'` does NOT strip a BOM. Fix that worked: rebuild line 1 —
`sed -i '1d' <file>` then `sed -i '1i <?php' <file>`. Verify with `od -c <file> | head -2`
(must start `<  ?  p  h  p`, not `357 273 277`). Note: plugin loads on every request, so a
bad plugin file takes the WHOLE app down until fixed or the plugin folder is removed.

### 2026-06-20 — FULL RESET + plugin deferred
Repeated SSH copy/paste corruption (UTF-8 BOM, and word-wrap splitting long command
lines at spaces) kept breaking the hand-installed plugin files. Decision: **full clean
slate** of Kanboard, and **defer the auto-numbering plugin**. Numbering is **manual for
now**; revisit auto-numbering later via a robust delivery (git clone / tar download), not
line-by-line paste. Core value (pipeline + per-phase time tracking) is all UI-driven — no
file editing needed. New compose returns to simple named volumes (no plugin bind mount).

### 2026-06-20 03:09 UTC — clean rebuild SUCCESS
Fresh Kanboard up from scratch, no plugin. `curl -I` → `302 /login`. Compose: simple
named volumes (`kanboard_data`, `kanboard_plugins`), port 8000→80, dir `~/kanboard`.
Lesson: deliver files by editing in nano then `cat -n` to verify; fix bad lines surgically
with `sed -i 'Ns/.../.../'`. NO base64, NO long pasted heredocs/commands (user's client
word-wraps long lines at spaces and breaks them). All further setup is browser-only.

### Actual board (built 2026-06-20): project "IRIDIUM Team"
Columns: **Inbox → Queued → Pre-Production → Production → Post-Production → Review → Published**
(User dropped the separate "Lessons Learned" and "Done" columns; Review added as its own
column — good for surfacing approval wait time. Completion handled by *closing* the task in
Published. Lessons-learned to be captured in card comments/checklist at Published, or add a
column later if desired.)

### Metadata model (final, 2026-06-20)
- **Product type** → Category (named `CODE Description`).
- **Platform** → Tag (`Plat A/B/C…`); most products on one platform, so tags > swimlanes.
- **Classification** → single level, differing **compartments** → Tags (multi-select OK).
  Placeholders **ABC / DEF / GHI / JKL** (user will swap in real compartment names later).
- **Tracking number** → MANUAL. Format `P TT YY NNN` (e.g. `ASG26001`), global per-year seq,
  assigned at Queued. Store number in card **Reference** field + title prefix. Next number =
  highest-numbered product this year + 1. Cheat-sheet kept in the **project Description**.
- **Intake fields** (target/location/source timestamps/context/folder/Resolve) → markdown
  **template card** that gets duplicated per product.

### 2026-06-20 — auto-numbering REVIVED (clean delivery via scp, no pasting code)
Root cause of earlier failures was file *delivery* (terminal mangled pasted code), not the
code. New method: plugin files authored on the Mac at `~/Documents/CAPS/TrackingNumber/`
(`Plugin.php`, `Action/GenerateTrackingNumber.php`), `scp`'d to server, `docker cp`'d into
the running container's `/var/www/app/plugins/`. Plugin updated for tags model: platform =
last word of a `Plat X` TAG (since platform is a tag now, not a swimlane); type = first word
of Category. Trigger column = **Queued**. Wire via Project → Actions in UI.
Tip: scp/docker cp lines are short — TYPE them if a paste looks wrapped.

### Tracking-number operations / how-to (reference)
**How the counter works:** it is *derived, not stored* — on each move into the trigger
column the plugin computes `next = (highest existing reference for the current year) + 1`,
reading all tasks (open AND closed) in the project directly from the DB. There is no
separate counter to reset.

**Reset numbering (e.g. after testing):** *delete* the numbered cards — open card → menu →
**Remove** → confirm. Closing a card does NOT reset it (closed cards still count). Once the
highest-numbered cards are removed, the next card recalculates lower; remove them all and the
next card starts at `001`. Note: gaps don't self-heal — deleting a middle number doesn't pull
later numbers down; only deleting the *highest* ones walks the counter back.

**Manually set / correct a number:** edit the card's **Reference** field directly. The plugin
is idempotent — it only assigns when Reference is empty and **never overwrites** an existing
one. So to fix a mis-numbered card or reserve a specific number, just type the value into
Reference (and update the title prefix to match if desired).

**Year rollover:** automatic. The regex only counts references ending in the current 2-digit
year, so on 1 Jan the prefix becomes `27` and the sequence naturally restarts at `001` — no
manual action.

**Reserve a starting number:** because next = max+1, you can force the next value by creating
(or editing) a card whose Reference ends in `YY` + (desired-1). Rarely needed.

### Task template + per-step time tracking (2026-06-20)
**Mechanism:** one parked **template card** holding the full **subtask** checklist; duplicate
it per product (Kanboard duplicate copies subtasks + description + tags + category + estimates;
auto-prefixes title `[DUPLICATE]`). Subtasks each carry their own time tracking — toggling a
subtask Todo→In progress→Done auto-logs elapsed into its "time spent"; estimates settable per
subtask; card total spent = sum of subtasks. This is STEP-level timing (manual toggle/timer),
complementing the automatic COLUMN-level analytics (phase timing).

**Template card subtasks (default; user to tweak):**
- Pre: [Pre] Gather project info · [Pre] Build folder structure · [Pre] Pull raw video ·
  [Pre] Encode to intermediate (source roll) · [Pre] Create DaVinci Resolve project
- Prod: [Prod] Cut · [Prod] Stabilize · [Prod] Color · [Prod] Fusion · [Prod] Build · [Prod] Draft
- Post: [Post] Render · [Post] Review · [Post] Publish

**Usage rules:**
- Keep the template card PARKED in Inbox; never move it to Queued (would get auto-numbered).
- Per product: Duplicate template → rename → set Category + `Plat _` tag → drag to Queued (auto-numbers).
- Optionally set a default `Plat A` tag + time estimates on the template so duplicates inherit them.

### Build order
1. Columns (7) — in progress
2. Create Categories (product types) + Swimlanes (platforms), each named `CODE Description`
3. Install plugin (bind-mount + 2 files + recreate container)
4. Wire Automatic Action: Project → Actions → "Move to column = Approved/Queued → Generate product tracking number"
5. Test: move a card with a swimlane+category into Approved → expect reference like `ASG26001`

## Architecture (planned)

```
[ team browsers ] --(HTTP :8000 or HTTPS via proxy)--> [ focalboard container ] --> [ persistent volume ]
```

## Change log

### 2026-06-19 — Initial setup
- Created this tracking document.
- (pending) Author docker-compose + first run.

## Commands run (server)

> Filled in as we go. Each entry: what it does + result observed.

### Step 1 — create project dir
```bash
mkdir -p ~/focalboard && cd ~/focalboard
```

### Step 2 — write docker-compose.yml
```bash
cat > docker-compose.yml <<'EOF'
services:
  focalboard:
    image: mattermost/focalboard:latest
    container_name: focalboard
    restart: unless-stopped
    ports:
      - "8000:8000"
    volumes:
      - fbdata:/opt/focalboard/data

volumes:
  fbdata:
EOF
```

### Step 3 — pull + start
```bash
docker compose up -d
docker compose ps
```

### Step 4 — verify
```bash
docker compose logs --tail=40 focalboard      # look for server listening on :8000
curl -I http://localhost:8000                  # expect HTTP 200 / redirect
```
Then browse to `http://<SERVER_LAN_IP>:8000` and register the first (admin) account.

**Result observed (2026-06-20 01:37 UTC):** ✅ Success.
- Container `focalboard` Up, ports `0.0.0.0:8000->8000`.
- Logs: `http server started port=8000`; sqlite db at `./data/focalboard.db` (→ `fbdata` volume).
- `curl -I http://localhost:8000` → `HTTP/1.1 200 OK`.
- Image self-reports version **7.8.9** (build=dev); `latest` tag is older than numbered tags — expected for EOL image.
- Server config of note: `ServerRoot=http://localhost:8000`, `AuthMode=native`, `EnableLocalMode=true`, `LocalOnly=false`, `EnablePublicSharedBoards=false`, `Telemetry=true`.

### Facts worth remembering for later tuning
- Config is baked into the image's `config.json`. To change settings (server root URL,
  disable telemetry, enable public shared boards, session length), we'll bind-mount a
  custom `config.json` over `/opt/focalboard/config.json` and restart.
- First user to register = admin.
- Host: `mcadmin@nimcraft`, project dir `~/focalboard`.

---

## 2026-06-20 — PIVOT to Kanboard

Decision: replace Focalboard with **Kanboard** (automatic per-phase time tracking;
actively maintained). Reuse host port 8000.

### Kanboard image facts (verified from docs.kanboard.org)
- Image: `kanboard/kanboard:latest` (Docker Hub / GHCR / Quay). Docs suggest pinning a version.
- Container listens on **80 (HTTP)** and 443 (HTTPS).
- Persistent volumes: `/var/www/app/data` (SQLite db + attachments) and `/var/www/app/plugins`.
- Default login: **admin / admin** → MUST change immediately on first login.

### Step A — tear down Focalboard (removes its data volume; no real boards were created)
```bash
cd ~/focalboard
docker compose down -v
```

### Step B — create Kanboard project + compose file
```bash
mkdir -p ~/kanboard && cd ~/kanboard
nano docker-compose.yml
```
Contents:
```yaml
services:
  kanboard:
    image: kanboard/kanboard:latest
    container_name: kanboard
    restart: unless-stopped
    ports:
      - "8000:80"
    volumes:
      - kanboard_data:/var/www/app/data
      - kanboard_plugins:/var/www/app/plugins

volumes:
  kanboard_data:
  kanboard_plugins:
```

### Step C — start + verify
```bash
docker compose up -d && docker compose ps
docker compose logs --tail=30 kanboard
curl -I http://localhost:8000
```
Then browse `http://<SERVER_LAN_IP>:8000`, log in **admin/admin**, immediately change the admin password.

**Result observed (2026-06-20 01:56 UTC):** ✅ Success.
- First boot generated a self-signed SSL cert (OpenSSL output in logs — normal).
- `curl -I http://localhost:8000` → `HTTP/1.1 302 Found`, `Location: /login`, sets `KB_SID` cookie.
- Security headers present out of the box: CSP, `X-Frame-Options: DENY`, `X-Content-Type-Options: nosniff`, `X-XSS-Protection`.
- Host: `mcadmin@nimcraft`, project dir `~/kanboard`, port 8000→80.

### 2026-06-20 — reset to default
Leftover data from an earlier Kanboard attempt was present (old volume reused).
Fixed by `docker compose down -v` (wiped `kanboard_data` + `kanboard_plugins`),
removed orphan `kanboard_kanboard_ssl` volume, then `docker compose up -d`.
Now clean: only `kanboard_kanboard_data` + `kanboard_kanboard_plugins`, both empty.

### Immediate hardening checklist (do at first login)
- [ ] Change admin password from default `admin/admin`
- [ ] (Optional) rename the admin username
- [ ] Decide registration/user-creation policy (Kanboard has no open self-registration — admin creates users)
- [ ] Keep LAN/VPN-only; no direct internet exposure

---

## Rollback / teardown notes

- `docker compose down` stops & removes the container (data volume preserved).
- `docker compose down -v` ALSO deletes the data volume (destroys boards). Avoid unless intentional.
