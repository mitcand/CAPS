<%*
// New Product intake — drives all field entry via prompts, so the operator never hand-edits YAML.
// Requires Templater. Bind to a hotkey, or use the "➕ New Product" Meta Bind button.

// ─────────────────────────────────────────────────────────────
// PRODUCT ID CONFIG — edit these two to match your shop.
//   ID format:  <program:1><type:2><year:2><seq:3>   e.g.  A VD 26 001  ->  AVD26001
//   Sequence is GLOBAL across all programs/types, and RESETS each calendar year.
const PROGRAMS   = ["A", "B", "C"];
const TYPE_CODES = { video: "VD", graphic: "GR", map: "MP", report: "RP" };
// ─────────────────────────────────────────────────────────────

const statuses = ["Inbox","Backlog","Preproduction","Production","Postproduction","Draft","Published","Archived"];
const status = await tp.system.suggester(statuses, statuses, false, "Status");
const priority = await tp.system.suggester(["routine","priority","immediate"], ["routine","priority","immediate"], false, "Priority");
const program = await tp.system.suggester(PROGRAMS, PROGRAMS, false, "Program code");
const ptype = await tp.system.suggester(Object.keys(TYPE_CODES), Object.keys(TYPE_CODES), false, "Product type");
const typeCode = TYPE_CODES[ptype];
const platform = await tp.system.prompt("Collection platform", "", false);
const classification = await tp.system.prompt("Classification marking", "UNCLASSIFIED");
const due = await tp.system.prompt("Due date (YYYY-MM-DD, blank = none)", "", false);
const title = await tp.system.prompt("Short title");

// ── Area pickers (multi-select): add one or more, "✓ done" to finish, "➕ Create new …" to make one inline ──
const today = tp.date.now("YYYY-MM-DD");

// Minimal inline creator — writes a valid Area note if it doesn't already exist, returns its basename.
async function createNote(folder, base, fmLines) {
  const path = folder + "/" + base + ".md";
  if (!app.vault.getAbstractFileByPath(path)) {
    await app.vault.create(path, "---\n" + fmLines + "created: " + today + "\n---\n\n# " + base + "\n");
  }
  return base;
}

// Each product can carry MULTIPLE of each area. Loop the suggester until the
// operator picks "✓ done", accumulating selections into an array. Already-picked
// notes drop out of the list so they can't be added twice.
async function pickMultiArea(folder, label, createFn) {
  const picked = [];
  while (true) {
    const names = app.vault.getMarkdownFiles()
      .filter(f => f.path.startsWith(folder + "/"))
      .map(f => f.basename)
      .filter(n => !picked.includes(n))
      .sort();
    const DONE = "✓ done" + (picked.length ? " — " + picked.length + " selected" : " — none");
    const NEW  = "➕ Create new " + label + "…";
    const opts = [DONE, NEW, ...names];
    const prompt = label + (picked.length ? " (add another, or ✓ done)" : " (pick one or more)");
    const pick = await tp.system.suggester(opts, opts, false, prompt);
    if (pick == null || pick === DONE) break;
    if (pick === NEW) { picked.push(await createFn()); continue; }
    picked.push(pick);
  }
  return picked;
}

// Render an array of note basenames as a YAML list of wiki-links (empty string = null field).
function yamlLinks(arr) {
  if (!arr || arr.length === 0) return "";
  return arr.map(n => "\n  - \"[[" + n + "]]\"").join("");
}

const mission = await pickMultiArea("Areas/Missions", "Mission", async () => {
  const id   = await tp.system.prompt("New Mission — Mission ID");
  const fl   = await tp.system.prompt("Flight number (optional)", "", false);
  const plat = await tp.system.prompt("Platform (optional)", "", false);
  const base = id + (fl ? " FL" + fl : "");
  return await createNote("Areas/Missions", base,
    "tracker: mission\ntags: [area, mission]\nmission_id: " + id + "\nflight_number: " + fl +
    "\nplatform: " + plat + "\ntakeoff_date: \nland_date: \ntakeoff_location: \nland_location: \n");
});

const customer = await pickMultiArea("Areas/Customers", "Customer", async () => {
  const name = await tp.system.prompt("New Customer — name/label (e.g. J2)");
  const cid  = await tp.system.prompt("Center ID (optional)", "", false);
  const poc  = await tp.system.prompt("POC (optional)", "", false);
  const base = cid ? cid + " " + name : name;
  return await createNote("Areas/Customers", base,
    "tracker: customer\ntags: [area, customer]\nname: " + name + "\ncenter_id: " + cid + "\npoc: " + poc + "\n");
});

const country = await pickMultiArea("Areas/Countries", "Country", async () => {
  const cname = await tp.system.prompt("New Country — name");
  const ccode = await tp.system.prompt("Country code (ISO, e.g. CAN)");
  const base  = ccode + " " + cname;
  return await createNote("Areas/Countries", base,
    "tracker: country\ntags: [area, country]\ncountry_name: " + cname + "\ncountry_code: " + ccode + "\n");
});

const target = await pickMultiArea("Areas/Targets", "Target", async () => {
  const tname = await tp.system.prompt("New Target — name");
  const tid   = await tp.system.prompt("Target ID");
  const coord = await tp.system.prompt("Coordinates (optional)", "", false);
  const base  = tid + " " + tname;
  return await createNote("Areas/Targets", base,
    "tracker: target\ntags: [area, target]\ntarget_name: " + tname + "\ntarget_id: " + tid +
    "\ncoordinates: " + coord + "\nimage: \n");
});

// ── Generate the next sequential ID by scanning the vault (source of truth = existing notes) ──
const yy = tp.date.now("YY");
const yearRe = new RegExp("^[A-Za-z]{3}" + yy + "(\\d{3})$");
let maxSeq = 0;
for (const f of app.vault.getMarkdownFiles()) {
  const fm = app.metadataCache.getFileCache(f)?.frontmatter;
  const candidates = [fm?.product_id, f.basename.split(" ")[0]];
  for (const c of candidates) {
    if (typeof c !== "string") continue;
    const m = c.match(yearRe);
    if (m) { const n = parseInt(m[1], 10); if (n > maxSeq) maxSeq = n; }
  }
}
const seq = String(maxSeq + 1).padStart(3, "0");
const productId = program + typeCode + yy + seq;

// Move the note into its own folder so Folder Notes turns it into a folder + folder note.
// Result:  <parent>/AVD26001 Title/AVD26001 Title.md   (folderNoteName = {{folder_name}}, insideFolder)
const productName = productId + " " + title;
const parent = tp.file.folder(true);                       // e.g. "Production"
const folderPath = (parent ? parent + "/" : "") + productName;
try { await app.vault.createFolder(folderPath); } catch (e) { /* folder already exists — fine */ }
await tp.file.move(folderPath + "/" + productName);
-%>
---
tracker: product
tags: [task]
cssclasses: [product]
product_id: <% productId %>
program: <% program %>
title: <% title %>
status: <% status %>
priority: <% priority %>
product_type: <% ptype %>
collection_platform: <% platform %>
mission:<% yamlLinks(mission) %>
customer:<% yamlLinks(customer) %>
country:<% yamlLinks(country) %>
target:<% yamlLinks(target) %>
duration_sec:
classification: <% classification %>
created: <% tp.date.now("YYYY-MM-DD") %>
due: <% due %>
done:
time_pre_min: 0
time_prod_min: 0
time_post_min: 0
notes:
sourcing:
coordination:
feedback:
---
# <% productId %> — <% title %>

## Controls
**Status** `INPUT[inlineSelect(option(Inbox), option(Backlog), option(Preproduction), option(Production), option(Postproduction), option(Draft), option(Published), option(Archived)):status]` · **Done** `INPUT[date:done]`

```meta-bind-button
label: "✅ Mark Published"
style: primary
id: "mark-published"
actions:
  - type: updateMetadata
    bindTarget: status
    evaluate: false
    value: "Published"
  - type: updateMetadata
    bindTarget: done
    evaluate: true
    value: new Date().toLocaleDateString('en-CA')
```

## Time
```meta-bind-js-view
{time_pre_min} as pre
{time_prod_min} as prod
{time_post_min} as post
---
const pre  = Number(context.bound.pre)  || 0;
const prod = Number(context.bound.prod) || 0;
const post = Number(context.bound.post) || 0;
const total = pre + prod + post;
const hm  = m => (m >= 60 ? Math.floor(m / 60) + "h " : "") + (m % 60) + "m";
const pct = m => total ? Math.round(m / total * 100) : 0;
return engine.markdown.create(
  "**Total:** " + hm(total) + "  \n" +
  "Preproduction " + hm(pre) + " (" + pct(pre) + "%) · " +
  "Production " + hm(prod) + " (" + pct(prod) + "%) · " +
  "Postproduction " + hm(post) + " (" + pct(post) + "%)"
);
```

**Preproduction**  `BUTTON[t-pre-sub]` `BUTTON[t-pre-15]` `BUTTON[t-pre-30]`
**Production**  `BUTTON[t-prod-sub]` `BUTTON[t-prod-15]` `BUTTON[t-prod-30]`
**Postproduction**  `BUTTON[t-post-sub]` `BUTTON[t-post-15]` `BUTTON[t-post-30]`
`BUTTON[t-reset]`

```meta-bind-button
label: "-15"
hidden: true
id: "t-pre-sub"
style: default
action:
  type: updateMetadata
  bindTarget: time_pre_min
  evaluate: true
  value: Math.max(x - 15, 0)
```
```meta-bind-button
label: "+15"
hidden: true
id: "t-pre-15"
style: default
action:
  type: updateMetadata
  bindTarget: time_pre_min
  evaluate: true
  value: x + 15
```
```meta-bind-button
label: "+30"
hidden: true
id: "t-pre-30"
style: default
action:
  type: updateMetadata
  bindTarget: time_pre_min
  evaluate: true
  value: x + 30
```
```meta-bind-button
label: "-15"
hidden: true
id: "t-prod-sub"
style: default
action:
  type: updateMetadata
  bindTarget: time_prod_min
  evaluate: true
  value: Math.max(x - 15, 0)
```
```meta-bind-button
label: "+15"
hidden: true
id: "t-prod-15"
style: default
action:
  type: updateMetadata
  bindTarget: time_prod_min
  evaluate: true
  value: x + 15
```
```meta-bind-button
label: "+30"
hidden: true
id: "t-prod-30"
style: default
action:
  type: updateMetadata
  bindTarget: time_prod_min
  evaluate: true
  value: x + 30
```
```meta-bind-button
label: "-15"
hidden: true
id: "t-post-sub"
style: default
action:
  type: updateMetadata
  bindTarget: time_post_min
  evaluate: true
  value: Math.max(x - 15, 0)
```
```meta-bind-button
label: "+15"
hidden: true
id: "t-post-15"
style: default
action:
  type: updateMetadata
  bindTarget: time_post_min
  evaluate: true
  value: x + 15
```
```meta-bind-button
label: "+30"
hidden: true
id: "t-post-30"
style: default
action:
  type: updateMetadata
  bindTarget: time_post_min
  evaluate: true
  value: x + 30
```
```meta-bind-button
label: "Reset time"
hidden: true
id: "t-reset"
style: destructive
actions:
  - type: updateMetadata
    bindTarget: time_pre_min
    evaluate: false
    value: 0
  - type: updateMetadata
    bindTarget: time_prod_min
    evaluate: false
    value: 0
  - type: updateMetadata
    bindTarget: time_post_min
    evaluate: false
    value: 0
```

> [!subtasks]+ Subtasks
> ```js-engine
> const file = context.file;
> const A = engine.app || globalThis.app;
> const build = async () => {
>   const text = await A.vault.cachedRead(file);
>   const boxes = text.split("\n").filter(l => /^>\s*- \[.\]/.test(l));
>   const done = boxes.filter(l => /\[[xX]\]/.test(l)).length;
>   const total = boxes.length;
>   const pct = total ? Math.round((done / total) * 100) : 0;
>   const filled = Math.round(pct / 10);
>   const bar = "█".repeat(filled) + "░".repeat(10 - filled);
>   return engine.markdown.create("`" + bar + "` **" + pct + "%** · " + done + "/" + total + " done");
> };
> const comp = engine.reactive(build);
> component.registerEvent(A.metadataCache.on("changed", (f) => { if (f && f.path === file.path) comp.refresh(); }));
> return comp;
> ```
>
> ### Preproduction
> - [ ] Obsidian
> - [ ] Project
> - [ ] Files
>
> ### Production
> - [ ] Cut
> - [ ] Stab
> - [ ] Color
> - [ ] Build
> - [ ] Draft
>
> ### Postproduction
> - [ ] Render
> - [ ] Review
> - [ ] Publish

## Notes
```meta-bind
INPUT[textArea:notes]
```

## Sourcing / Collection
```meta-bind
INPUT[textArea:sourcing]
```

## Coordination / Tasking
```meta-bind
INPUT[textArea:coordination]
```

## Feedback / Revisions
```meta-bind
INPUT[textArea:feedback]
```

## Journal
- <% tp.date.now("YYYY-MM-DD HH:mm") %> — created.
