<%*
/* ══════════════════════════════════════════════════════════════════════
   NEW PRODUCT  —  intake template (requires Templater)

   Prompts the operator for every field so the YAML is never hand-edited.
   Bind to a hotkey, or use the "➕ New Product" Meta Bind button.

   To maintain this template you normally only touch two sections below:
     • CONFIG            — the product-ID scheme (programs / type codes)
     • LISTS & SELECTORS — every drop-down pick-list and area definition
   ══════════════════════════════════════════════════════════════════════ */


// ══════════════════════════════════════════════════════════════════════
// CONFIG  — edit these to match your shop
// ══════════════════════════════════════════════════════════════════════
//   Product ID format:  <program:1><type:2><year:2><seq:3>
//     e.g.  A + VD + 26 + 001  ->  AVD26001
//   The sequence is GLOBAL across all programs/types and RESETS each year.
const PROGRAMS   = ["A", "B", "C"];
const TYPE_CODES = { video: "VD", graphic: "GR", map: "MP", report: "RP" };


// ══════════════════════════════════════════════════════════════════════
// LISTS & SELECTORS  — every pick-list lives here; add/remove items freely
// ══════════════════════════════════════════════════════════════════════
const STATUSES   = ["Inbox","Backlog","Preproduction","Production","Postproduction","Draft","Published","Archived"];
const PRIORITIES = ["routine","priority","immediate"];

// AREAS — each product can link MULTIPLE notes from each of these folders.
//
// To add a new area, copy one entry below and change:
//   key    — the front-matter field it fills in (see the YAML at the bottom)
//   folder — where its notes live
//   label  — what the operator sees in the picker
//   create — the prompts for a brand-new note, plus the fields to save.
//
// In create(), each `fields` line is just  fieldName: value  — no quotes or
// line breaks to get right. Leave a value as "" for a field the operator
// fills in later, and use [ ... ] for a list (like tags).
const AREAS = [
  {
    key: "mission", folder: "Areas/Missions", label: "Mission",
    create: async (folder) => {
      const id   = await tp.system.prompt("New Mission — Mission ID");
      const fl   = await tp.system.prompt("Flight number (optional)", "", false);
      const plat = await tp.system.prompt("Platform (optional)", "", false);
      const base = id + (fl ? " FL" + fl : "");          // note title, e.g. "M123 FL07"
      return createNote(folder, base, {
        tracker: "mission",
        tags: ["area", "mission"],
        mission_id: id,
        flight_number: fl,
        platform: plat,
        takeoff_date: "",
        land_date: "",
        takeoff_location: "",
        land_location: "",
      });
    },
  },
  {
    key: "customer", folder: "Areas/Customers", label: "Customer",
    create: async (folder) => {
      const name = await tp.system.prompt("New Customer — name/label (e.g. J2)");
      const cid  = await tp.system.prompt("Center ID (optional)", "", false);
      const poc  = await tp.system.prompt("POC (optional)", "", false);
      const base = cid ? cid + " " + name : name;
      return createNote(folder, base, {
        tracker: "customer",
        tags: ["area", "customer"],
        name: name,
        center_id: cid,
        poc: poc,
      });
    },
  },
  {
    key: "country", folder: "Areas/Countries", label: "Country",
    create: async (folder) => {
      const cname = await tp.system.prompt("New Country — name");
      const ccode = await tp.system.prompt("Country code (ISO, e.g. CAN)");
      const base  = ccode + " " + cname;
      return createNote(folder, base, {
        tracker: "country",
        tags: ["area", "country"],
        country_name: cname,
        country_code: ccode,
      });
    },
  },
  {
    key: "target", folder: "Areas/Targets", label: "Target",
    create: async (folder) => {
      const tname = await tp.system.prompt("New Target — name");
      const tid   = await tp.system.prompt("Target ID");
      const coord = await tp.system.prompt("Coordinates (optional)", "", false);
      const base  = tid + " " + tname;
      return createNote(folder, base, {
        tracker: "target",
        tags: ["area", "target"],
        target_name: tname,
        target_id: tid,
        coordinates: coord,
        image: "",
      });
    },
  },
];


// ══════════════════════════════════════════════════════════════════════
// FUNCTIONS  — reusable helpers; nothing here runs until it's called below
// ══════════════════════════════════════════════════════════════════════
const today = tp.date.now("YYYY-MM-DD");

// Format one front-matter value: a list becomes [a, b]; anything else is
// written as-is (an empty string just leaves the field blank).
function yamlValue(value) {
  return Array.isArray(value) ? "[" + value.join(", ") + "]" : value;
}

// Inline note creator — if no note exists yet at folder/base.md, build one
// whose front-matter comes from the `fields` object (plus a created date).
// Returns the note's basename either way, so the picker can link to it.
async function createNote(folder, base, fields) {
  const path = folder + "/" + base + ".md";
  if (!app.vault.getAbstractFileByPath(path)) {
    const lines = Object.entries(fields).map(([key, value]) => key + ": " + yamlValue(value));
    lines.push("created: " + today);
    await app.vault.create(path, "---\n" + lines.join("\n") + "\n---\n\n# " + base + "\n");
  }
  return base;
}

// Repeatedly show a suggester so the operator can attach one or more notes
// from `folder`. "✓ done" ends the loop; "➕ Create new…" runs createFn.
// Already-picked notes drop out of the list so they can't be added twice.
async function pickMultiArea(folder, label, createFn) {
  const picked = [];
  while (true) {
    const names = app.vault.getMarkdownFiles()
      .filter(f => f.path.startsWith(folder + "/"))
      .map(f => f.basename)
      .filter(n => !picked.includes(n))
      .sort();
    const DONE = "✓ done" + (picked.length ? " — " + picked.length + " selected" : " — none");
    const NEW  = "➕ Create new " + label + "…";
    const opts = [DONE, NEW, ...names];
    const prompt = label + (picked.length ? " (add another, or ✓ done)" : " (pick one or more)");
    const pick = await tp.system.suggester(opts, opts, false, prompt);
    if (pick == null || pick === DONE) break;
    if (pick === NEW) { picked.push(await createFn(folder)); continue; }
    picked.push(pick);
  }
  return picked;
}

// Render an array of note basenames as a YAML list of wiki-links
// (empty array collapses the field to null).
function yamlLinks(arr) {
  if (!arr || arr.length === 0) return "";
  return arr.map(n => "\n  - \"[[" + n + "]]\"").join("");
}

// Next sequential product ID: scan every note for this year's IDs and add 1.
// The vault itself is the source of truth, so sequences survive across sessions.
function nextProductId(program, typeCode, yy) {
  const yearRe = new RegExp("^[A-Za-z]{3}" + yy + "(\\d{3})$");
  let maxSeq = 0;
  for (const f of app.vault.getMarkdownFiles()) {
    const fm = app.metadataCache.getFileCache(f)?.frontmatter;
    const candidates = [fm?.product_id, f.basename.split(" ")[0]];
    for (const c of candidates) {
      if (typeof c !== "string") continue;
      const m = c.match(yearRe);
      if (m) { const n = parseInt(m[1], 10); if (n > maxSeq) maxSeq = n; }
    }
  }
  return program + typeCode + yy + String(maxSeq + 1).padStart(3, "0");
}


// ══════════════════════════════════════════════════════════════════════
// FIELD ENTRY  — prompt the operator for every product field
// ══════════════════════════════════════════════════════════════════════
const status         = await tp.system.suggester(STATUSES, STATUSES, false, "Status");
const priority       = await tp.system.suggester(PRIORITIES, PRIORITIES, false, "Priority");
const program        = await tp.system.suggester(PROGRAMS, PROGRAMS, false, "Program code");
const ptype          = await tp.system.suggester(Object.keys(TYPE_CODES), Object.keys(TYPE_CODES), false, "Product type");
const typeCode       = TYPE_CODES[ptype];
const platform       = await tp.system.prompt("Collection platform", "", false);
const classification = await tp.system.prompt("Classification marking", "UNCLASSIFIED");
const due            = await tp.system.prompt("Due date (YYYY-MM-DD, blank = none)", "", false);
const title          = await tp.system.prompt("Short title");

// Attach linked area notes. Results are keyed by AREAS[].key — e.g.
// picks.mission — and consumed by yamlLinks(...) in the YAML below.
const picks = {};
for (const area of AREAS) picks[area.key] = await pickMultiArea(area.folder, area.label, area.create);


// ══════════════════════════════════════════════════════════════════════
// ID + FILE PLACEMENT
// ══════════════════════════════════════════════════════════════════════
const yy        = tp.date.now("YY");
const productId = nextProductId(program, typeCode, yy);

// Move the note into its own folder so Folder Notes turns it into a folder +
// folder note:  <parent>/AVD26001 Title/AVD26001 Title.md
const productName = productId + " " + title;
const parent      = tp.file.folder(true);                  // e.g. "Production"
const folderPath  = (parent ? parent + "/" : "") + productName;
try { await app.vault.createFolder(folderPath); } catch (e) { /* folder already exists — fine */ }
await tp.file.move(folderPath + "/" + productName);
-%>
---
tracker: product
tags: [task]
cssclasses: [product]
product_id: <% productId %>
program: <% program %>
title: <% title %>
status: <% status %>
priority: <% priority %>
product_type: <% ptype %>
collection_platform: <% platform %>
mission:<% yamlLinks(picks.mission) %>
customer:<% yamlLinks(picks.customer) %>
country:<% yamlLinks(picks.country) %>
target:<% yamlLinks(picks.target) %>
duration_sec:
classification: <% classification %>
created: <% tp.date.now("YYYY-MM-DD") %>
due: <% due %>
done:
time_pre_min: 0
time_prod_min: 0
time_post_min: 0
notes:
sourcing:
coordination:
feedback:
---
# <% productId %> — <% title %>

## Controls
**Status** `INPUT[inlineSelect(option(Inbox), option(Backlog), option(Preproduction), option(Production), option(Postproduction), option(Draft), option(Published), option(Archived)):status]` · **Done** `INPUT[date:done]`

```meta-bind-button
label: "✅ Mark Published"
style: primary
id: "mark-published"
actions:
  - type: updateMetadata
    bindTarget: status
    evaluate: false
    value: "Published"
  - type: updateMetadata
    bindTarget: done
    evaluate: true
    value: new Date().toLocaleDateString('en-CA')
```

## Time
```meta-bind-js-view
{time_pre_min} as pre
{time_prod_min} as prod
{time_post_min} as post
---
const pre  = Number(context.bound.pre)  || 0;
const prod = Number(context.bound.prod) || 0;
const post = Number(context.bound.post) || 0;
const total = pre + prod + post;
const hm  = m => (m >= 60 ? Math.floor(m / 60) + "h " : "") + (m % 60) + "m";
const pct = m => total ? Math.round(m / total * 100) : 0;
return engine.markdown.create(
  "**Total:** " + hm(total) + "  \n" +
  "Preproduction " + hm(pre) + " (" + pct(pre) + "%) · " +
  "Production " + hm(prod) + " (" + pct(prod) + "%) · " +
  "Postproduction " + hm(post) + " (" + pct(post) + "%)"
);
```

**Preproduction**  `BUTTON[t-pre-sub]` `BUTTON[t-pre-15]` `BUTTON[t-pre-30]`
**Production**  `BUTTON[t-prod-sub]` `BUTTON[t-prod-15]` `BUTTON[t-prod-30]`
**Postproduction**  `BUTTON[t-post-sub]` `BUTTON[t-post-15]` `BUTTON[t-post-30]`
`BUTTON[t-reset]`

<!-- Time buttons: the ten blocks below define the +/- buttons used above.
     They are `hidden: true`, so only the `BUTTON[id]` references (e.g.
     BUTTON[t-pre-15]) render on the page. Each phase (pre / prod / post) has
     the same three buttons; to change a step size, edit its `value:` line
     (e.g. `x + 15` -> `x + 10`). Do not reuse an `id:` — each must be unique. -->

```meta-bind-button
label: "-15"
hidden: true
id: "t-pre-sub"
style: default
action:
  type: updateMetadata
  bindTarget: time_pre_min
  evaluate: true
  value: Math.max(x - 15, 0)
```
```meta-bind-button
label: "+15"
hidden: true
id: "t-pre-15"
style: default
action:
  type: updateMetadata
  bindTarget: time_pre_min
  evaluate: true
  value: x + 15
```
```meta-bind-button
label: "+30"
hidden: true
id: "t-pre-30"
style: default
action:
  type: updateMetadata
  bindTarget: time_pre_min
  evaluate: true
  value: x + 30
```
```meta-bind-button
label: "-15"
hidden: true
id: "t-prod-sub"
style: default
action:
  type: updateMetadata
  bindTarget: time_prod_min
  evaluate: true
  value: Math.max(x - 15, 0)
```
```meta-bind-button
label: "+15"
hidden: true
id: "t-prod-15"
style: default
action:
  type: updateMetadata
  bindTarget: time_prod_min
  evaluate: true
  value: x + 15
```
```meta-bind-button
label: "+30"
hidden: true
id: "t-prod-30"
style: default
action:
  type: updateMetadata
  bindTarget: time_prod_min
  evaluate: true
  value: x + 30
```
```meta-bind-button
label: "-15"
hidden: true
id: "t-post-sub"
style: default
action:
  type: updateMetadata
  bindTarget: time_post_min
  evaluate: true
  value: Math.max(x - 15, 0)
```
```meta-bind-button
label: "+15"
hidden: true
id: "t-post-15"
style: default
action:
  type: updateMetadata
  bindTarget: time_post_min
  evaluate: true
  value: x + 15
```
```meta-bind-button
label: "+30"
hidden: true
id: "t-post-30"
style: default
action:
  type: updateMetadata
  bindTarget: time_post_min
  evaluate: true
  value: x + 30
```
```meta-bind-button
label: "Reset time"
hidden: true
id: "t-reset"
style: destructive
actions:
  - type: updateMetadata
    bindTarget: time_pre_min
    evaluate: false
    value: 0
  - type: updateMetadata
    bindTarget: time_prod_min
    evaluate: false
    value: 0
  - type: updateMetadata
    bindTarget: time_post_min
    evaluate: false
    value: 0
```

> [!subtasks]+ Subtasks
> ```js-engine
> const file = context.file;
> const A = engine.app || globalThis.app;
> const build = async () => {
>   const text = await A.vault.cachedRead(file);
>   const boxes = text.split("\n").filter(l => /^>\s*- \[.\]/.test(l));
>   const done = boxes.filter(l => /\[[xX]\]/.test(l)).length;
>   const total = boxes.length;
>   const pct = total ? Math.round((done / total) * 100) : 0;
>   const filled = Math.round(pct / 10);
>   const bar = "█".repeat(filled) + "░".repeat(10 - filled);
>   return engine.markdown.create("`" + bar + "` **" + pct + "%** · " + done + "/" + total + " done");
> };
> const comp = engine.reactive(build);
> component.registerEvent(A.metadataCache.on("changed", (f) => { if (f && f.path === file.path) comp.refresh(); }));
> return comp;
> ```
>
> ### Preproduction
> - [ ] Obsidian
> - [ ] Project
> - [ ] Files
>
> ### Production
> - [ ] Cut
> - [ ] Stab
> - [ ] Color
> - [ ] Build
> - [ ] Draft
>
> ### Postproduction
> - [ ] Render
> - [ ] Review
> - [ ] Publish

## Notes
```meta-bind
INPUT[textArea:notes]
```

## Sourcing / Collection
```meta-bind
INPUT[textArea:sourcing]
```

## Coordination / Tasking
```meta-bind
INPUT[textArea:coordination]
```

## Feedback / Revisions
```meta-bind
INPUT[textArea:feedback]
```

## Journal
- <% tp.date.now("YYYY-MM-DD HH:mm") %> — created.
