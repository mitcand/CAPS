<%*
// NEW PRODUCT INTAKE TEMPLATE
// LOAD SCRIPTS
const config  = tp.user.config();
const helpers = tp.user.helpers(tp);
const areas   = tp.user.areas(tp, helpers);

// FIELD ENTRY
// Pick-list fields: pickOne shows each item's `name` and returns the whole
// chosen object, so later we can use .name (readable) and .code/.value.
const status   = await helpers.pickOne(config.STATUSES,   "Status");
const priority = await helpers.pickOne(config.PRIORITIES, "Priority");
const program  = await helpers.pickOne(config.PROGRAMS,   "Program");
const type     = await helpers.pickOne(config.TYPE_CODES, "Product type");

// Free-text fields.
const marking = await tp.system.prompt("Classification", "UNCLASSIFIED");
const due     = await tp.system.prompt("Due (YYYY-MM-DD, blank = none)", "", false);
const title   = await tp.system.prompt("Short title");

// ATTACH AREAS — for each area, attach one or more linked notes. "➕ Create
// new…" runs that area's create() from areas.js (matched by area.key).
const picks = {};
for (const area of config.AREAS) {
  picks[area.key] = await helpers.pickMultiArea(area.folder, area.label, areas[area.key]);
}

// PRODUCT ID — pass the chosen program/type CODES plus the 2-digit year.
const yy        = tp.date.now("YY");
const productId = helpers.nextProductId(program.code, type.code, yy);

// FILE PLACEMENT — give the note its own folder so Folder Notes pairs them,
// named by product ID only:  <parent>/ASG26001/ASG26001.md
const parent     = tp.file.folder(true);
const folderPath = (parent ? parent + "/" : "") + productId;
try { await app.vault.createFolder(folderPath); } catch (e) { /* already exists — fine */ }
await tp.file.move(folderPath + "/" + productId);
-%>
---
tracker: product
tags: [task]
cssclasses: [product]
product_id: <% productId %>
program: <% program.code %>
title: <% title %>
status: <% status.name %>
priority: <% priority.name %>
product_type: <% type.code %>
mission: <% helpers.yamlLinks(picks.mission) %>
customer: <% helpers.yamlLinks(picks.customer) %>
country: <% helpers.yamlLinks(picks.country) %>
target: <% helpers.yamlLinks(picks.target) %>
classification: <% marking %>
created: <% tp.date.now("YYYY-MM-DD") %>
due: <% due %>
done:
time_pre_min: 0
time_prod_min: 0
time_post_min: 0
notes:
sourcing:
coordination:
feedback:
---

# <% productId %> — <% title %>

## Missions
<!-- Attached missions only: filters the Missions folder down to notes this
     product links to via its `mission` property (this = the product note). -->
```base
filters:
  and:
    - file.inFolder("Areas/Missions")
    - this.mission.toString().contains(file.name)
properties:
  note.flight_number:
    displayName: Flight #
  note.platform:
    displayName: Platform
  note.takeoff_date:
    displayName: Takeoff
  note.land_date:
    displayName: Landing
  note.takeoff_location:
    displayName: From
  note.land_location:
    displayName: To
views:
  - type: table
    name: Missions
    order:
      - file.name
      - flight_number
      - platform
      - takeoff_date
      - land_date
      - takeoff_location
      - land_location
```

## Targets
<!-- Attached targets only: same idea, scoped by this product's `target` property. -->
```base
filters:
  and:
    - file.inFolder("Areas/Targets")
    - this.target.toString().contains(file.name)
properties:
  note.target_id:
    displayName: Target ID
  note.coordinates:
    displayName: Coordinates
  note.image:
    displayName: Image
views:
  - type: table
    name: Targets
    order:
      - file.name
      - target_id
      - coordinates
      - image
```

## Controls
**Status** `INPUT[inlineSelect(option(Inbox), option(Backlog), option(Preproduction), option(Production), option(Postproduction), option(Draft), option(Published), option(Archived)):status]` · **Done** `INPUT[date:done]` · `BUTTON[mark-published]` `BUTTON[t-reset]`

```meta-bind-button
label: "✅ Mark Published"
hidden: true
style: primary
id: "mark-published"
actions:
  - type: updateMetadata
    bindTarget: status
    evaluate: false
    value: "Published"
  - type: updateMetadata
    bindTarget: done
    evaluate: true
    value: new Date().toLocaleDateString('en-CA')
```

<!-- Combined Time + Subtasks. Three phase columns (laid out by production.css):
     each shows its task count, its minutes with -10 / +10 buttons, and its
     checklist. The overall "% · x/y" readout is floated onto the title row.
     The six hidden time buttons + reset are defined after the callout. -->
> [!subtasks]+ Work
> ```js-engine
> // Overall readout: every checkbox in the note.
> const file = context.file;
> const A = engine.app || globalThis.app;
> const build = async () => {
>   const boxes = (await A.vault.cachedRead(file)).split("\n").filter(l => /^[>\s]*- \[.\]/.test(l));
>   const done = boxes.filter(l => /\[[xX]\]/.test(l)).length;
>   const total = boxes.length;
>   const pct = total ? Math.round(done / total * 100) : 0;
>   const fm = A.metadataCache.getFileCache(file)?.frontmatter || {};
>   const mins = (Number(fm.time_pre_min) || 0) + (Number(fm.time_prod_min) || 0) + (Number(fm.time_post_min) || 0);
>   const hm = (mins >= 60 ? Math.floor(mins / 60) + "h " : "") + (mins % 60) + "m";
>   return engine.markdown.create("**" + pct + "%** · " + done + "/" + total + " done · " + hm);
> };
> const comp = engine.reactive(build);
> component.registerEvent(A.metadataCache.on("changed", (f) => { if (f && f.path === file.path) comp.refresh(); }));
> return comp;
> ```
>
> > [!phase]+ Preproduction
> > ```js-engine
> > // Count only this phase's checkboxes (between its heading and the next phase).
> > const file = context.file;
> > const A = engine.app || globalThis.app;
> > const phase = "Preproduction";
> > const build = async () => {
> >   const lines = (await A.vault.cachedRead(file)).split("\n");
> >   let done = 0, total = 0, seen = false;
> >   for (const line of lines) {
> >     if (/\[!phase\]/.test(line)) { seen = line.includes(phase); continue; }
> >     if (seen && line.trim() && !/^\s*>/.test(line)) seen = false;   // left the Work callout
> >     if (seen && /^[>\s]*- \[.\]/.test(line)) { total++; if (/\[[xX]\]/.test(line)) done++; }
> >   }
> >   return engine.markdown.create("**" + done + "/" + total + "**");
> > };
> > const comp = engine.reactive(build);
> > component.registerEvent(A.metadataCache.on("changed", (f) => { if (f && f.path === file.path) comp.refresh(); }));
> > return comp;
> > ```
> > `VIEW[{time_pre_min}]`m · `BUTTON[t-pre-sub]` `BUTTON[t-pre-add]`
> >
> > - [ ] Obsidian
> > - [ ] Project
> > - [ ] Files
>
> > [!phase]+ Production
> > ```js-engine
> > const file = context.file;
> > const A = engine.app || globalThis.app;
> > const phase = "Production";
> > const build = async () => {
> >   const lines = (await A.vault.cachedRead(file)).split("\n");
> >   let done = 0, total = 0, seen = false;
> >   for (const line of lines) {
> >     if (/\[!phase\]/.test(line)) { seen = line.includes(phase); continue; }
> >     if (seen && line.trim() && !/^\s*>/.test(line)) seen = false;
> >     if (seen && /^[>\s]*- \[.\]/.test(line)) { total++; if (/\[[xX]\]/.test(line)) done++; }
> >   }
> >   return engine.markdown.create("**" + done + "/" + total + "**");
> > };
> > const comp = engine.reactive(build);
> > component.registerEvent(A.metadataCache.on("changed", (f) => { if (f && f.path === file.path) comp.refresh(); }));
> > return comp;
> > ```
> > `VIEW[{time_prod_min}]`m · `BUTTON[t-prod-sub]` `BUTTON[t-prod-add]`
> >
> > - [ ] Cut
> > - [ ] Stab
> > - [ ] Color
> > - [ ] Build
> > - [ ] Draft
>
> > [!phase]+ Postproduction
> > ```js-engine
> > const file = context.file;
> > const A = engine.app || globalThis.app;
> > const phase = "Postproduction";
> > const build = async () => {
> >   const lines = (await A.vault.cachedRead(file)).split("\n");
> >   let done = 0, total = 0, seen = false;
> >   for (const line of lines) {
> >     if (/\[!phase\]/.test(line)) { seen = line.includes(phase); continue; }
> >     if (seen && line.trim() && !/^\s*>/.test(line)) seen = false;
> >     if (seen && /^[>\s]*- \[.\]/.test(line)) { total++; if (/\[[xX]\]/.test(line)) done++; }
> >   }
> >   return engine.markdown.create("**" + done + "/" + total + "**");
> > };
> > const comp = engine.reactive(build);
> > component.registerEvent(A.metadataCache.on("changed", (f) => { if (f && f.path === file.path) comp.refresh(); }));
> > return comp;
> > ```
> > `VIEW[{time_post_min}]`m · `BUTTON[t-post-sub]` `BUTTON[t-post-add]`
> >
> > - [ ] Render
> > - [ ] Review
> > - [ ] Publish

<!-- Time buttons (hidden): each phase gets a -10 and a +10 that adjust its
     minutes. To change the step size, edit the `value:` line. Do not reuse an id. -->

```meta-bind-button
label: "-10"
hidden: true
id: "t-pre-sub"
style: default
action:
  type: updateMetadata
  bindTarget: time_pre_min
  evaluate: true
  value: Math.max(x - 10, 0)
```
```meta-bind-button
label: "+10"
hidden: true
id: "t-pre-add"
style: default
action:
  type: updateMetadata
  bindTarget: time_pre_min
  evaluate: true
  value: x + 10
```
```meta-bind-button
label: "-10"
hidden: true
id: "t-prod-sub"
style: default
action:
  type: updateMetadata
  bindTarget: time_prod_min
  evaluate: true
  value: Math.max(x - 10, 0)
```
```meta-bind-button
label: "+10"
hidden: true
id: "t-prod-add"
style: default
action:
  type: updateMetadata
  bindTarget: time_prod_min
  evaluate: true
  value: x + 10
```
```meta-bind-button
label: "-10"
hidden: true
id: "t-post-sub"
style: default
action:
  type: updateMetadata
  bindTarget: time_post_min
  evaluate: true
  value: Math.max(x - 10, 0)
```
```meta-bind-button
label: "+10"
hidden: true
id: "t-post-add"
style: default
action:
  type: updateMetadata
  bindTarget: time_post_min
  evaluate: true
  value: x + 10
```
```meta-bind-button
label: "Reset time"
hidden: true
id: "t-reset"
style: destructive
actions:
  - type: updateMetadata
    bindTarget: time_pre_min
    evaluate: false
    value: 0
  - type: updateMetadata
    bindTarget: time_prod_min
    evaluate: false
    value: 0
  - type: updateMetadata
    bindTarget: time_post_min
    evaluate: false
    value: 0
```

## Notes
```meta-bind
INPUT[textArea:notes]
```

## Sourcing / Collection
```meta-bind
INPUT[textArea:sourcing]
```

## Coordination / Tasking
```meta-bind
INPUT[textArea:coordination]
```

## Feedback / Revisions
```meta-bind
INPUT[textArea:feedback]
```

## Journal
- <% tp.date.now("YYYY-MM-DD HH:mm") %> — created.
