<%*
// NEW PRODUCT INTAKE TEMPLATE
// LOAD SCRIPTS
const config  = tp.user.config();
const helpers = tp.user.helpers(tp);
const areas   = tp.user.areas(tp, helpers);

// FIELD ENTRY
// Pick-list fields: pickOne shows each item's `name` and returns the whole
// chosen object, so later we can use .name (readable) and .code/.value.
const status   = await helpers.pickOne(config.STATUSES,   "Status");
const priority = await helpers.pickOne(config.PRIORITIES, "Priority");
const program  = await helpers.pickOne(config.PROGRAMS,   "Program");
const type     = await helpers.pickOne(config.TYPE_CODES, "Product type");

// Free-text fields.
const marking = await tp.system.prompt("Classification", "UNCLASSIFIED");
const due     = await tp.system.prompt("Due (YYYY-MM-DD, blank = none)", "", false);
const title   = await tp.system.prompt("Short title");

// ATTACH AREAS — for each area, attach one or more linked notes. "➕ Create
// new…" runs that area's create() from areas.js (matched by area.key).
const picks = {};
for (const area of config.AREAS) {
  picks[area.key] = await helpers.pickMultiArea(area.folder, area.label, areas[area.key]);
}

// PRODUCT ID — pass the chosen program/type CODES plus the 2-digit year.
const yy        = tp.date.now("YY");
const productId = helpers.nextProductId(program.code, type.code, yy);

// FILE PLACEMENT — give the note its own folder so Folder Notes pairs them,
// named by product ID only:  <parent>/ASG26001/ASG26001.md
const parent     = tp.file.folder(true);
const folderPath = (parent ? parent + "/" : "") + productId;
try { await app.vault.createFolder(folderPath); } catch (e) { /* already exists — fine */ }
await tp.file.move(folderPath + "/" + productId);
-%>
---
tracker: product
tags: [task]
cssclasses: [product]
product_id: <% productId %>
program: <% program.code %>
title: <% title %>
status: <% status.name %>
priority: <% priority.name %>
product_type: <% type.code %>
mission: <% helpers.yamlLinks(picks.mission) %>
customer: <% helpers.yamlLinks(picks.customer) %>
country: <% helpers.yamlLinks(picks.country) %>
target: <% helpers.yamlLinks(picks.target) %>
classification: <% marking %>
created: <% tp.date.now("YYYY-MM-DD") %>
due: <% due %>
done:
time_pre_min: 0
time_prod_min: 0
time_post_min: 0
notes:
sourcing:
coordination:
feedback:
---

# <% productId %> — <% title %>

````ad-note
title: Missions
color: 94, 165, 218
<!-- Attached missions only. View logic lives in the reusable base file
     "_Views/Product — Missions.base". When embedded, `this` resolves to THIS
     product note, so the per-product filter still works. Edit the .base once to
     change columns/filters for every product. Toolbar hidden via production.css. -->
![[Product — Missions.base]]
````

````ad-note
title: Targets
color: 94, 165, 218
<!-- Attached targets only. View logic lives in "_Views/Product — Targets.base";
     `this` resolves to this product note when embedded. Edit the .base once to
     change it for every product. Toolbar hidden via production.css. -->
![[Product — Targets.base]]
````

````ad-note
title: Controls
color: 40, 93, 171
**Status** `INPUT[inlineSelect(option(Inbox), option(Backlog), option(Preproduction), option(Production), option(Postproduction), option(Draft), option(Published), option(Archived)):status]` · **Done** `INPUT[date:done]` · `BUTTON[mark-published]` `BUTTON[t-reset]`
````

```meta-bind-button
label: "✅ Mark Published"
hidden: true
style: primary
class: mb-brand-primary
id: "mark-published"
actions:
  - type: updateMetadata
    bindTarget: status
    evaluate: false
    value: "Published"
  - type: updateMetadata
    bindTarget: done
    evaluate: true
    value: new Date().toLocaleDateString('en-CA')
```

<!-- Combined Time + Subtasks, rebuilt with Admonition custom types
     (ad-subtasks / ad-phase). Three phase columns are laid out by production.css
     (its .callout[data-callout="subtasks"/"phase"] grid rules — Admonition emits
     native-callout markup, so they still apply). Each phase shows its task count,
     its minutes with -10 / +10 buttons, and its checklist; the overall "% · x/y"
     readout spans the top of the grid. Per-phase counters key off each box's
     `title:` line. The six hidden time buttons + reset are defined after this.
     NOTE: needs the `subtasks` + `phase` types imported into Admonition
     (admonition-types.json) with their color re-set once in the Edit dialog. -->
`````ad-subtasks
title: Work
color: 40, 93, 171
```js-engine
// Overall readout: every checkbox that sits under a phase title in this block.
const file = context.file;
const A = engine.app || globalThis.app;
const build = async () => {
  const lines = (await A.vault.cachedRead(file)).split("\n");
  const phases = ["Preproduction", "Production", "Postproduction"];
  let done = 0, total = 0, seen = false;
  for (const line of lines) {
    const m = line.match(/^\s*title:\s*(.+?)\s*$/);
    if (m) { seen = phases.includes(m[1]); continue; }
    if (/^\s*`{4,}/.test(line)) { seen = false; continue; }
    if (seen && /^\s*- \[.\]/.test(line)) { total++; if (/\[[xX]\]/.test(line)) done++; }
  }
  const pct = total ? Math.round(done / total * 100) : 0;
  const fm = A.metadataCache.getFileCache(file)?.frontmatter || {};
  const mins = (Number(fm.time_pre_min) || 0) + (Number(fm.time_prod_min) || 0) + (Number(fm.time_post_min) || 0);
  const hm = (mins >= 60 ? Math.floor(mins / 60) + "h " : "") + (mins % 60) + "m";
  return engine.markdown.create("**" + pct + "%** · " + done + "/" + total + " done · " + hm);
};
const comp = engine.reactive(build);
component.registerEvent(A.metadataCache.on("changed", (f) => { if (f && f.path === file.path) comp.refresh(); }));
return comp;
```

````ad-phase
title: Preproduction
color: 241, 220, 170
```js-engine
// Count only this phase's checkboxes (between its title and the box's close).
const file = context.file;
const A = engine.app || globalThis.app;
const phase = "Preproduction";
const build = async () => {
  const lines = (await A.vault.cachedRead(file)).split("\n");
  let done = 0, total = 0, seen = false;
  for (const line of lines) {
    const m = line.match(/^\s*title:\s*(.+?)\s*$/);
    if (m) { seen = (m[1] === phase); continue; }
    if (/^\s*`{4,}/.test(line)) { seen = false; continue; }
    if (seen && /^\s*- \[.\]/.test(line)) { total++; if (/\[[xX]\]/.test(line)) done++; }
  }
  return engine.markdown.create("**" + done + "/" + total + "**");
};
const comp = engine.reactive(build);
component.registerEvent(A.metadataCache.on("changed", (f) => { if (f && f.path === file.path) comp.refresh(); }));
return comp;
```
`VIEW[{time_pre_min}]`m · `BUTTON[t-pre-sub]` `BUTTON[t-pre-add]`

- [ ] Obsidian
- [ ] Project
- [ ] Files
````

````ad-phase
title: Production
color: 249, 166, 63
```js-engine
const file = context.file;
const A = engine.app || globalThis.app;
const phase = "Production";
const build = async () => {
  const lines = (await A.vault.cachedRead(file)).split("\n");
  let done = 0, total = 0, seen = false;
  for (const line of lines) {
    const m = line.match(/^\s*title:\s*(.+?)\s*$/);
    if (m) { seen = (m[1] === phase); continue; }
    if (/^\s*`{4,}/.test(line)) { seen = false; continue; }
    if (seen && /^\s*- \[.\]/.test(line)) { total++; if (/\[[xX]\]/.test(line)) done++; }
  }
  return engine.markdown.create("**" + done + "/" + total + "**");
};
const comp = engine.reactive(build);
component.registerEvent(A.metadataCache.on("changed", (f) => { if (f && f.path === file.path) comp.refresh(); }));
return comp;
```
`VIEW[{time_prod_min}]`m · `BUTTON[t-prod-sub]` `BUTTON[t-prod-add]`

- [ ] Cut
- [ ] Stab
- [ ] Color
- [ ] Build
- [ ] Draft
````

````ad-phase
title: Postproduction
color: 205, 88, 33
```js-engine
const file = context.file;
const A = engine.app || globalThis.app;
const phase = "Postproduction";
const build = async () => {
  const lines = (await A.vault.cachedRead(file)).split("\n");
  let done = 0, total = 0, seen = false;
  for (const line of lines) {
    const m = line.match(/^\s*title:\s*(.+?)\s*$/);
    if (m) { seen = (m[1] === phase); continue; }
    if (/^\s*`{4,}/.test(line)) { seen = false; continue; }
    if (seen && /^\s*- \[.\]/.test(line)) { total++; if (/\[[xX]\]/.test(line)) done++; }
  }
  return engine.markdown.create("**" + done + "/" + total + "**");
};
const comp = engine.reactive(build);
component.registerEvent(A.metadataCache.on("changed", (f) => { if (f && f.path === file.path) comp.refresh(); }));
return comp;
```
`VIEW[{time_post_min}]`m · `BUTTON[t-post-sub]` `BUTTON[t-post-add]`

- [ ] Render
- [ ] Review
- [ ] Publish
````
`````

<!-- Time buttons (hidden): each phase gets a -10 and a +10 that adjust its
     minutes. To change the step size, edit the `value:` line. Do not reuse an id. -->

```meta-bind-button
label: "-10"
hidden: true
id: "t-pre-sub"
style: default
class: mb-brand-step
action:
  type: updateMetadata
  bindTarget: time_pre_min
  evaluate: true
  value: Math.max(x - 10, 0)
```
```meta-bind-button
label: "+10"
hidden: true
id: "t-pre-add"
style: default
class: mb-brand-step
action:
  type: updateMetadata
  bindTarget: time_pre_min
  evaluate: true
  value: x + 10
```
```meta-bind-button
label: "-10"
hidden: true
id: "t-prod-sub"
style: default
class: mb-brand-step
action:
  type: updateMetadata
  bindTarget: time_prod_min
  evaluate: true
  value: Math.max(x - 10, 0)
```
```meta-bind-button
label: "+10"
hidden: true
id: "t-prod-add"
style: default
class: mb-brand-step
action:
  type: updateMetadata
  bindTarget: time_prod_min
  evaluate: true
  value: x + 10
```
```meta-bind-button
label: "-10"
hidden: true
id: "t-post-sub"
style: default
class: mb-brand-step
action:
  type: updateMetadata
  bindTarget: time_post_min
  evaluate: true
  value: Math.max(x - 10, 0)
```
```meta-bind-button
label: "+10"
hidden: true
id: "t-post-add"
style: default
class: mb-brand-step
action:
  type: updateMetadata
  bindTarget: time_post_min
  evaluate: true
  value: x + 10
```
```meta-bind-button
label: "Reset time"
hidden: true
id: "t-reset"
style: destructive
class: mb-brand-danger
actions:
  - type: updateMetadata
    bindTarget: time_pre_min
    evaluate: false
    value: 0
  - type: updateMetadata
    bindTarget: time_prod_min
    evaluate: false
    value: 0
  - type: updateMetadata
    bindTarget: time_post_min
    evaluate: false
    value: 0
```

````ad-note
title: Notes
color: 94, 165, 218
```meta-bind
INPUT[textArea:notes]
```
````

````ad-note
title: Sourcing / Collection
color: 94, 165, 218
```meta-bind
INPUT[textArea:sourcing]
```
````

````ad-note
title: Coordination / Tasking
color: 94, 165, 218
```meta-bind
INPUT[textArea:coordination]
```
````

````ad-note
title: Feedback / Revisions
color: 94, 165, 218
```meta-bind
INPUT[textArea:feedback]
```
````

````ad-note
title: Journal
color: 94, 165, 218
- <% tp.date.now("YYYY-MM-DD HH:mm") %> — created.
````
