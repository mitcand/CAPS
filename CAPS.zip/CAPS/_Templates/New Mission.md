<%*
// New Mission — a reference "Area" that Products link to. Requires Templater.
// The Mission ID is entered by you (not auto-generated).
const mission_id       = await tp.system.prompt("Mission ID (you assign this)");
const flight_number    = await tp.system.prompt("Flight number", "", false);
const platform         = await tp.system.prompt("Platform (e.g. MQ-9)", "", false);
const takeoff_date     = await tp.system.prompt("Takeoff date (YYYY-MM-DD)", tp.date.now("YYYY-MM-DD"), false);
const land_date        = await tp.system.prompt("Landing date (YYYY-MM-DD, blank = none)", "", false);
const takeoff_location = await tp.system.prompt("Takeoff location", "", false);
const land_location    = await tp.system.prompt("Landing location", "", false);

// Name the file by Mission ID (+ flight number if given) so it's readable in links/sidebar.
await tp.file.rename(mission_id + (flight_number ? " FL" + flight_number : ""));
-%>
---
tracker: mission
tags: [area, mission]
mission_id: <% mission_id %>
flight_number: <% flight_number %>
platform: <% platform %>
takeoff_date: <% takeoff_date %>
land_date: <% land_date %>
takeoff_location: <% takeoff_location %>
land_location: <% land_location %>
created: <% tp.date.now("YYYY-MM-DD") %>
---

# <% mission_id %><% flight_number ? " — Flight " + flight_number : "" %>

- **Platform:** <% platform %>
- **Takeoff:** <% takeoff_date %> — <% takeoff_location %>
- **Landing:** <% land_date %> — <% land_location %>

## Products from this mission
Linked Products appear in the **backlinks** pane (they set `mission: [[<% mission_id %><% flight_number ? " FL" + flight_number : "" %>]]`).
