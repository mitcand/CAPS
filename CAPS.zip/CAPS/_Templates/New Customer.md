<%*
// New Customer — a reference "Area" that Products link to. Requires Templater.
// The Center ID is entered by you (not auto-generated).
const name      = await tp.system.prompt("Customer name / short label (e.g. J2)");
const center_id = await tp.system.prompt("Center ID (you assign this)", "", false);
const poc       = await tp.system.prompt("POC — point of contact", "", false);

// Name the file "<Center ID> <name>" (falls back to just the name if no Center ID).
await tp.file.rename(center_id ? center_id + " " + name : name);
-%>
---
tracker: customer
tags: [area, customer]
name: <% name %>
center_id: <% center_id %>
poc: <% poc %>
created: <% tp.date.now("YYYY-MM-DD") %>
---

# <% name %><% center_id ? " (" + center_id + ")" : "" %>

- **Center ID:** <% center_id %>
- **POC:** <% poc %>

## Products for this customer
Linked Products appear in the **backlinks** pane.
