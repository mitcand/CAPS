<%*
// New Target — a reference "Area" that Products link to. Requires Templater.
// The Target ID is entered by you (not auto-generated).
const target_name = await tp.system.prompt("Target name");
const target_id   = await tp.system.prompt("Target ID (you assign this)");
const coordinates = await tp.system.prompt("Coordinates (lat, long)", "", false);
// Templater can't upload files — drag the image into the vault first, then type its filename here.
const image       = await tp.system.prompt("Image filename (e.g. apron.jpg; blank to add later)", "", false);

// Name the file "<Target ID> <name>".
await tp.file.rename(target_id + " " + target_name);
-%>
---
tracker: target
tags: [area, target]
target_name: <% target_name %>
target_id: <% target_id %>
coordinates: <% coordinates %>
image: <% image ? "\"[[" + image + "]]\"" : "" %>
created: <% tp.date.now("YYYY-MM-DD") %>
---

# <% target_id %> — <% target_name %>

- **Coordinates:** <% coordinates %>

## Imagery
<% image ? "![[" + image + "]]" : "> Drag the target image into this note, then set the `image:` field to its filename." %>

## Products against this target
Linked Products appear in the **backlinks** pane.
