// ══════════════════════════════════════════════════════════════════════
// AREAS  —  how to CREATE a brand-new note for each area type
//
// config.js lists WHERE each area lives (folder/label); this file holds the
// prompts + fields for making a new one. The two pair up by KEY: every key
// here must match a `key` in config.js's AREAS list.
//
// Loaded as a Templater user script:  tp.user.areas(tp, helpers)
//   tp      — Templater, for the tp.system.prompt pop-ups
//   helpers — so each create() can call helpers.createNote(...)
// Because tp and helpers are handed in here once, each create() below only
// needs (folder): where to save the note (this area's folder from config.js).
//
// To add an area: add a create() here AND a matching row in config.js.
// Each create() should build the note's filename in `base`, then return
// helpers.createNote(folder, base, { ...front-matter fields... }).
// ══════════════════════════════════════════════════════════════════════
function getAreas(tp, helpers) {
  return {

    mission: async (folder) => {
      const id       = await tp.system.prompt("Mission ID");
      const flight   = await tp.system.prompt("Flight number", "", false);
      const platform = await tp.system.prompt("Platform", "", false);
      const base     = id + (flight ? " FL" + flight : "");
      return helpers.createNote(folder, base, {
        tracker: "mission",
        tags: ["area", "mission"],
        mission_id: id,
        flight_number: flight,
        platform: platform,
        takeoff_date: "",
        land_date: "",
        takeoff_location: "",
        land_location: "",
      });
    },

    customer: async (folder) => {
      const name     = await tp.system.prompt("Customer name/label (e.g. J2)");
      const centerId = await tp.system.prompt("Center ID", "", false);
      const poc      = await tp.system.prompt("POC", "", false);
      const base     = centerId ? centerId + " " + name : name;
      return helpers.createNote(folder, base, {
        tracker: "customer",
        tags: ["area", "customer"],
        name: name,
        center_id: centerId,
        poc: poc,
      });
    },

    country: async (folder) => {
      const name = await tp.system.prompt("Country name");
      const code = await tp.system.prompt("Country code (ISO, e.g. CAN)");
      const base = code + " " + name;
      return helpers.createNote(folder, base, {
        tracker: "country",
        tags: ["area", "country"],
        country_name: name,
        country_code: code,
      });
    },

    target: async (folder) => {
      const name   = await tp.system.prompt("Target name");
      const id     = await tp.system.prompt("Target ID");
      const coords = await tp.system.prompt("Coordinates", "", false);
      const base   = id + " " + name;
      return helpers.createNote(folder, base, {
        tracker: "target",
        tags: ["area", "target"],
        target_name: name,
        target_id: id,
        coordinates: coords,
        image: "",
      });
    },

  };
}

module.exports = getAreas;
