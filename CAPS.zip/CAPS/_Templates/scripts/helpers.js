function getHelpers(tp) {
  const helpers = {

    // ── yamlValue(value) → string ─────────────────────────────────────
    // Format ONE front-matter value. If it's an array, write it inline as
    // [a, b]; otherwise return it as-is (empty string = blank field).
    yamlValue: function (value) {
      if (Array.isArray(value)) {
        return "[" + value.join(", ") + "]";
      }
      return value;
    },
    
    // ── yamlLinks(arr) → string ───────────────────────────────────────
    // Turn an array of note basenames into a multi-line YAML list of quoted
    // wiki-links (what the mission/customer/country/target fields need):
    //     \n  - "[[Name]]"  per item.  Empty/missing array → "".
    yamlLinks: function (arr) {
      if (!arr || arr.length === 0) return "";
      return arr.map(n => "\n  - \"[[" + n + "]]\"").join("");
    },

    // ── createNote(folder, base, fields) → basename ───────────────────
    // If no note exists at folder/base.md, create one with front-matter
    // built from `fields` (+ a created date). Return the basename either
    // way so a picker can link to it. Uses yamlValue for each field.
    createNote: async function (folder, base, fields) {
      const path = folder + "/" + base + ".md";
      if (!app.vault.getAbstractFileByPath(path)) {
        const lines = Object.entries(fields).map(([key, value]) => key + ": " + helpers.yamlValue(value));
        lines.push("created: " + tp.date.now("YYYY-MM-DD"));
        await app.vault.create(path, "---\n" + lines.join("\n") + "\n---\n\n# " + base + "\n");
      }
      return base;
    },

    // ── pickMultiArea(folder, label, createFn) → [basenames] ──────────
    // Loop a suggester so the operator attaches one OR MORE notes from
    // `folder`. "✓ done" ends; "➕ Create new…" runs createFn. Already-picked
    // notes drop out of the list. Return the array of chosen basenames.
    pickMultiArea: async function (folder, label, createFn) {
      const picked = [];
      while (true) {
        const names = app.vault.getMarkdownFiles()
          .filter(f => f.path.startsWith(folder + "/"))
          .map(f => f.basename)
          .filter(n => !picked.includes(n))
          .sort();
        const DONE = "✓ done" + (picked.length ? " — " + picked.length + " selected" : " — none");
        const NEW  = "➕ Create new " + label + "…";
        const opts = [DONE, NEW, ...names];
        const prompt = label + (picked.length ? " (add another, or ✓ done)" : " (pick one or more)");
        const pick = await tp.system.suggester(opts, opts, false, prompt);
        if (pick == null || pick === DONE) break;
        if (pick === NEW) { picked.push(await createFn(folder)); continue; }
        picked.push(pick);
      }
      return picked;
    },

    // ── pickOne(list, label) → chosen item ────────────────────────────
    // Single-select picker for a config list (STATUSES, PROGRAMS, ...).
    // Shows each item as "Name (code)" — or "Name (value)" for lists that use
    // value — but returns the WHOLE item object, so the caller can still read
    // .name and .code / .value.
    pickOne: async function (list, label) {
      const display = (item) => {
        const tag = item.code != null ? item.code : item.value;
        return tag != null ? "(" + tag + ") " + item.name : item.name;
      };
      return await tp.system.suggester(display, list, false, label);
    },

    // ── nextProductId(program, typeCode, yy) → id string ──────────────
    // Scan the vault for this year's product IDs and return the next one:
    // <program><typeCode><yy><seq:3>, e.g. "ASG26001". Sequence is GLOBAL
    // across programs/types and resets each year. Vault = source of truth.
    nextProductId: function (program, typeCode, yy) {
      const yearRe = new RegExp("^[A-Za-z]{3}" + yy + "(\\d{3})$");
      let maxSeq = 0;
      for (const f of app.vault.getMarkdownFiles()) {
        const fm = app.metadataCache.getFileCache(f)?.frontmatter;
        const candidates = [fm?.product_id, f.basename.split(" ")[0]];
        for (const c of candidates) {
          if (typeof c !== "string") continue;
          const m = c.match(yearRe);
          if (m) {
            const n = parseInt(m[1], 10);
            if (n > maxSeq) maxSeq = n;
          }
        }
      }
      return program + typeCode + yy + String(maxSeq + 1).padStart(3, "0");
    },
  };

  return helpers;
}

module.exports = getHelpers;
