function getConfig() {
  return {
    // PROGRAM LIST
    PROGRAMS: [
    { name: "Alpha", code: "A" },
    { name: "Bravo", code: "B" },
    { name: "Codec", code: "C" }
    ],
    // PRODUCT TYPES
    TYPE_CODES: [
    { name: "Significant Observation",   code: "SG" },
    { name: "Analysis Enhancement",      code: "AE" },
    { name: "Target Rollup",             code: "TR" },
    { name: "Mission Summary",           code: "MS" },
    { name: "Special Project",           code: "SP" },
    { name: "Drone Safari",              code: "DS" }
    ],
    // STATUSES
    STATUSES: [
    { name: "Inbox",          value: 1 },
    { name: "Preproduction",  value: 2 },
    { name: "Production",     value: 3 },
    { name: "Postproduction", value: 4 },
    { name: "Draft",          value: 5 },
    { name: "Published",      value: 6 },
    { name: "Backlog",        value: 7 },
    { name: "Archived",       value: 8 }
    ],
    // PRIORITIES
    PRIORITIES: [
    { name: "Routine",    value: 3 },
    { name: "Priority",   value: 2 },
    { name: "Immediate",  value: 1 }
    ],
    // AREA DEFINITIONS
    // Each product can link MULTIPLE notes from each area below.
    //   key    — must MATCH a create() in areas.js (that's how they pair up)
    //   folder — where this area's notes live
    //   label  — what the operator sees in the picker
    // To add an area: add a row here AND a matching create() in areas.js.
    AREAS: [
    { key: "mission",  folder: "Areas/Missions",  label: "Mission"  },
    { key: "customer", folder: "Areas/Customers", label: "Customer" },
    { key: "country",  folder: "Areas/Countries", label: "Country"  },
    { key: "target",   folder: "Areas/Targets",   label: "Target"   },
    ]
  };
}

module.exports = getConfig;