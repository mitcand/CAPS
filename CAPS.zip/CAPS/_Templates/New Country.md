<%*
// New Country — a reference "Area" that Products link to. Requires Templater.
// Country code is the standard ISO code (you enter it).
const country_name = await tp.system.prompt("Country name");
const country_code = await tp.system.prompt("Country code (ISO, e.g. US or USA)");

// Name the file "<CODE> <name>" — e.g. "US United States".
await tp.file.rename(country_code + " " + country_name);
-%>
---
tracker: country
tags: [area, country]
country_name: <% country_name %>
country_code: <% country_code %>
created: <% tp.date.now("YYYY-MM-DD") %>
---

# <% country_code %> — <% country_name %>

## Products in this country
Linked Products appear in the **backlinks** pane.
