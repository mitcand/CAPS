---
tracker: reference
tags: [setup, manual]
title: Build Manual — Production Tracking Vault
created: 2026-06-30
---

# Build Manual — Production Tracking Vault (from scratch)

This manual rebuilds the entire system in a fresh Obsidian vault: auto-numbered **Products**
(`AVD26001`), four **Area** registries (Missions, Customers, Countries, Targets) that Products
link to, intake **templates + buttons**, and **Bases** dashboards.

Follow the steps top to bottom. Every file's full contents are included — create the file at the
given path and paste the block.

> **Note on the code blocks below:** each file is shown wrapped in a 4-backtick fence (` ```` `).
> When a file's own content contains 3-backtick fences (the dashboards and Bases blocks), paste
> only the **inside** — i.e. everything between the outer 4-backtick lines.

---

## 0. What you're building

**Model:** one entity — a **Product** *is* the task (one deliverable per job). Products link to
reference **Areas**. Product IDs are auto-generated and unique; Area IDs are typed by you.

**Product ID format:** `<program:1><type:2><year:2><seq:3>` → e.g. `AVD26001`
= program **A**, video (**VD**), year **2026**, sequence **001**. The sequence is global across all
programs/types and **resets each calendar year**.

**Final folder layout:**

```
VaultRoot/
├── _Templates/
│   ├── New Product.md
│   ├── New Mission.md
│   ├── New Customer.md
│   ├── New Country.md
│   └── New Target.md
├── _Views/
│   ├── Production — Work.base
│   └── Production — Metrics.base
├── Production/
│   ├── Production.md          ← dashboard + New Product button
│   └── AVD26001 Title/        ← each Product is its OWN folder …
│       └── AVD26001 Title.md  ← … with a same-named folder note (attachments live beside it)
├── Areas/
│   ├── Areas.md               ← dashboard + 4 buttons + registries
│   ├── Missions/
│   ├── Customers/
│   ├── Countries/
│   └── Targets/
├── .obsidian/snippets/
│   └── production.css         ← layout + info-box styling (full-width [Minimal-safe], subtasks, boxes)
├── _Setup — Product Codes.md  ← where to change placeholder codes
└── _Manual — Build From Scratch.md  ← this file
```

---

## 1. Prerequisites & plugins

1. Install **Obsidian 1.9+** (the **Bases** core plugin ships with it).
2. **Settings → Core plugins →** enable **Bases**.
3. **Settings → Community plugins → Browse**, install + enable:
   - **Templater** (`templater-obsidian`) — the prompt-driven intake templates.
   - **Meta Bind** (`obsidian-meta-bind-plugin`) — the clickable creation buttons + in-note controls.
   - **Folder Notes** (`folder-notes`) — makes `Production/` and `Areas/` open their dashboard note, and
     makes each **Product folder** open its folder note (settings: `folderNoteName = {{folder_name}}`,
     storage **inside folder**, **hide folder note** on).
   - **Homepage** (`homepage`) — opens the Production dashboard automatically at launch.
   - **JS Engine** (`js-engine`) — powers Meta Bind `evaluate: true` expressions: the per-phase time
     **+15 / +30 / -15** buttons, the **Publish** button's auto-date stamp, and the live time-breakdown
     display. Made by the same author as Meta Bind. It's a *convenience layer over durable frontmatter* —
     if it's ever removed, your recorded minutes stay safe in YAML; only the buttons/display stop working.
4. **No task plugin.** Subtasks are plain checkboxes — no TaskNotes / Obsidian Tasks. Time is tracked in
   frontmatter via Meta Bind buttons (see §4), not a timer plugin.

---

## 2. Plugin configuration

**Templater** — Settings → Templater:
- **Template folder location:** `_Templates`
- Leave "Trigger Templater on new file creation" **off** (we trigger via buttons/commands, which
  avoids the template running on *every* new note).
- *(Optional)* under **Template Hotkeys**, add `_Templates/New Product.md` to get a bindable command.

**Meta Bind** — Settings → Meta Bind:
- Ensure **buttons** are enabled. Turn on **"Render buttons in live preview"** if you want the
  buttons clickable without switching to Reading view.

**Bases** — no config needed; the `.base` files and embedded ```` ```base ```` blocks just work.

**Folder Notes** — enable folder-note behavior (folder-name-matches-note) so clicking `Production/` opens
`Production.md` and `Areas/` opens `Areas.md`.

**Homepage** — set **Homepage** to `Production/Production` (or `Welcome`) and enable **Open on startup**, so
every launch lands on the dashboard.

**Appearance (CSS snippet)** — after you create `.obsidian/snippets/production.css` (§8c), go to
**Settings → Appearance → CSS snippets**, click **refresh**, and toggle **`production`** on. Optional/cosmetic.

---

## 3. Create the folders

Create these empty folders now (so the buttons have somewhere to write):

```
_Templates/
_Views/
Production/
Areas/
Areas/Missions/
Areas/Customers/
Areas/Countries/
Areas/Targets/
```

---

## 4. The Product template (auto-numbered)

Create **`_Templates/New Product.md`**:

> **Note:** this template also carries `cssclasses: [product]` (targeted by the
> `.obsidian/snippets/production.css` snippet for full-width, 3-column subtasks, and the free-text
> info boxes) and a Meta Bind control bar. It has **no** `requester` / `blocked` / `software_used`
> fields — those were dropped from the schema.
> The four Area pickers (Mission / Customer / Country / Target) are **multi-select** — each product
> can hold **one or more** of each. Keep picking, then choose **✓ done**; the pickers can also
> **create a new Area inline** ("➕ Create new …"), and the chosen values are written as YAML lists.
> The body also has four **free-text info boxes** — **Notes**, **Sourcing / Collection**,
> **Coordination / Tasking**, **Feedback / Revisions** — Meta Bind text areas editable in **Reading
> view**. They store into hidden `notes` / `sourcing` / `coordination` / `feedback` fields that the
> CSS snippet keeps out of the properties UI.
> The **Time** section tracks per-phase effort via `+15/+30/-15` buttons with a live total (h/m) + share %,
> and the **Subtasks** callout carries a **JS Engine progress bar** (done/total + %) that recounts its
> checkboxes live as you tick them. Both need the JS Engine plugin.

````text
<%*
/* ══════════════════════════════════════════════════════════════════════
   NEW PRODUCT  —  intake template (requires Templater)

   Prompts the operator for every field so the YAML is never hand-edited.
   Bind to a hotkey, or use the "➕ New Product" Meta Bind button.

   To maintain this template you normally only touch two sections below:
     • CONFIG            — the product-ID scheme (programs / type codes)
     • LISTS & SELECTORS — every drop-down pick-list and area definition
   ══════════════════════════════════════════════════════════════════════ */


// ══════════════════════════════════════════════════════════════════════
// CONFIG  — edit these to match your shop
// ══════════════════════════════════════════════════════════════════════
//   Product ID format:  <program:1><type:2><year:2><seq:3>
//     e.g.  A + VD + 26 + 001  ->  AVD26001
//   The sequence is GLOBAL across all programs/types and RESETS each year.
const PROGRAMS   = ["A", "B", "C"];
const TYPE_CODES = { video: "VD", graphic: "GR", map: "MP", report: "RP" };


// ══════════════════════════════════════════════════════════════════════
// LISTS & SELECTORS  — every pick-list lives here; add/remove items freely
// ══════════════════════════════════════════════════════════════════════
const STATUSES   = ["Inbox","Backlog","Preproduction","Production","Postproduction","Draft","Published","Archived"];
const PRIORITIES = ["routine","priority","immediate"];

// AREAS — each product can link MULTIPLE notes from each of these folders.
//
// To add a new area, copy one entry below and change:
//   key    — the front-matter field it fills in (see the YAML at the bottom)
//   folder — where its notes live
//   label  — what the operator sees in the picker
//   create — the prompts for a brand-new note, plus the fields to save.
//
// In create(), each `fields` line is just  fieldName: value  — no quotes or
// line breaks to get right. Leave a value as "" for a field the operator
// fills in later, and use [ ... ] for a list (like tags).
const AREAS = [
  {
    key: "mission", folder: "Areas/Missions", label: "Mission",
    create: async (folder) => {
      const id   = await tp.system.prompt("New Mission — Mission ID");
      const fl   = await tp.system.prompt("Flight number (optional)", "", false);
      const plat = await tp.system.prompt("Platform (optional)", "", false);
      const base = id + (fl ? " FL" + fl : "");          // note title, e.g. "M123 FL07"
      return createNote(folder, base, {
        tracker: "mission",
        tags: ["area", "mission"],
        mission_id: id,
        flight_number: fl,
        platform: plat,
        takeoff_date: "",
        land_date: "",
        takeoff_location: "",
        land_location: "",
      });
    },
  },
  {
    key: "customer", folder: "Areas/Customers", label: "Customer",
    create: async (folder) => {
      const name = await tp.system.prompt("New Customer — name/label (e.g. J2)");
      const cid  = await tp.system.prompt("Center ID (optional)", "", false);
      const poc  = await tp.system.prompt("POC (optional)", "", false);
      const base = cid ? cid + " " + name : name;
      return createNote(folder, base, {
        tracker: "customer",
        tags: ["area", "customer"],
        name: name,
        center_id: cid,
        poc: poc,
      });
    },
  },
  {
    key: "country", folder: "Areas/Countries", label: "Country",
    create: async (folder) => {
      const cname = await tp.system.prompt("New Country — name");
      const ccode = await tp.system.prompt("Country code (ISO, e.g. CAN)");
      const base  = ccode + " " + cname;
      return createNote(folder, base, {
        tracker: "country",
        tags: ["area", "country"],
        country_name: cname,
        country_code: ccode,
      });
    },
  },
  {
    key: "target", folder: "Areas/Targets", label: "Target",
    create: async (folder) => {
      const tname = await tp.system.prompt("New Target — name");
      const tid   = await tp.system.prompt("Target ID");
      const coord = await tp.system.prompt("Coordinates (optional)", "", false);
      const base  = tid + " " + tname;
      return createNote(folder, base, {
        tracker: "target",
        tags: ["area", "target"],
        target_name: tname,
        target_id: tid,
        coordinates: coord,
        image: "",
      });
    },
  },
];


// ══════════════════════════════════════════════════════════════════════
// FUNCTIONS  — reusable helpers; nothing here runs until it's called below
// ══════════════════════════════════════════════════════════════════════
const today = tp.date.now("YYYY-MM-DD");

// Format one front-matter value: a list becomes [a, b]; anything else is
// written as-is (an empty string just leaves the field blank).
function yamlValue(value) {
  return Array.isArray(value) ? "[" + value.join(", ") + "]" : value;
}

// Inline note creator — if no note exists yet at folder/base.md, build one
// whose front-matter comes from the `fields` object (plus a created date).
// Returns the note's basename either way, so the picker can link to it.
async function createNote(folder, base, fields) {
  const path = folder + "/" + base + ".md";
  if (!app.vault.getAbstractFileByPath(path)) {
    const lines = Object.entries(fields).map(([key, value]) => key + ": " + yamlValue(value));
    lines.push("created: " + today);
    await app.vault.create(path, "---\n" + lines.join("\n") + "\n---\n\n# " + base + "\n");
  }
  return base;
}

// Repeatedly show a suggester so the operator can attach one or more notes
// from `folder`. "✓ done" ends the loop; "➕ Create new…" runs createFn.
// Already-picked notes drop out of the list so they can't be added twice.
async function pickMultiArea(folder, label, createFn) {
  const picked = [];
  while (true) {
    const names = app.vault.getMarkdownFiles()
      .filter(f => f.path.startsWith(folder + "/"))
      .map(f => f.basename)
      .filter(n => !picked.includes(n))
      .sort();
    const DONE = "✓ done" + (picked.length ? " — " + picked.length + " selected" : " — none");
    const NEW  = "➕ Create new " + label + "…";
    const opts = [DONE, NEW, ...names];
    const prompt = label + (picked.length ? " (add another, or ✓ done)" : " (pick one or more)");
    const pick = await tp.system.suggester(opts, opts, false, prompt);
    if (pick == null || pick === DONE) break;
    if (pick === NEW) { picked.push(await createFn(folder)); continue; }
    picked.push(pick);
  }
  return picked;
}

// Render an array of note basenames as a YAML list of wiki-links
// (empty array collapses the field to null).
function yamlLinks(arr) {
  if (!arr || arr.length === 0) return "";
  return arr.map(n => "\n  - \"[[" + n + "]]\"").join("");
}

// Next sequential product ID: scan every note for this year's IDs and add 1.
// The vault itself is the source of truth, so sequences survive across sessions.
function nextProductId(program, typeCode, yy) {
  const yearRe = new RegExp("^[A-Za-z]{3}" + yy + "(\\d{3})$");
  let maxSeq = 0;
  for (const f of app.vault.getMarkdownFiles()) {
    const fm = app.metadataCache.getFileCache(f)?.frontmatter;
    const candidates = [fm?.product_id, f.basename.split(" ")[0]];
    for (const c of candidates) {
      if (typeof c !== "string") continue;
      const m = c.match(yearRe);
      if (m) { const n = parseInt(m[1], 10); if (n > maxSeq) maxSeq = n; }
    }
  }
  return program + typeCode + yy + String(maxSeq + 1).padStart(3, "0");
}


// ══════════════════════════════════════════════════════════════════════
// FIELD ENTRY  — prompt the operator for every product field
// ══════════════════════════════════════════════════════════════════════
const status         = await tp.system.suggester(STATUSES, STATUSES, false, "Status");
const priority       = await tp.system.suggester(PRIORITIES, PRIORITIES, false, "Priority");
const program        = await tp.system.suggester(PROGRAMS, PROGRAMS, false, "Program code");
const ptype          = await tp.system.suggester(Object.keys(TYPE_CODES), Object.keys(TYPE_CODES), false, "Product type");
const typeCode       = TYPE_CODES[ptype];
const platform       = await tp.system.prompt("Collection platform", "", false);
const classification = await tp.system.prompt("Classification marking", "UNCLASSIFIED");
const due            = await tp.system.prompt("Due date (YYYY-MM-DD, blank = none)", "", false);
const title          = await tp.system.prompt("Short title");

// Attach linked area notes. Results are keyed by AREAS[].key — e.g.
// picks.mission — and consumed by yamlLinks(...) in the YAML below.
const picks = {};
for (const area of AREAS) picks[area.key] = await pickMultiArea(area.folder, area.label, area.create);


// ══════════════════════════════════════════════════════════════════════
// ID + FILE PLACEMENT
// ══════════════════════════════════════════════════════════════════════
const yy        = tp.date.now("YY");
const productId = nextProductId(program, typeCode, yy);

// Move the note into its own folder so Folder Notes turns it into a folder +
// folder note:  <parent>/AVD26001 Title/AVD26001 Title.md
const productName = productId + " " + title;
const parent      = tp.file.folder(true);                  // e.g. "Production"
const folderPath  = (parent ? parent + "/" : "") + productName;
try { await app.vault.createFolder(folderPath); } catch (e) { /* folder already exists — fine */ }
await tp.file.move(folderPath + "/" + productName);
-%>
---
tracker: product
tags: [task]
cssclasses: [product]
product_id: <% productId %>
program: <% program %>
title: <% title %>
status: <% status %>
priority: <% priority %>
product_type: <% ptype %>
collection_platform: <% platform %>
mission:<% yamlLinks(picks.mission) %>
customer:<% yamlLinks(picks.customer) %>
country:<% yamlLinks(picks.country) %>
target:<% yamlLinks(picks.target) %>
duration_sec:
classification: <% classification %>
created: <% tp.date.now("YYYY-MM-DD") %>
due: <% due %>
done:
time_pre_min: 0
time_prod_min: 0
time_post_min: 0
notes:
sourcing:
coordination:
feedback:
---

# <% productId %> — <% title %>

## Controls
**Status** `INPUT[inlineSelect(option(Inbox), option(Backlog), option(Preproduction), option(Production), option(Postproduction), option(Draft), option(Published), option(Archived)):status]` · **Done** `INPUT[date:done]`

```meta-bind-button
label: "✅ Mark Published"
style: primary
id: "mark-published"
actions:
  - type: updateMetadata
    bindTarget: status
    evaluate: false
    value: "Published"
  - type: updateMetadata
    bindTarget: done
    evaluate: true
    value: new Date().toLocaleDateString('en-CA')
```

## Time
```meta-bind-js-view
{time_pre_min} as pre
{time_prod_min} as prod
{time_post_min} as post
---
const pre  = Number(context.bound.pre)  || 0;
const prod = Number(context.bound.prod) || 0;
const post = Number(context.bound.post) || 0;
const total = pre + prod + post;
const hm  = m => (m >= 60 ? Math.floor(m / 60) + "h " : "") + (m % 60) + "m";
const pct = m => total ? Math.round(m / total * 100) : 0;
return engine.markdown.create(
  "**Total:** " + hm(total) + "  \n" +
  "Preproduction " + hm(pre) + " (" + pct(pre) + "%) · " +
  "Production " + hm(prod) + " (" + pct(prod) + "%) · " +
  "Postproduction " + hm(post) + " (" + pct(post) + "%)"
);
```

**Preproduction**  `BUTTON[t-pre-sub]` `BUTTON[t-pre-15]` `BUTTON[t-pre-30]`
**Production**  `BUTTON[t-prod-sub]` `BUTTON[t-prod-15]` `BUTTON[t-prod-30]`
**Postproduction**  `BUTTON[t-post-sub]` `BUTTON[t-post-15]` `BUTTON[t-post-30]`
`BUTTON[t-reset]`

<!-- Hidden button defs: one per phase × {-15,+15,+30} plus Reset. bindTarget switches the phase;
     evaluate:true makes `x` the current value. Same block for prod/post with time_prod_min / time_post_min. -->
```meta-bind-button
label: "-15"
hidden: true
id: "t-pre-sub"
style: default
action:
  type: updateMetadata
  bindTarget: time_pre_min
  evaluate: true
  value: Math.max(x - 15, 0)
```
```meta-bind-button
label: "+15"
hidden: true
id: "t-pre-15"
style: default
action:
  type: updateMetadata
  bindTarget: time_pre_min
  evaluate: true
  value: x + 15
```
```meta-bind-button
label: "+30"
hidden: true
id: "t-pre-30"
style: default
action:
  type: updateMetadata
  bindTarget: time_pre_min
  evaluate: true
  value: x + 30
```
```meta-bind-button
label: "-15"
hidden: true
id: "t-prod-sub"
style: default
action:
  type: updateMetadata
  bindTarget: time_prod_min
  evaluate: true
  value: Math.max(x - 15, 0)
```
```meta-bind-button
label: "+15"
hidden: true
id: "t-prod-15"
style: default
action:
  type: updateMetadata
  bindTarget: time_prod_min
  evaluate: true
  value: x + 15
```
```meta-bind-button
label: "+30"
hidden: true
id: "t-prod-30"
style: default
action:
  type: updateMetadata
  bindTarget: time_prod_min
  evaluate: true
  value: x + 30
```
```meta-bind-button
label: "-15"
hidden: true
id: "t-post-sub"
style: default
action:
  type: updateMetadata
  bindTarget: time_post_min
  evaluate: true
  value: Math.max(x - 15, 0)
```
```meta-bind-button
label: "+15"
hidden: true
id: "t-post-15"
style: default
action:
  type: updateMetadata
  bindTarget: time_post_min
  evaluate: true
  value: x + 15
```
```meta-bind-button
label: "+30"
hidden: true
id: "t-post-30"
style: default
action:
  type: updateMetadata
  bindTarget: time_post_min
  evaluate: true
  value: x + 30
```
```meta-bind-button
label: "Reset time"
hidden: true
id: "t-reset"
style: destructive
actions:
  - type: updateMetadata
    bindTarget: time_pre_min
    evaluate: false
    value: 0
  - type: updateMetadata
    bindTarget: time_prod_min
    evaluate: false
    value: 0
  - type: updateMetadata
    bindTarget: time_post_min
    evaluate: false
    value: 0
```

> [!subtasks]+ Subtasks
> ```js-engine
> const file = context.file;
> const A = engine.app || globalThis.app;
> const build = async () => {
>   const text = await A.vault.cachedRead(file);
>   const boxes = text.split("\n").filter(l => /^>\s*- \[.\]/.test(l));
>   const done = boxes.filter(l => /\[[xX]\]/.test(l)).length;
>   const total = boxes.length;
>   const pct = total ? Math.round((done / total) * 100) : 0;
>   const filled = Math.round(pct / 10);
>   const bar = "█".repeat(filled) + "░".repeat(10 - filled);
>   return engine.markdown.create("`" + bar + "` **" + pct + "%** · " + done + "/" + total + " done");
> };
> const comp = engine.reactive(build);
> component.registerEvent(A.metadataCache.on("changed", (f) => { if (f && f.path === file.path) comp.refresh(); }));
> return comp;
> ```
>
> ### Preproduction
> - [ ] Obsidian
> - [ ] Project
> - [ ] Files
>
> ### Production
> - [ ] Cut
> - [ ] Stab
> - [ ] Color
> - [ ] Build
> - [ ] Draft
>
> ### Postproduction
> - [ ] Render
> - [ ] Review
> - [ ] Publish

## Notes
```meta-bind
INPUT[textArea:notes]
```

## Sourcing / Collection
```meta-bind
INPUT[textArea:sourcing]
```

## Coordination / Tasking
```meta-bind
INPUT[textArea:coordination]
```

## Feedback / Revisions
```meta-bind
INPUT[textArea:feedback]
```

## Journal
- <% tp.date.now("YYYY-MM-DD HH:mm") %> — created.
````

---

## 5. The four Area templates

### 5a. `_Templates/New Mission.md`

````text
<%*
// New Mission — a reference "Area" that Products link to. Requires Templater.
// The Mission ID is entered by you (not auto-generated).
const mission_id       = await tp.system.prompt("Mission ID (you assign this)");
const flight_number    = await tp.system.prompt("Flight number", "", false);
const platform         = await tp.system.prompt("Platform (e.g. MQ-9)", "", false);
const takeoff_date     = await tp.system.prompt("Takeoff date (YYYY-MM-DD)", tp.date.now("YYYY-MM-DD"), false);
const land_date        = await tp.system.prompt("Landing date (YYYY-MM-DD, blank = none)", "", false);
const takeoff_location = await tp.system.prompt("Takeoff location", "", false);
const land_location    = await tp.system.prompt("Landing location", "", false);

// Name the file by Mission ID (+ flight number if given) so it's readable in links/sidebar.
await tp.file.rename(mission_id + (flight_number ? " FL" + flight_number : ""));
-%>
---
tracker: mission
tags: [area, mission]
mission_id: <% mission_id %>
flight_number: <% flight_number %>
platform: <% platform %>
takeoff_date: <% takeoff_date %>
land_date: <% land_date %>
takeoff_location: <% takeoff_location %>
land_location: <% land_location %>
created: <% tp.date.now("YYYY-MM-DD") %>
---

# <% mission_id %><% flight_number ? " — Flight " + flight_number : "" %>

- **Platform:** <% platform %>
- **Takeoff:** <% takeoff_date %> — <% takeoff_location %>
- **Landing:** <% land_date %> — <% land_location %>

## Products from this mission
Linked Products appear in the **backlinks** pane (they set `mission: [[<% mission_id %><% flight_number ? " FL" + flight_number : "" %>]]`).
````

### 5b. `_Templates/New Customer.md`

````text
<%*
// New Customer — a reference "Area" that Products link to. Requires Templater.
// The Center ID is entered by you (not auto-generated).
const name      = await tp.system.prompt("Customer name / short label (e.g. J2)");
const center_id = await tp.system.prompt("Center ID (you assign this)", "", false);
const poc       = await tp.system.prompt("POC — point of contact", "", false);

// Name the file "<Center ID> <name>" (falls back to just the name if no Center ID).
await tp.file.rename(center_id ? center_id + " " + name : name);
-%>
---
tracker: customer
tags: [area, customer]
name: <% name %>
center_id: <% center_id %>
poc: <% poc %>
created: <% tp.date.now("YYYY-MM-DD") %>
---

# <% name %><% center_id ? " (" + center_id + ")" : "" %>

- **Center ID:** <% center_id %>
- **POC:** <% poc %>

## Products for this customer
Linked Products appear in the **backlinks** pane.
````

### 5c. `_Templates/New Country.md`

````text
<%*
// New Country — a reference "Area" that Products link to. Requires Templater.
// Country code is the standard ISO code (you enter it).
const country_name = await tp.system.prompt("Country name");
const country_code = await tp.system.prompt("Country code (ISO, e.g. US or USA)");

// Name the file "<CODE> <name>" — e.g. "US United States".
await tp.file.rename(country_code + " " + country_name);
-%>
---
tracker: country
tags: [area, country]
country_name: <% country_name %>
country_code: <% country_code %>
created: <% tp.date.now("YYYY-MM-DD") %>
---

# <% country_code %> — <% country_name %>

## Products in this country
Linked Products appear in the **backlinks** pane.
````

### 5d. `_Templates/New Target.md`

````text
<%*
// New Target — a reference "Area" that Products link to. Requires Templater.
// The Target ID is entered by you (not auto-generated).
const target_name = await tp.system.prompt("Target name");
const target_id   = await tp.system.prompt("Target ID (you assign this)");
const coordinates = await tp.system.prompt("Coordinates (lat, long)", "", false);
// Templater can't upload files — drag the image into the vault first, then type its filename here.
const image       = await tp.system.prompt("Image filename (e.g. apron.jpg; blank to add later)", "", false);

// Name the file "<Target ID> <name>".
await tp.file.rename(target_id + " " + target_name);
-%>
---
tracker: target
tags: [area, target]
target_name: <% target_name %>
target_id: <% target_id %>
coordinates: <% coordinates %>
image: <% image ? "\"[[" + image + "]]\"" : "" %>
created: <% tp.date.now("YYYY-MM-DD") %>
---

# <% target_id %> — <% target_name %>

- **Coordinates:** <% coordinates %>

## Imagery
<% image ? "![[" + image + "]]" : "> Drag the target image into this note, then set the `image:` field to its filename." %>

## Products against this target
Linked Products appear in the **backlinks** pane.
````

---

## 6. The Production dashboard

Create **`Production/Production.md`**. It holds the **➕ New Product** button and an embedded board.
(Paste the inside of the 4-backtick fence — it contains its own 3-backtick blocks.)

````markdown
---
tracker: project
tags: [dashboard]
title: Production
created: 2026-06-30
---

# Production — Project Dashboard

## Quick actions

```meta-bind-button
label: "➕ New Product"
icon: "plus"
style: primary
tooltip: "Create a product with an auto-generated ID (AVD26001…)"
id: "new-product"
actions:
  - type: templaterCreateNote
    templateFile: "_Templates/New Product.md"
    folderPath: "Production"
    fileName: "Untitled Product"
    openNote: true
```

## Active work (board)

```base
views:
  - type: table
    name: Active
    filters:
      and:
        - tracker == "product"
    groupBy:
      property: note.status
      direction: ASC
    order:
      - file.name
      - note.priority
      - note.due
```

## Full views
- **Work views** → open `_Views/Production — Work.base`
- **Metrics** → open `_Views/Production — Metrics.base`
````

---

## 7. The Areas dashboard + registries

Create **`Areas/Areas.md`** — four creation buttons plus a columned table per Area type.
(Paste the inside of the 4-backtick fence.)

````markdown
---
tracker: project
tags: [area, dashboard]
title: Areas
created: 2026-06-30
---

# Areas — reference registry

Entities that **Products** link to. Create records with the buttons; each opens a Templater
prompt flow (IDs are entered by you, not auto-generated). Products pick from these when created.

## New record

```meta-bind-button
label: "✈️ New Mission"
icon: "plane"
style: primary
tooltip: "Mission ID, flight number, takeoff/land date + location, platform"
id: "new-mission"
actions:
  - type: templaterCreateNote
    templateFile: "_Templates/New Mission.md"
    folderPath: "Areas/Missions"
    fileName: "Untitled Mission"
    openNote: true
```
```meta-bind-button
label: "🏢 New Customer"
icon: "building"
style: primary
tooltip: "Customer name, Center ID, POC"
id: "new-customer"
actions:
  - type: templaterCreateNote
    templateFile: "_Templates/New Customer.md"
    folderPath: "Areas/Customers"
    fileName: "Untitled Customer"
    openNote: true
```
```meta-bind-button
label: "🌐 New Country"
icon: "globe"
style: primary
tooltip: "Country name + ISO code"
id: "new-country"
actions:
  - type: templaterCreateNote
    templateFile: "_Templates/New Country.md"
    folderPath: "Areas/Countries"
    fileName: "Untitled Country"
    openNote: true
```
```meta-bind-button
label: "🎯 New Target"
icon: "crosshair"
style: primary
tooltip: "Target name, Target ID, coordinates, image"
id: "new-target"
actions:
  - type: templaterCreateNote
    templateFile: "_Templates/New Target.md"
    folderPath: "Areas/Targets"
    fileName: "Untitled Target"
    openNote: true
```

## Missions
```base
filters:
  and:
    - file.inFolder("Areas/Missions")
properties:
  note.flight_number:
    displayName: Flight #
  note.platform:
    displayName: Platform
  note.takeoff_date:
    displayName: Takeoff
  note.land_date:
    displayName: Landing
  note.takeoff_location:
    displayName: From
  note.land_location:
    displayName: To
views:
  - type: table
    name: Missions
    order:
      - file.name
      - flight_number
      - platform
      - takeoff_date
      - land_date
      - takeoff_location
      - land_location
```

## Customers
```base
filters:
  and:
    - file.inFolder("Areas/Customers")
properties:
  note.name:
    displayName: Name
  note.center_id:
    displayName: Center ID
  note.poc:
    displayName: POC
views:
  - type: table
    name: Customers
    order:
      - file.name
      - name
      - center_id
      - poc
```

## Countries
```base
filters:
  and:
    - file.inFolder("Areas/Countries")
properties:
  note.country_code:
    displayName: Code
  note.country_name:
    displayName: Country
views:
  - type: table
    name: Countries
    order:
      - file.name
      - country_code
      - country_name
```

## Targets
```base
filters:
  and:
    - file.inFolder("Areas/Targets")
properties:
  note.target_id:
    displayName: Target ID
  note.coordinates:
    displayName: Coordinates
  note.image:
    displayName: Image
views:
  - type: table
    name: Targets
    order:
      - file.name
      - target_id
      - coordinates
      - image
```
````

---

## 8. The Bases views (product boards)

These are standalone `.base` files. They are plain YAML — paste the inside of each fence.

### 8a. `_Views/Production — Work.base`

````yaml
filters:
  and:
    - tracker == "product"
properties:
  note.status:
    displayName: Status
  note.priority:
    displayName: Priority
  note.product_type:
    displayName: Type
  note.mission:
    displayName: Mission
  note.customer:
    displayName: Customer
  note.country:
    displayName: Country
  note.target:
    displayName: Target
  note.due:
    displayName: Due
  note.created:
    displayName: Created
views:
  - type: table
    name: Active board
    filters:
      and:
        - status != "Published"
        - status != "Archived"
    groupBy:
      property: status
      direction: ASC
    order:
      - file.name
      - priority
      - mission
      - customer
      - country
      - target
      - due
  - type: table
    name: Inbox
    filters:
      and:
        - status == "Inbox"
    order:
      - file.name
      - priority
      - mission
      - customer
      - country
      - target
      - created
  - type: table
    name: Overdue
    filters:
      and:
        - due < now()
        - status != "Published"
        - status != "Archived"
    order:
      - file.name
      - due
      - status
      - priority
      - mission
      - customer
      - country
      - target
  - type: table
    name: Recently changed
    order:
      - file.name
      - status
      - mission
      - customer
      - country
      - target
      - file.mtime
````

### 8b. `_Views/Production — Metrics.base`

````yaml
filters:
  and:
    - tracker == "product"
formulas:
  turnaround: (done - created)
  total_min: (time_pre_min + time_prod_min + time_post_min)
properties:
  note.status:
    displayName: Status
  note.product_type:
    displayName: Type
  note.mission:
    displayName: Mission
  note.customer:
    displayName: Customer
  note.country:
    displayName: Country
  note.target:
    displayName: Target
  note.created:
    displayName: Created
  note.done:
    displayName: Closed
  note.time_pre_min:
    displayName: Pre (min)
  note.time_prod_min:
    displayName: Prod (min)
  note.time_post_min:
    displayName: Post (min)
  formula.total_min:
    displayName: Total (min)
  note.priority:
    displayName: Priority
  note.due:
    displayName: Due
  formula.turnaround:
    displayName: Turnaround
views:
  - type: table
    name: Throughput (Published)
    filters:
      and:
        - status == "Published"
    groupBy:
      property: product_type
      direction: ASC
    order:
      - file.name
      - customer
      - mission
      - country
      - target
      - done
  - type: table
    name: Backlog by status
    filters:
      and:
        - status != "Published"
        - status != "Archived"
    groupBy:
      property: status
      direction: ASC
    order:
      - file.name
      - priority
      - customer
      - mission
      - country
      - target
      - due
  - type: table
    name: By customer
    groupBy:
      property: customer
      direction: ASC
    order:
      - file.name
      - status
      - product_type
      - done
      - formula.total_min
    summaries:
      formula.total_min: Sum
  - type: table
    name: By mission
    groupBy:
      property: mission
      direction: ASC
    order:
      - file.name
      - status
      - product_type
      - customer
      - done
  - type: table
    name: By country
    groupBy:
      property: country
      direction: ASC
    order:
      - file.name
      - status
      - product_type
      - customer
      - done
  - type: table
    name: By target
    groupBy:
      property: target
      direction: ASC
    order:
      - file.name
      - status
      - product_type
      - customer
      - done
  - type: table
    name: Turnaround & effort
    filters:
      and:
        - status == "Published"
    order:
      - file.name
      - customer
      - mission
      - country
      - target
      - created
      - done
      - formula.turnaround
      - time_pre_min
      - time_prod_min
      - time_post_min
      - formula.total_min
    summaries:
      time_pre_min: Sum
      time_prod_min: Sum
      time_post_min: Sum
      formula.total_min: Sum
````

---

## 8c. The layout CSS snippet (optional)

Create **`.obsidian/snippets/production.css`** and paste the block below, then enable it under
**Settings → Appearance → CSS snippets** (click **refresh** first). It targets Product notes (they carry
`cssclasses: [product]`) to give them **full width** and lay the three subtask phases out in **columns**
(best in Reading view). The layout parts are cosmetic, but **leave it on** — it also hides the info-box
fields from the properties panel (see §4). The full-width rules are written to work with **both** the
default Obsidian theme **and the Minimal theme**, which size content differently.

```css
/* ============================================================
   Product note styling — applied via  cssclasses: [product]
   Enable under Settings → Appearance → CSS snippets.
   ============================================================ */

/* --- Full width: reclaim the side gutters on Product notes ---------
   Theme-agnostic. The DEFAULT theme sizes the content container from
   --file-line-width; MINIMAL sizes the inner content from --line-width
   / --max-width (its readable-line-width rules), so overriding the
   sizer alone does nothing under Minimal. Overriding all of those width
   variables on the Product view container (plus a direct sizer rule)
   forces full width in either theme, reading or editing, whether or not
   "readable line length" is on. ------------------------------------- */
.markdown-preview-view.product,
.markdown-source-view.product {
  --line-width: 100%;
  --line-width-wide: 100%;
  --max-width: 100%;
  --content-line-width: 100%;
  --file-line-width: 100%;
}
.markdown-preview-view.product .markdown-preview-sizer,
.markdown-source-view.mod-cm6.product .cm-sizer {
  max-width: 100% !important;
}

/* --- Subtasks callout: give the custom type a look --- */
.product .callout[data-callout="subtasks"] {
  --callout-color: 130, 130, 210;      /* soft indigo */
  --callout-icon: lucide-list-checks;
}

/* --- 3-column subtasks (each phase aims for its own column) --- */
.product .callout[data-callout="subtasks"] .callout-content {
  column-count: 3;
  column-gap: 2rem;
}
.product .callout[data-callout="subtasks"] .callout-content h3 {
  margin-top: 0;
  break-after: avoid;
}
.product .callout[data-callout="subtasks"] .callout-content h3,
.product .callout[data-callout="subtasks"] .callout-content ul {
  break-inside: avoid;
}

/* --- Roomier checkboxes, easier to click/scan --- */
.product .markdown-preview-view ul.contains-task-list {
  line-height: 1.6;
}

/* --- Free-text info boxes (Meta Bind text areas) ---------------
   These fields exist only to back the in-note text boxes, so hide
   them from the properties UI. Editing happens via the boxes, which
   work in reading view. Unscoped (not .product) on purpose: the
   File Properties SIDEBAR pane doesn't inherit the note's cssclass,
   and these four keys are only ever used on Product notes. --------- */
.metadata-property[data-property-key="notes"],
.metadata-property[data-property-key="sourcing"],
.metadata-property[data-property-key="coordination"],
.metadata-property[data-property-key="feedback"],
.metadata-property[data-property-key="time_pre_min"],
.metadata-property[data-property-key="time_prod_min"],
.metadata-property[data-property-key="time_post_min"] {
  display: none;
}

/* Give the text areas a comfortable, full-width writing surface. */
.product .mb-input-textarea {
  min-height: 6.5rem;
  width: 100%;
  resize: vertical;
}
```

> [!note] The info-box hiding rules are **not** optional if you want the tidy look.
> The four free-text fields (`notes`, `sourcing`, `coordination`, `feedback`) back the in-note
> **Notes / Sourcing / Coordination / Feedback** text areas, which are editable in **Reading view**.
> The `display: none` rules keep those fields out of the properties panel so the boxes are the only
> place they appear. Remove the rules if you'd rather edit them as normal properties too.

---

## 9. Set your real codes

The templates ship with **placeholder** program/type codes. The **only functional** place to change
them is the config block at the top of **`_Templates/New Product.md`**:

```js
const PROGRAMS   = ["A", "B", "C"];                                   // ← your 1-char program codes
const TYPE_CODES = { video: "VD", graphic: "GR", map: "MP", report: "RP" };  // ← product_type → 2-char code
```

- **`PROGRAMS`** — your real 1-character program codes (the "Program code" picker list).
- **`TYPE_CODES`** — keys must match the product-type options; values are the 2-letter ID codes.

⚠️ Changing these only affects **future** products — existing IDs stay as assigned (that's your
audit trail). See `_Setup — Product Codes.md` for the full change-list.

---

## 10. Daily use

1. **Create Areas first.** Open `Areas/Areas.md` → click a button → fill the prompts. Do this for any
   Missions / Customers / Countries / Targets you'll reference. (Products can only *link* to Areas
   that already exist.)
2. **Create a Product.** Open `Production/Production.md` → **➕ New Product** → answer the prompts
   (Status, Priority, Program, Type, …, then the four Area pickers). Each Area picker is
   **multi-select** — add as many Missions / Customers / Countries / Targets as apply, then pick
   **✓ done**. The ID auto-fills (`AVD26001`), and the note is moved into its **own folder** with a
   matching **folder note** (`Production/AVD26001 Title/AVD26001 Title.md`) — so clicking the folder
   opens the Product, and any attachments/exports can live right beside it. It opens automatically.
3. **Fill the info boxes (optional).** In the note body, type into the **Notes**, **Sourcing /
   Collection**, **Coordination / Tasking**, and **Feedback / Revisions** boxes — right in **Reading
   view**, no edit mode needed. Their fields stay hidden from the properties panel.
4. **Log time as you work.** In the **Time** section, click **+15 / +30** (or **-15** to correct) under
   the phase you're working — Preproduction / Production / Postproduction. The live display shows the
   running **total (h/m)** and each phase's **share %**; **Reset time** zeroes them. Marking a Product
   **Published** stamps **Done** automatically.
5. **Work the boards.** Open the two `.base` files (or the embedded board) to triage, track overdue
   items, and read throughput/turnaround metrics (incl. per-customer / mission / country / target). Product
   rows show their linked Mission(s) / Customer(s) / Country(ies) / Target(s) as clickable links.
6. **Backlinks.** Each Area note's **backlinks** pane lists every Product pointing at it.

---

## 11. How the auto-ID guarantees no duplicates

When you create a Product, the template **scans every note's `product_id`** (falling back to the
filename prefix), keeps only IDs ending in the current year (`26###`), takes the **highest** sequence,
and adds 1. Because the vault's existing notes *are* the counter:

- **No stored counter to drift** — nothing to get out of sync across machines.
- **Survives deletions** — it takes `max + 1`, not `count + 1`, so deleting `…26005` won't make the
  next Product collide with `…26006`. Gaps are preserved (good for auditing).
- **Per-year reset is automatic** — the year filter means January restarts at `…27001`.

Only caveat: two Products created in the same second on two machines *before sync* could collide —
rare, and unavoidable without a central service.

---

## 12. Troubleshooting

- **Button shows as raw code** → you're in a mode where Meta Bind isn't rendering. Switch to Reading
  view, or enable "Render buttons in live preview" in Meta Bind settings.
- **Button errors "template not found"** → check the `templateFile:` path matches exactly, and that
  Templater's template folder is `_Templates`.
- **Base shows "error rendering"** → don't name any property `type` (it collides with a Bases
  built-in); this system uses `tracker` instead. Avoid `file`, `note`, `tags` as property names too.
- **Area picker only shows "✓ done" and "➕ Create new …"** → that Area folder is empty; create a
  record there first (or make one inline). The pickers are multi-select — keep choosing, then **✓ done**.
- **Info box shows `META_BIND_ERROR` / "Failed to parse"** → a `placeholder(…)` argument contains a
  comma or apostrophe (Meta Bind reads commas as argument separators). The shipped boxes use the bare
  form `INPUT[textArea:notes]` to avoid this; if you add a placeholder, keep it comma- and quote-free.
- **`notes` / `sourcing` / `coordination` / `feedback` show in the properties panel** → the `production`
  CSS snippet isn't active. Settings → Appearance → CSS snippets → **refresh**, then toggle `production` on.
- **ID came out wrong** → confirm the `PROGRAMS`/`TYPE_CODES` config and that existing Products carry
  a `product_id` in frontmatter for the scan to read.
