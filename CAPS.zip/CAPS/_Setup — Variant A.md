---
tracker: setup-guide
tags: [meta/planning]
created: 2026-06-24
---

# Variant A Setup — TaskNotes-led, air-gapped

> [!warning] Superseded — kept as a decision record
> **v1 was locked as Variant B (core-only), not Variant A.** You don't want TaskNotes' drag-board,
> calendar, or timer — its only real advantages — and it drifted the frontmatter on first contact.
> This doc is retained only as a record of the path considered and rejected.
> **Use [[_Setup — Variant B (Core Build)]] instead.**

Companion to [[Obsidian PM Vault Plan]]. This is the install + config checklist to turn the sample
(already in this vault) into the working Variant A system. **The sample notes and the two `.base`
views work *right now* with core Bases — no community plugins required.** The plugins below add the
nicer operator UI on top of the same frontmatter.

## What already works (open these now)
- `_Views/Production — Work.base` → tabs: Active board (cards by status) · Inbox · Overdue · Blocked · Recently changed.
- `_Views/Production — Metrics.base` → Throughput · Backlog by status · By requester · Turnaround & effort.
- `Production/Production.md` → embedded board (the ```base``` block).

Once you've created a few Products: any past-due one shows in **Overdue** (and also in **Blocked** if
`blocked: true`); anything set to **Published/Done** shows in **Throughput** with its **Turnaround**
(done − created) and **Spent** time summed; the board splits cards into status columns.

> [!note] Bases gotchas (learned the hard way)
> - **Don't name a property `type`.** It collides with a Bases built-in and throws "error rendering code
>   block" even as a bare reference. We use **`tracker`** instead (product / project) — which
>   also matches Redmine's term. If you add fields, avoid other reserved words (`file`, `note`, `tags`).
> - **Filters use BARE property names** (`status != "Published"`, `tracker == "product"`) — *not*
>   `note.status`. The `note.` / `file.` / `formula.` prefixes are only for `order`, `groupBy.property`,
>   `summaries` keys, and the `properties:` block.
> - **No `sort:` key.** It isn't in the documented format; sort interactively by clicking a column header.
>   (Views here rely on `groupBy` + `order`; click the Due / modified column to sort Overdue / Recently changed.)
> - **Turnaround** = `formula.turnaround: '(done - created)'` (bare names), rendering as a *duration*
>   (e.g. "3 days"), not a bare number — Bases has no documented day-count diff. Hence no Average summary
>   on it; the per-phase `time_pre_min` / `time_prod_min` / `time_post_min` (real numbers) get `Sum`.
> - **If a `.base` view still errors:** tell me the exact error text + which view; remaining suspects are
>   the `now()` date filter (Overdue) or the `Sum` summary name.

## Plugins to install (air-gapped transfer)

On an internet-connected machine, install each from **Settings → Community plugins → Browse**, then
copy its folder from `.obsidian/plugins/<plugin-id>/` to the same path on the air-gapped vault.
**Pin the version** (note the version number) and don't auto-update — treat like a Redmine plugin.

| Plugin | id | Role here |
|---|---|---|
| **TaskNotes** | `tasknotes` | Kanban/calendar/agenda + start-stop time tracking; reads our frontmatter |
| **Templater** | `templater-obsidian` | The intake template (`_Templates/New Product`) — auto-generates the Product ID |
| **Folder notes** | `folder-notes` | Makes `Production/` open its landing note |
| **Meta Bind** | `obsidian-meta-bind-plugin` | In-note dropdowns, buttons, and free-text **text-area boxes** (status, time, Publish button, Notes / Sourcing / Coordination / Feedback) — the info boxes need it even alongside TaskNotes |

After copying, enable each under **Settings → Community plugins**.

## TaskNotes configuration (the important part)

TaskNotes field names are **remappable** — point them at *our* keys so it reads the existing notes.
In **Settings → TaskNotes → Field mapping** (labels may vary slightly by version), set:

| TaskNotes concept | Map to our property |
|---|---|
| Task identifier tag | `task` (we tag every Product `tags: [task]`) |
| Status | `status` |
| Priority | `priority` |
| Due date | `due` |
| Created date | `created` |
| Completed date | `done` |
| Time estimate | `timeEstimate` |
| Time entries | `timeEntries` |

**Custom statuses** (Settings → TaskNotes → Statuses) — create these 8 in order, flag the last two completed:

| Order | Value | Completed? |
|---|---|---|
| 1 | Inbox | no |
| 2 | Backlog | no |
| 3 | Preproduction | no |
| 4 | Production | no |
| 5 | Postproduction | no |
| 6 | Draft | no |
| 7 | Published | **yes** |
| 8 | Archived | **yes** |

Marking **Published/Archived** as completed is what auto-stamps `done` (= Redmine closed-on) → makes
turnaround free.

**Custom priorities:** `routine`, `priority`, `immediate` (low→high weight).

**Time tracking:** TaskNotes' start/stop timer writes to `timeEntries`. But the schema tracks effort
**per phase** in `time_pre_min` / `time_prod_min` / `time_post_min` (real numbers Bases can sum; it can't
parse the entries array) — the Metrics "Turnaround & effort" view sums those plus a `total_min` formula.
Convention: when you stop the TaskNotes timer, bump the matching phase field. If you'd rather not
double-enter, drop the TaskNotes timer entirely and use the Variant B **+15 / +30 / -15** phase buttons
(they need JS Engine).

## Templater configuration
- Settings → Templater → Template folder: `_Templates`.
- Optionally enable a hotkey for "Templater: Create new note from template" → pick *New Product*.
- Or use the Meta Bind `➕ New Product` button on the Production dashboard to run the same intake.
- Product IDs are auto-generated by Templater in the form `<program:1char><type:2char><year:2digit><seq:3digit>` (e.g. `AVD26001` = program A, video = VD, 2026, sequence 001). The sequence is **global** across programs/types and **resets each calendar year** — Templater scans existing notes for the highest current-year sequence and adds 1, so IDs never collide and survive deletions.
- Products live **flat** in `Production/` — no per-request subfolders, no parent link to set.

## Folder notes configuration
- Enable "folder note" behavior; the included sample already uses the folder-name-matches-note pattern
  (`Production/Production.md`). Clicking the folder opens that note.

## Verify (create a few test Products first)
1. Open the two `.base` files → confirm they populate as described above (works pre-plugins).
2. Install + configure TaskNotes → open its **Kanban** view → confirm your Products appear
   as cards in their status columns; drag one to a new column → confirm `status` updates in frontmatter.
3. Open TaskNotes **Calendar/Agenda** → confirm due dates show; a past-due Product reads overdue.
4. Start/stop the TaskNotes timer on a Product → confirm a `timeEntries` entry; bump the phase field (`time_prod_min`, etc.).
5. Run *New Product* (Templater) → confirm a complete note is created from prompts with no manual YAML.
6. Set a Product to **Published** → confirm `done` auto-stamps and it leaves the Active board, lands in Throughput.

## Cleanup
Every demo note carries `sample: true` and lives under `Production/`. To remove the demo: delete the
`Production/` folder, or search `sample: true` and delete those notes. Keep `_Views/` and `_Templates/`.
