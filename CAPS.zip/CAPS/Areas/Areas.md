---
tracker: project
tags: [area, dashboard]
title: Areas
created: 2026-06-30
---

# Areas — reference registry

Entities that **Products** link to. Create records with the buttons; each opens a Templater
prompt flow (IDs are entered by you, not auto-generated). Products pick from these when created.

## New record

```meta-bind-button
label: "✈️ New Mission"
icon: "plane"
style: primary
tooltip: "Mission ID, flight number, takeoff/land date + location, platform"
id: "new-mission"
actions:
  - type: templaterCreateNote
    templateFile: "_Templates/New Mission.md"
    folderPath: "Areas/Missions"
    fileName: "Untitled Mission"
    openNote: true
```
```meta-bind-button
label: "🏢 New Customer"
icon: "building"
style: primary
tooltip: "Customer name, Center ID, POC"
id: "new-customer"
actions:
  - type: templaterCreateNote
    templateFile: "_Templates/New Customer.md"
    folderPath: "Areas/Customers"
    fileName: "Untitled Customer"
    openNote: true
```
```meta-bind-button
label: "🌐 New Country"
icon: "globe"
style: primary
tooltip: "Country name + ISO code"
id: "new-country"
actions:
  - type: templaterCreateNote
    templateFile: "_Templates/New Country.md"
    folderPath: "Areas/Countries"
    fileName: "Untitled Country"
    openNote: true
```
```meta-bind-button
label: "🎯 New Target"
icon: "crosshair"
style: primary
tooltip: "Target name, Target ID, coordinates, image"
id: "new-target"
actions:
  - type: templaterCreateNote
    templateFile: "_Templates/New Target.md"
    folderPath: "Areas/Targets"
    fileName: "Untitled Target"
    openNote: true
```

## Missions
```base
filters:
  and:
    - file.inFolder("Areas/Missions")
properties:
  note.flight_number:
    displayName: Flight #
  note.platform:
    displayName: Platform
  note.takeoff_date:
    displayName: Takeoff
  note.land_date:
    displayName: Landing
  note.takeoff_location:
    displayName: From
  note.land_location:
    displayName: To
views:
  - type: table
    name: Missions
    order:
      - file.name
      - flight_number
      - platform
      - takeoff_date
      - land_date
      - takeoff_location
      - land_location
```

## Customers
```base
filters:
  and:
    - file.inFolder("Areas/Customers")
properties:
  note.name:
    displayName: Name
  note.center_id:
    displayName: Center ID
  note.poc:
    displayName: POC
views:
  - type: table
    name: Customers
    order:
      - file.name
      - name
      - center_id
      - poc
```

## Countries
```base
filters:
  and:
    - file.inFolder("Areas/Countries")
properties:
  note.country_code:
    displayName: Code
  note.country_name:
    displayName: Country
views:
  - type: table
    name: Countries
    order:
      - file.name
      - country_code
      - country_name
```

## Targets
```base
filters:
  and:
    - file.inFolder("Areas/Targets")
properties:
  note.target_id:
    displayName: Target ID
  note.coordinates:
    displayName: Coordinates
  note.image:
    displayName: Image
views:
  - type: table
    name: Targets
    order:
      - file.name
      - target_id
      - coordinates
      - image
```
