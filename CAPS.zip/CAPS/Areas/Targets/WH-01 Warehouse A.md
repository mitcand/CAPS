---
tracker: target
tags: [area, target]
target_name: Warehouse A
target_id: WH-01
coordinates: 19tdg200343
image: 
created: 2026-06-30
---

# WH-01 — Warehouse A

- **Coordinates:** 19tdg200343

## Imagery
> Drag the target image into this note, then set the `image:` field to its filename.

## Products against this target
Linked Products appear in the **backlinks** pane.
