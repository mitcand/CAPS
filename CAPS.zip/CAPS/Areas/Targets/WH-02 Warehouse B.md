---
tracker: target
tags: [area, target]
target_name: Warehouse B
target_id: WH-02
coordinates: 090E 130N
image: 
created: 2026-06-30
---

# WH-02 — Warehouse B

- **Coordinates:** 090E 130N

## Imagery
> Drag the target image into this note, then set the `image:` field to its filename.

## Products against this target
Linked Products appear in the **backlinks** pane.
