---
tracker: customer
tags: [area, customer]
name: Black House Team Group
center_id: BHTG
poc: Matt Mattson
created: 2026-07-01
---

# BHTG Black House Team Group
