<?php

namespace Kanboard\Plugin\TrackingNumber;

use Kanboard\Core\Plugin\Base;
use Kanboard\Plugin\TrackingNumber\Action\GenerateTrackingNumber;

class Plugin extends Base
{
    public function initialize()
    {
        $this->actionManager->register(new GenerateTrackingNumber($this->container));
    }

    public function getPluginName()
    {
        return 'TrackingNumber';
    }

    public function getPluginDescription()
    {
        return t('Auto-generate a product tracking number when a card enters a chosen column');
    }

    public function getPluginAuthor()
    {
        return 'CAPS';
    }

    public function getPluginVersion()
    {
        return '1.0.0';
    }
}
