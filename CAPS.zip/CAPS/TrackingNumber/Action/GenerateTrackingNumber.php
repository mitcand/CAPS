<?php

namespace Kanboard\Plugin\TrackingNumber\Action;

use Kanboard\Model\TaskModel;
use Kanboard\Action\Base;

/**
 * Generate a product tracking number when a task moves to a chosen column.
 *
 * Format: <Platform><Type><YY><NNN>   e.g. ASG26001
 *   Platform = last word of the task's "Plat ..." TAG  (e.g. "Plat A" -> A)
 *   Type     = first word of the task's CATEGORY name  (e.g. "SG ..." -> SG)
 *   YY       = current 2-digit year
 *   NNN      = global per-year sequence, zero-padded, resets each January
 *
 * Assigns only once (skips if the task already has a reference), and only if
 * both a platform tag and a product-type category are present.
 */
class GenerateTrackingNumber extends Base
{
    public function getDescription()
    {
        return t('Generate product tracking number when moved to column');
    }

    public function getCompatibleEvents()
    {
        return array(
            TaskModel::EVENT_MOVE_COLUMN,
        );
    }

    public function getActionRequiredParameters()
    {
        return array(
            'column_id' => t('Column'),
        );
    }

    public function getEventRequiredParameters()
    {
        return array(
            'task_id',
            'column_id',
        );
    }

    public function hasRequiredCondition(array $data)
    {
        return $data['column_id'] == $this->getParam('column_id');
    }

    public function doAction(array $data)
    {
        $task = $this->taskFinderModel->getById($data['task_id']);

        // Assign only once: skip if this task already has a reference.
        if (! empty($task['reference'])) {
            return false;
        }

        $type = $this->firstWord($this->categoryName($task['category_id']));
        $platform = $this->platformFromTags($task['id']);

        // Need both a platform tag and a product-type category.
        if ($platform === '' || $type === '') {
            return false;
        }

        $year = date('y');
        $sequence = $this->nextSequence($task['project_id'], $year);
        $reference = $platform.$type.$year.sprintf('%03d', $sequence);

        return $this->taskModificationModel->update(array(
            'id' => $data['task_id'],
            'reference' => $reference,
            'title' => $reference.' — '.$task['title'],
        ));
    }

    private function platformFromTags($taskId)
    {
        $tags = $this->taskTagModel->getList($taskId);

        foreach ($tags as $name) {
            if (stripos($name, 'Plat') === 0) {
                $parts = preg_split('/\s+/', trim($name));
                return strtoupper(end($parts));
            }
        }

        return '';
    }

    private function firstWord($name)
    {
        $name = trim((string) $name);
        if ($name === '') {
            return '';
        }
        $parts = preg_split('/\s+/', $name);
        return strtoupper($parts[0]);
    }

    private function categoryName($categoryId)
    {
        if (empty($categoryId)) {
            return '';
        }
        $category = $this->categoryModel->getById($categoryId);
        return isset($category['name']) ? $category['name'] : '';
    }

    private function nextSequence($projectId, $year)
    {
        $references = $this->db
            ->table(TaskModel::TABLE)
            ->eq('project_id', $projectId)
            ->findAllByColumn('reference');

        $max = 0;

        foreach ($references as $reference) {
            if (preg_match('/(\d{2})(\d{3})$/', (string) $reference, $m) && $m[1] === $year) {
                $seq = (int) $m[2];
                if ($seq > $max) {
                    $max = $seq;
                }
            }
        }

        return $max + 1;
    }
}
