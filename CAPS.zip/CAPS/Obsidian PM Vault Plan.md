---
type: planning-doc
status: draft
created: 2026-06-24
updated: 2026-06-24
tags:
  - meta/planning
---

# Obsidian PM Vault — "Redmine-lite" Design Plan

> [!note] Status
> **v1 LOCKED (2026-06-30).** Companion to [[PM System Design Plan]] (the Redmine build).
> Obsidian replicates the *useful* Redmine behaviors while staying **low-maintenance** — the
> specific objection that got Obsidian rejected the first time.
>
> **Locked model (2026-06-24):** air-gapped production shop · keep time tracking (per-phase minute buttons) ·
> handoff = Bases recent-activity view + in-note journals (no separate daily shift-log) ·
> single-entity model: one **Product** per request (the deliverable *is* the task); its steps live as
> subtasks *inside* that one Product, not as separate rows.
> **Locked build (2026-06-30): Variant B — Core-only** (Bases + Templater + Meta Bind + Folder Notes),
> Subtasks are plain checkboxes. **No TaskNotes, no Obsidian Tasks, no task plugin at all.**
> See [[_Setup — Variant B (Core Build)]] for the install/config checklist.

## Context carried over from the Redmine plan

Same shop, same needs — restated so this doc stands alone:

- **Workload:** intelligence production (FMV/video from airborne collection, graphics, maps, reports).
- **Environment:** air-gapped Windows/Linux workstation; **one operator at a time**, but **continuity across shifts**.
- **Must track metrics:** volume/throughput, turnaround/cycle time, status/backlog, grouped by requester/collection.
- **Must hold a KB:** software how-tos (DaVinci Resolve, FFMPEG, R/RStudio, operator guide), expandable.
- **Prior rejection reason (the bar to clear):** "a hand-built notes-app tracker is high-maintenance for
  the operator and the prior two attempts didn't stick." → **Design principle: minimize hand-editing of
  YAML and minimize bespoke query code. Lean on purpose-built plugins so the operator works in forms/buttons,
  not raw markdown.**

## The one fact that drives the whole architecture

**Obsidian Bases (core, already enabled) reads only frontmatter properties + file metadata — it
cannot see inline `- [ ]` checkbox tasks inside note bodies.** (Confirmed; stated by Obsidian's
founder.) You use **Bases instead of Dataview**, and this settles the task-plugin question — but not
the way the first draft assumed:

- The **Product** (a whole job) is what you track on boards → it's **one note**, all fields in
  frontmatter → **a Bases-queryable row.** ✅
- A Product's **subtasks** (cut, color, render…) are steps *inside* that one job. You **don't** want
  them as separate board rows — only the Product's overall status rolls up. So they live as **native
  `- [ ]` checkboxes in the note body**, and Bases' blindness to checkboxes is exactly what you want
  here: the project layer (frontmatter → boards) and the step layer (checkboxes → in-note) never collide.

**Therefore no task plugin is needed for the tasks themselves.** Both candidates were rejected:

- **TaskNotes** = one note per task → overkill: its only real advantages are a drag-board, calendar, and
  start/stop timer, none of which you want. In practice it also drifted the frontmatter on first contact
  (wrote `status: done` / `completedDate` that the 8-state workflow + metrics don't read). ❌
- **Obsidian Tasks** = rich per-checkbox metadata whose entire payoff is *cross-note querying* — which you
  explicitly don't want, and which is invisible to Bases anyway. ❌

An auto completion-date stamp on subtasks was considered (via Task Collector) but **dropped** — its only
no-popup trigger is a hotkey, not a plain checkbox click, and the feature wasn't worth an extra plugin +
config surface + failure mode. Subtasks are just **native `- [ ]` checkboxes** you tick off; if a step's
completion time matters, note it in the Product's `## Journal`.

## How Redmine concepts map to Obsidian

| Redmine | Obsidian equivalent | Built with |
|---|---|---|
| Project (Production) | A folder + its **folder-note** | Foldernotes |
| Tracker (Product) | `tracker:` frontmatter property | Templater sets it |
| Issue / Product | **One note** (frontmatter = fields, body = journal) | TaskNotes *or* plain note (§Variants) |
| Sub-components (e.g. map inside a video) | **Part of the single Product** — not a separate note or roll-up | — |
| Status workflow (8 states) | `status:` property w/ fixed value set | TaskNotes custom statuses / Metabind dropdown |
| Custom fields (§4 of Redmine plan) | Frontmatter properties | Templater prompts on creation |
| Priority, due/start date, %done | Frontmatter properties | core Properties / Metabind |
| created / closed-on dates | `created:` + `done:`/`completed:` properties | Templater + TaskNotes (auto-stamps completion) |
| Blocked (boolean + reason) | `blocked: true` + `blocked_reason:` | Metabind toggle |
| Saved queries / boards | **`.base` views** (table, cards, kanban-ish) | Bases |
| Kanban board | TaskNotes Kanban view (Bases-powered) | TaskNotes |
| Calendar / due-date view | TaskNotes Calendar/Agenda view | TaskNotes |
| Gantt | *No true equivalent* — calendar + sort-by-date covers most | Bases/TaskNotes |
| Roadmap / versions | `version:` property + a Bases view grouped by version w/ count summary | Bases |
| Metrics (volume/turnaround/backlog) | Bases views: group-by + **summary rows** (count/avg) + formula columns (turnaround = done − created) | Bases formulas |
| Activity feed (shift handoff) | Bases view sorted by `file.mtime` desc **+** each Product's body = timestamped journal | Bases + note body |
| Per-project Wiki (KB) | Obsidian *is* a wiki — folder of how-to notes, folder-notes as tool landing pages | Foldernotes |
| Time tracking (spent hours) | **Kept.** TaskNotes start/stop + entries (Variant A) *or* per-phase `time_*_min` + Metabind buttons (Variant B) | TaskNotes / Metabind |
| Watchers / news / forums / SCM | **Dropped** — single-operator, no team | — |

## Plugin roster

Already on (core): **Bases**, Properties, Templates, Daily notes, Graph, Backlinks, Tag pane, Bookmarks, Sync.

Community plugins (you named these):
- **Templater** ✅ — a `New Product` template that *prompts* for fields, stamps `created:`, and auto-generates the `product_id`. This is the
  anti-"high-maintenance" lever: creating an issue = one command, no raw YAML typing.
- **Foldernotes** ✅ — Projects and KB tools become folders with a landing note; Products live flat inside `Production/`.
- **Metabind** ✅ — in-note buttons/dropdowns to change status, toggle Blocked, set fields → operator never hand-edits YAML.
- **TaskNotes** — purpose-built task layer (kanban/calendar/agenda/time-tracking, Bases-native). *Used only in Variant A — see §Two Build Variants.*

> [!warning] Air-gap reality
> Every community plugin must be **manually transferred, version-matched, and updated by hand** on the
> air-gapped box (same drill as Redmine plugins). TaskNotes is the heaviest dependency and the
> fastest-moving (it just shipped a breaking **v4 that now *requires* Bases** + Obsidian 1.10.1+). That
> cuts against the "install once, runs for years" value you prized in the Redmine decision. Hence ⟂A is real,
> not rhetorical.

## Proposed vault structure (illustrative)

```
CAPS/
├── Production/                     ← folder-note = Production project dashboard (Bases views embedded)
│   ├── Production.md
│   ├── AVD26001 Airfield FMV clip.md      ← Product (the deliverable = the task)
│   ├── AGR26002 Annotated map.md          ← Product
│   └── AGR26003 Standalone graphic.md     ← Product (all Products live flat here)
├── Knowledge Base/
│   ├── Knowledge Base.md           ← folder-note = KB index
│   ├── DaVinci Resolve/ …
│   ├── FFMPEG/ …
│   ├── R & RStudio/ …
│   └── This System (Operator Guide)/ …
├── _Templates/                     ← Templater templates (New Product, KB page)
└── _Views/                         ← .base files (Active, Inbox, Overdue, Blocked, Metrics, Activity)
```

(No separate daily shift-log folder — per your call, handoff = the Activity view + each Product's in-note journal.)

Example **Product** note frontmatter (as actually shipped by `_Templates/New Product.md`):

```yaml
---
tracker: product            # product | project  (NOT `type` — collides with a Bases built-in)
tags: [task]
cssclasses: [product]       # targets the production.css snippet (layout + info-box handling)
product_id: AVD26001        # auto-generated by Templater: <program:1><type:2><year:2><seq:3>
program: A                  # A | B | C  (placeholder program codes)
title: Warehouse B Loading
status: Production           # Inbox→Backlog→Preproduction→Production→Postproduction→Draft→Published→Archived
priority: routine           # routine | priority | immediate
product_type: video         # video | graphic | map | report
collection_platform: MQ-9
mission:                    # ↓ the four Area links are LISTS — a Product can hold one or more of each
  - "[[A26B001 FL26032]]"
customer:
  - "[[AS263J2 J2]]"
country:
  - "[[GER Germany]]"
  - "[[MEX Mexico]]"
target:
  - "[[WH-02 Warehouse B]]"
duration_sec: 95
classification: "<marking + caveats>"
created: 2026-06-24
due: 2026-06-26
done:                       # stamped automatically by the Publish button → turnaround = done − created
time_pre_min: 0             # ↓ per-phase effort, driven by +15/+30/-15 buttons (needs JS Engine)
time_prod_min: 0
time_post_min: 0
notes:                      # ↓ free-text info boxes (Meta Bind text areas, hidden from properties panel)
sourcing:
coordination:
feedback:
---
```

> The four Area links (`mission` / `customer` / `country` / `target`) are **multi-value lists** — each
> Product can reference several Missions, Customers, Countries, or Targets. The `notes` / `sourcing` /
> `coordination` / `feedback` fields back the in-note **Notes / Sourcing / Coordination / Feedback**
> text boxes (editable in Reading view); the `production` CSS snippet hides them from the properties UI.

> [!info] Product ID format
> `product_id` = `<program:1char><type:2char><year:2digit><seq:3digit>` — e.g. `AVD26001` = program **A**, type **VD** (video), year **26** (2026), sequence **001**. Templater generates it by scanning existing notes for the highest current-year sequence and adding 1. The sequence is **global** across all programs and types and **resets each calendar year** — so no duplicates, and it survives note deletions.

## What the views look like (Bases)

- **Inbox triage** — table, filter `status == "Inbox"`, sort by `created`.
- **Active board** — kanban/cards grouped by `status`, excluding closed (Published/Archived).
- **Overdue** — `due < now() AND status not-closed`.
- **Blocked** — `blocked == true`, showing `blocked_reason`.
- **Throughput** — `status == Published`, filter to period, **group by `product_type`**, summary row = count.
- **Backlog by status** — group by `status`, count summary.
- **By requester / platform** — group by `requester` / `collection_platform`, count summary.
- **Turnaround** — formula column `(done - created)` in days; summary = average.
- **Effort** — per-phase `time_*_min` summed + a `total_min` formula (Variant B) or TaskNotes time entries (Variant A), per Product / grouped by product_type.
- **Shift activity** — table sorted by `file.mtime` desc (what moved recently); the operator opens a row to read its in-note journal for the "why." This pair *is* the handoff.

## Two Build Variants  (← the one decision left)

Both variants store **identical frontmatter** on every Product. That's deliberate: the *data*
is plugin-agnostic plain markdown, so you can start on one variant and switch later without a migration.
The only difference is **what drives the UI on top of that data.**

### Variant A — TaskNotes-led  *(lowest operator effort at runtime)*

- Each Product is a **TaskNotes task note**. Operator creates/edits via the TaskNotes UI and natural-language input.
- **Status workflow:** TaskNotes custom statuses = your 8 states; flag **Published/Archived** as completed →
  TaskNotes **auto-stamps the completion date** (= Redmine's closed-on) → turnaround is free.
- **Board / calendar:** TaskNotes ships **Kanban** (drag a card to change status), **Calendar**, **Agenda**,
  and Task-list views as `.base` files. You get a real drag-board and a month grid out of the box.
- **Time tracking (kept):** built-in **start/stop timer + time entries** in frontmatter, optional Pomodoro. Native. ✅
- **Metrics:** Bases views over the task frontmatter; TaskNotes also exposes computed props (`isOverdue`,
  `daysUntilDue`, urgency) you can surface as columns.
- **Plugins to transfer & freeze on the air-gapped box:** Templater, Foldernotes, Metabind, **TaskNotes** (Bases is core).
- **Longevity hedge:** TaskNotes property names are **remappable**, so we point them at the *same* frontmatter
  keys Variant B uses. If a future Obsidian ever breaks TaskNotes, every Product is still a plain readable
  note and your Bases metric views keep working — you'd lose the kanban/calendar UI, not the data.
- **Air-gap note:** the usual knock on TaskNotes (fast, breaking releases — it just shipped a v4 that requires
  Bases) **mostly doesn't apply here**: on an air-gapped box you *pin one version and never auto-update*, exactly
  like a Redmine plugin. The breaking-change risk only bites people chasing updates.
- **Stand-up effort:** **LOW.** Most views come from the plugin; you mainly configure statuses + a Templater intake.

### Variant B — Core-only + your three plugins  *(maximum longevity / reviewability)*

- Each Product is a **plain note**, same frontmatter schema. No TaskNotes.
- **Status workflow:** a fixed-value `status:` property changed via a **Metabind inline dropdown** in the note.
  A Metabind **"Mark Published"** button sets `status: Published` *and* stamps `done:` in one click (closed-on).
- **Board / calendar — the real trade:** every view is a **hand-built Bases `.base`**. A "cards grouped by status"
  view *looks* like a board but **Bases cards are not drag-between-columns** (core Bases has no drag-kanban) —
  status changes happen via the in-note dropdown instead. And **core Bases has no calendar/month view** (its
  view types are table/cards/list/map) → due dates show as a **table sorted by due**, not a grid. If a visual
  month calendar or drag-board matters to the operator, that's the cost of going core-only.
- **Time tracking (kept, hand-rolled):** **per-phase** effort in `time_pre_min` / `time_prod_min` / `time_post_min`,
  bumped via Metabind **+15 / +30 / -15** buttons (no typing, no mental math), with a live JS-computed **total (h/m)
  and per-phase %** display. Less precise than a real start/stop timer, but durable — the minutes live in frontmatter.
- **Plugins to transfer & freeze:** Templater, Folder Notes, Meta Bind, Homepage, **JS Engine** — all stable, and
  JS Engine is by the same author as Meta Bind (it only powers the buttons/display; the data survives without it).
- **Stand-up effort:** **MEDIUM–HIGH.** You (well, I) build every Bases view and the Metabind controls up front —
  but once built it's frozen, self-contained, and reviewable line-by-line. This is the truest match to the Redmine
  "install once, runs for years, source is reviewable" value.

### Side-by-side

| | **A — TaskNotes-led** | **B — Core-only** |
|---|---|---|
| Operator effort (runtime) | **Lowest** (UI-driven) | Low-ish (dropdowns/buttons) |
| Build effort (upfront) | Low | **Medium–high** |
| Drag kanban | ✅ native | ❌ (cards + dropdown) |
| Month calendar | ✅ native | ❌ (date-sorted table) |
| Time tracking | ✅ start/stop timer | ✅ per-phase +15/+30/-15 buttons + live total |
| Closed-on auto-stamp | ✅ automatic | ✅ via Metabind Publish button |
| Plugins to maintain on air-gap | 4 (incl. fast-moving TaskNotes, **pinned**) | **5** (all stable) |
| Longevity / reviewability | Good (data survives even if plugin dies) | **Best** (plain notes + 3 small plugins) |
| Data portability | Identical frontmatter ↔ | Identical frontmatter ↔ |

### Decision — locked 2026-06-30: **Variant B (Core-only)**

The original draft leaned Variant A (TaskNotes) for its drag-board, calendar, and timer — but you don't want
any of those three, which were TaskNotes' only real advantages. Strip them away and A is a heavier,
faster-moving plugin earning nothing, and it drifted the data on first contact (see §The one fact…). **Variant
B wins:** "core Bases + 3 stable plugins + plain notes, reviewable forever" is the truest match to the Redmine
value you prized, and it clears the low-maintenance bar without the churn risk.

- **Subtasks:** native `- [ ]` checkboxes inside each Product, in three phases (**Preproduction** / **Production**
  / **Postproduction**) — ticked off by hand, no stamp plugin.
- **Time tracking:** **per-phase** minutes (`time_pre_min` / `time_prod_min` / `time_post_min`) via +15/+30/-15
  buttons; the Metrics base sums each phase and a `total_min` formula. Live total (h/m) + per-phase % in-note.
- **Final plugin roster:** Templater, Meta Bind, Folder Notes, **Homepage**, **JS Engine** — all pinned on the
  air-gapped box.

**v1 is built.** Frontmatter schema, the Templater intake, the four Area templates, both `.base` views, and the
Meta Bind creation buttons all exist — see [[_Manual — Build From Scratch]] to rebuild from scratch and
[[_Setup — Variant B (Core Build)]] for the install/config checklist.

> **Now built (2026-07-01):** the **"Mark Published"** button sets `status: Published` + stamps `done:` in one
> click; per-phase **+15/+30/-15** time buttons with a live total (h/m) + per-phase % display (via **JS Engine**);
> a live **subtask % progress bar** in the Subtasks callout; multi-value Area links; per-Product folder notes;
> and the four free-text info boxes.

## Discussion notes
<!-- Jot answers/changes here; we'll work through them next session. -->
