---
tags: [home, index]
title: Home
---

# 🏠 Vault Home

Production tracking for the video team — auto-numbered **Products** linked to reference **Areas**.

## Start here
- 📖 [[_Manual — Build From Scratch]] — full setup manual (rebuild the whole system from scratch)
- 🧩 [[_Setup — Variant B (Core Build)]] — plugin install + config checklist (the chosen build)
- ⚙️ [[_Setup — Product Codes]] — where to change the program / product-type codes

## Dashboards
- 🎬 [[Production]] — create Products (➕ button) and see the active board
- 🗂️ [[Areas]] — create Missions / Customers / Countries / Targets and browse the registries

## Boards (Bases)
- `_Views/Production — Work.base` — Active board · Inbox · Overdue · Recently changed
- `_Views/Production — Metrics.base` — Throughput · Backlog · By customer / mission / country / target · Turnaround & effort

## How it works (quick)
1. Create **Areas** first (Products can only link to Areas that already exist).
2. Create a **Product** from the Production dashboard — its ID (`AVD26001`) auto-fills, no duplicates.
   Each Product becomes its **own folder** (a folder note), can link **one or more** Missions / Customers /
   Countries / Targets, has free-text **Notes / Sourcing / Coordination / Feedback** boxes you can type into
   right in Reading view, and tracks effort **per phase** with **+15 / +30 / -15** buttons (live total in h/m).
3. Work the **boards**; each Product row shows its linked Mission(s) / Customer(s) / Country(ies) / Target(s).

> See [[_Manual — Build From Scratch]] for the complete details, file contents, and troubleshooting.
