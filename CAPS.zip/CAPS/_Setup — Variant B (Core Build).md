---
tracker: setup-guide
tags: [meta/planning, setup]
created: 2026-06-30
---

# Variant B Setup — Core-only, air-gapped (the chosen build)

Companion to [[Obsidian PM Vault Plan]] and [[_Manual — Build From Scratch]]. This is the install +
config checklist for the **locked v1 build**: core **Bases** + four stable community plugins.
**No TaskNotes, no Obsidian Tasks, no task plugin at all** — subtasks are plain checkboxes.

The sample notes and the two `.base` views already work with core Bases alone — the plugins below add
the intake forms, buttons, and folder landing pages on top of the same frontmatter.

## What already works (open these now)
- `_Views/Production — Work.base` → Active board · Inbox · Overdue · Recently changed.
- `_Views/Production — Metrics.base` → Throughput · Backlog by status · By customer / mission / country / target · Turnaround & effort.
- `Production/Production.md` → **➕ New Product** button + embedded board.
- `Areas/Areas.md` → four creation buttons + a registry table per Area type.

Once you've created a few Products: past-due ones show in **Overdue**; anything set to **Published** shows
in **Throughput** with **Turnaround** (`done − created`) and summed **Spent** time.

## Plugins to install (air-gapped transfer)

On an internet-connected machine, install each from **Settings → Community plugins → Browse**, then copy
its folder from `.obsidian/plugins/<id>/` to the same path on the air-gapped vault. **Note the version and
pin it — don't auto-update.** Treat each like a Redmine plugin: install once, freeze.

| Plugin | id | Role here |
|---|---|---|
| **Templater** | `templater-obsidian` | Prompt-driven intake (`New Product`) — auto-generates the Product ID |
| **Meta Bind** | `obsidian-meta-bind-plugin` | In-note creation buttons (New Product, New Mission…) |
| **Folder Notes** | `folder-notes` | Makes `Production/` and `Areas/` open their landing note |
| **Homepage** | `homepage` | Opens the Production dashboard automatically at launch (start-of-shift) |
| **JS Engine** | `js-engine` | Powers Meta Bind `evaluate: true` — the time +15/+30/-15 buttons, Publish auto-date, live time breakdown |

After copying, enable each under **Settings → Community plugins**.

> [!note] Why no task plugin
> An auto completion-date stamp on subtasks was evaluated (Task Collector) and **dropped**: its only
> no-popup trigger is a hotkey rather than a plain checkbox click, and the feature wasn't worth an extra
> air-gapped plugin. Subtasks are plain `- [ ]` checkboxes — tick them off; if a step's completion time
> matters, note it in the Product's `## Journal`.

## Templater configuration
- Settings → Templater → **Template folder:** `_Templates`.
- Leave "Trigger Templater on new file creation" **off** (buttons/commands trigger it instead).
- Optional: bind a hotkey to "Templater: Create new note from template" → *New Product*. Or just use the
  **➕ New Product** button on the Production dashboard.
- Product IDs auto-generate as `<program:1><type:2><year:2><seq:3>` (e.g. `AVD26001`), global sequence,
  reset each calendar year — Templater scans existing notes for the highest current-year seq and adds 1.

## Meta Bind configuration
- Ensure **buttons** are enabled; turn on **"Render buttons in live preview"** so they're clickable
  without switching to Reading view.
- **JS Engine is required** (added deliberately — see the time-tracking section). Meta Bind hands
  `evaluate: true` expressions to JS Engine; without it the time buttons, the Publish auto-date, and the
  live time breakdown won't work (the rest of the vault still would). It's a convenience layer over
  durable frontmatter — remove it and your recorded minutes survive in YAML.
- Controls: an `inlineSelect` for status, a `date` picker for `done`, and Meta Bind **buttons** for the
  Publish action and per-phase time. Every button needs a `style:` field
  (`default` / `primary` / `plain` / `destructive`) — it's mandatory.

## Folder Notes configuration
- Enable folder-note behavior (folder-name-matches-note): clicking `Production/` opens `Production.md`,
  clicking `Areas/` opens `Areas.md`.
- Settings to match: **Folder note name** = `{{folder_name}}`, **storage location** = *inside the folder*,
  **hide folder note** = on. With these, every Product created by **➕ New Product** lands in its own
  folder as a folder note (`Production/AVD26001 Title/AVD26001 Title.md`) — click the folder to open the
  Product, and keep source files / exports beside it. (Attachments, renames, and the boards all still work.)

## Homepage configuration
- Settings → **Homepage** → set **Homepage** to `Production/Production` (or `Welcome`), and enable
  **Open on startup**.
- Now every launch lands on your dashboard — the start-of-shift board — instead of the last-open note.

## Appearance — enable the CSS snippet
- The vault ships with `.obsidian/snippets/production.css`; copy it to the air-gapped vault along with the
  plugins.
- Settings → **Appearance → CSS snippets** → click the **refresh** icon → toggle **`production`** on.
- It gives Product notes (which carry `cssclasses: [product]`) **full width** and lays the three subtask
  phases out in **columns** (best in Reading view). It also **sizes the free-text info boxes** and
  **hides their backing fields** (`notes` / `sourcing` / `coordination` / `feedback`) from the properties
  panel. The layout parts are cosmetic, but leave it **on** — with it off, those four fields show up as
  raw properties.
- The full-width rules are theme-agnostic: they work with the **default** Obsidian theme and with the
  **Minimal** theme (which sizes content from different CSS variables), in both reading and editing views.

## The status workflow (core-only, no drag board)
Eight states in `status:`: **Inbox → Backlog → Preproduction → Production → Postproduction → Draft →
Published → Archived.** Change status from the **inline dropdown** in each Product's *Controls* section
(one click, no JS). Setting **Published** is your "closed": click the **✅ Mark Published** button — it
sets the status **and** stamps today's date into **Done** in one click, so Turnaround computes automatically.

## Time tracking (per-phase, button-driven)
Each Product tracks effort **per phase** in three frontmatter fields — `time_pre_min`, `time_prod_min`,
`time_post_min` — via **+15 / +30 / -15** buttons in the *Time* section. No typing, no mental math, no
fudging: click a button, the minute count updates. A **Reset time** button zeros all three. The fields are
hidden from the properties panel (CSS), so the buttons are the only entry path — which keeps the numbers
consistent. Above the buttons, a live **JS view** shows the computed **total in h/m** and each phase's
**share %**, updating as you click. The Metrics base derives the total via a `total_min` formula
(`time_pre_min + time_prod_min + time_post_min`) and sums per-phase columns. Buttons and the display need
the **JS Engine** plugin; the recorded minutes live in plain frontmatter and survive without it.

## Subtasks (native checkboxes)
Every new Product ships with a `## Subtasks` callout in three phases:
- **Preproduction:** Obsidian · Project · Files
- **Production:** Cut · Stab · Color · Build · Draft
- **Postproduction:** Render · Review · Publish

Tick boxes as you complete steps. Add or remove steps freely per job; they're plain markdown, so they
never touch frontmatter or the boards. (The `production` CSS snippet lays the three phases out in columns.)
At the top of the callout a **JS Engine progress bar** counts the callout's checkboxes and shows
**done/total + %**, updating live as you tick (it re-reads on `metadataCache` change). It counts only
lines inside the callout (`> - [ ]`), so stray checkboxes elsewhere in the note don't skew it — and since
it counts whatever boxes are there, adding/removing subtasks just works.

## Info boxes (free-text, reading-view editable)
Below the subtasks, every Product ships with four **Meta Bind text areas** — **Notes**, **Sourcing /
Collection**, **Coordination / Tasking**, **Feedback / Revisions**. Type into them directly in **Reading
view**; no edit mode, no YAML. Each writes to a hidden field (`notes` / `sourcing` / `coordination` /
`feedback`) that the `production` snippet keeps out of the properties panel, so they read as plain boxes.

## Multi-value Areas
The four Area links — Mission / Customer / Country / Target — are **lists**: a Product can carry more than
one of each (e.g. two countries, two targets). The **➕ New Product** picker adds them one at a time until
you choose **✓ done**, and stores them as YAML lists. Every value backlinks to its Area note.

## Verify (create a couple of test Products first)
1. Open the two `.base` files → confirm they populate as described (works pre-plugins).
2. Run **➕ New Product** → confirm a complete note from prompts, auto ID, no manual YAML, with the
   three-phase Subtasks checklist and the four info boxes in the body. Pick **two** countries (and/or
   targets) to confirm the Area pickers are multi-select and land as a YAML list. Confirm the note lands
   in its **own folder** (`Production/AVD26001 …/`) as a folder note — clicking the folder opens it.
3. Set a Product to **Published** and fill `done:` → confirm it leaves the Active board and lands in
   Throughput with its Turnaround + summed Spent time.
4. Open an Area note (Mission / Customer / …) → confirm its **backlinks** pane lists the Products linking to it.
5. With the `production` snippet on, open a Product in Reading view → confirm full-width + 3-column subtasks.
6. Restart Obsidian → confirm it opens on the Production dashboard (Homepage).

## Bases gotchas (carried over — learned the hard way)
- **Don't name a property `type`** (collides with a Bases built-in) — we use `tracker`. Avoid `file`,
  `note`, `tags` as property names too.
- **Filters use BARE property names** (`status != "Published"`), not `note.status`. The `note.` / `file.` /
  `formula.` prefixes are only for `order`, `groupBy.property`, `summaries`, and the `properties:` block.
- **No `sort:` key** — sort interactively by clicking a column header; views rely on `groupBy` + `order`.
- **Turnaround** = `formula.turnaround: '(done - created)'`, rendering as a duration ("3 days"). Effort is
  summed from the per-phase fields (`time_pre_min` / `time_prod_min` / `time_post_min`, each a `Sum`
  summary) plus a `total_min` formula for the combined total. Note: summarizing a *formula* column
  (`formula.total_min: Sum`) depends on your Bases version — if the group-total footer doesn't render,
  the three per-phase `Sum`s still do, and they add up to the same number.
