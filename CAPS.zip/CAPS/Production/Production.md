---
tracker: project
tags: [sample]
title: Production
created: 2026-06-21
---

# Production — Project Dashboard

## Quick actions

```meta-bind-button
label: "➕ New Product"
icon: "plus"
style: primary
tooltip: "Create a product with an auto-generated ID (AVD26001…)"
id: "new-product"
actions:
  - type: templaterCreateNote
    templateFile: "_Templates/New Product.md"
    folderPath: "Production"
    fileName: "Untitled Product"
    openNote: true
```

> [!info] Folder note
> This note is the landing page for the **Production** folder (via Foldernotes once installed).
> Below is a live Bases board embedded as a base code block — it works right now with the
> core Bases plugin, no community plugins needed.

## Active work (board)

```base
views:
  - type: table
    name: Active
    filters:
      and:
        - tracker == "product"
    groupBy:
      property: status
      direction: ASC
    order:
      - file.name
      - priority
      - due

```

## Full views
- **Work views** → open `_Views/Production — Work.base` (Inbox · Active board · Overdue · Blocked · Recently changed)
- **Metrics** → open `_Views/Production — Metrics.base` (Throughput · Backlog · By requester · Turnaround & effort)

<!-- sample: true — delete this whole Production/ folder to remove the demo -->
