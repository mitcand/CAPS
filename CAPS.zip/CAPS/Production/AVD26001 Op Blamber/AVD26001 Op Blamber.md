---
tracker: product
tags:
  - task
cssclasses:
  - product
product_id: AVD26001
program: A
title: Op Blamber
status: Published
priority: routine
product_type: video
collection_platform: 123
mission:
  - "[[A26B001 FL26032]]"
customer:
  - "[[BHTG Black House Team Group]]"
country:
  - "[[GER Germany]]"
target:
  - "[[WH-01 Warehouse A]]"
duration_sec:
classification: UNCLASSIFIED
created: 2026-07-01
due:
done: 2026-07-01
time_pre_min: 45
time_prod_min: 60
time_post_min: 105
notes:
sourcing:
coordination:
feedback:
---
# AVD26001 — Op Blamber

## Controls
**Status** `INPUT[inlineSelect(option(Inbox), option(Backlog), option(Preproduction), option(Production), option(Postproduction), option(Draft), option(Published), option(Archived)):status]` · **Done** `INPUT[date:done]`

```meta-bind-button
label: "✅ Mark Published"
style: primary
id: "mark-published"
actions:
  - type: updateMetadata
    bindTarget: status
    evaluate: false
    value: "Published"
  - type: updateMetadata
    bindTarget: done
    evaluate: true
    value: new Date().toLocaleDateString('en-CA')
```

## Time
```meta-bind-js-view
{time_pre_min} as pre
{time_prod_min} as prod
{time_post_min} as post
---
const pre  = Number(context.bound.pre)  || 0;
const prod = Number(context.bound.prod) || 0;
const post = Number(context.bound.post) || 0;
const total = pre + prod + post;
const hm  = m => (m >= 60 ? Math.floor(m / 60) + "h " : "") + (m % 60) + "m";
const pct = m => total ? Math.round(m / total * 100) : 0;
return engine.markdown.create(
  "**Total:** " + hm(total) + "  \n" +
  "Preproduction " + hm(pre) + " (" + pct(pre) + "%) · " +
  "Production " + hm(prod) + " (" + pct(prod) + "%) · " +
  "Postproduction " + hm(post) + " (" + pct(post) + "%)"
);
```

**Preproduction**  `BUTTON[t-pre-sub]` `BUTTON[t-pre-15]` `BUTTON[t-pre-30]`
**Production**  `BUTTON[t-prod-sub]` `BUTTON[t-prod-15]` `BUTTON[t-prod-30]`
**Postproduction**  `BUTTON[t-post-sub]` `BUTTON[t-post-15]` `BUTTON[t-post-30]`
`BUTTON[t-reset]`

```meta-bind-button
label: "-15"
hidden: true
id: "t-pre-sub"
style: default
action:
  type: updateMetadata
  bindTarget: time_pre_min
  evaluate: true
  value: Math.max(x - 15, 0)
```
```meta-bind-button
label: "+15"
hidden: true
id: "t-pre-15"
style: default
action:
  type: updateMetadata
  bindTarget: time_pre_min
  evaluate: true
  value: x + 15
```
```meta-bind-button
label: "+30"
hidden: true
id: "t-pre-30"
style: default
action:
  type: updateMetadata
  bindTarget: time_pre_min
  evaluate: true
  value: x + 30
```
```meta-bind-button
label: "-15"
hidden: true
id: "t-prod-sub"
style: default
action:
  type: updateMetadata
  bindTarget: time_prod_min
  evaluate: true
  value: Math.max(x - 15, 0)
```
```meta-bind-button
label: "+15"
hidden: true
id: "t-prod-15"
style: default
action:
  type: updateMetadata
  bindTarget: time_prod_min
  evaluate: true
  value: x + 15
```
```meta-bind-button
label: "+30"
hidden: true
id: "t-prod-30"
style: default
action:
  type: updateMetadata
  bindTarget: time_prod_min
  evaluate: true
  value: x + 30
```
```meta-bind-button
label: "-15"
hidden: true
id: "t-post-sub"
style: default
action:
  type: updateMetadata
  bindTarget: time_post_min
  evaluate: true
  value: Math.max(x - 15, 0)
```
```meta-bind-button
label: "+15"
hidden: true
id: "t-post-15"
style: default
action:
  type: updateMetadata
  bindTarget: time_post_min
  evaluate: true
  value: x + 15
```
```meta-bind-button
label: "+30"
hidden: true
id: "t-post-30"
style: default
action:
  type: updateMetadata
  bindTarget: time_post_min
  evaluate: true
  value: x + 30
```
```meta-bind-button
label: "Reset time"
hidden: true
id: "t-reset"
style: destructive
actions:
  - type: updateMetadata
    bindTarget: time_pre_min
    evaluate: false
    value: 0
  - type: updateMetadata
    bindTarget: time_prod_min
    evaluate: false
    value: 0
  - type: updateMetadata
    bindTarget: time_post_min
    evaluate: false
    value: 0
```

> [!subtasks]+ Subtasks
> ```js-engine
> const file = context.file;
> const A = engine.app || globalThis.app;
> const build = async () => {
>   const text = await A.vault.cachedRead(file);
>   const boxes = text.split("\n").filter(l => /^>\s*- \[.\]/.test(l));
>   const done = boxes.filter(l => /\[[xX]\]/.test(l)).length;
>   const total = boxes.length;
>   const pct = total ? Math.round((done / total) * 100) : 0;
>   const filled = Math.round(pct / 10);
>   const bar = "█".repeat(filled) + "░".repeat(10 - filled);
>   return engine.markdown.create("`" + bar + "` **" + pct + "%** · " + done + "/" + total + " done");
> };
> const comp = engine.reactive(build);
> component.registerEvent(A.metadataCache.on("changed", (f) => { if (f && f.path === file.path) comp.refresh(); }));
> return comp;
> ```
>
> ### Preproduction
> - [x] Obsidian
> - [x] Project
> - [x] Files
>
> ### Production
> - [x] Cut
> - [x] Stab
> - [x] Color
> - [x] Build
> - [x] Draft
>
> ### Postproduction
> - [x] Render
> - [x] Review
> - [x] Publish

## Notes
```meta-bind
INPUT[textArea:notes]
```

## Sourcing / Collection
```meta-bind
INPUT[textArea:sourcing]
```

## Coordination / Tasking
```meta-bind
INPUT[textArea:coordination]
```

## Feedback / Revisions
```meta-bind
INPUT[textArea:feedback]
```

## Journal
- 2026-07-01 18:11 — created.
