# Video Project Check-In / Check-Out Tool (Scaffold)

A PowerShell + WinForms GUI that governs where a project's **media** lives:
**parked on the SAN**, or **checked out to exactly one PWS**. The DaVinci project
itself stays in the Project Server database and is never touched by this tool.

> This is a **scaffold** — correct and runnable, but see *Known limits* before
> using it on real projects.

## How it works

- **Model:** exclusive lease, single copy. Media is either on the SAN or on one PWS, never both.
- **Check-out:** robocopy SAN → `E:\Projects\<name>`, verify, then delete the SAN copy.
- **Check-in:** robocopy `E:\Projects\<name>` → SAN, verify, then delete the local copy.
- **No relinking:** every PWS uses the *same* local root (`E:\Projects`), so media always
  returns to the exact path Resolve stored.
- **State** lives on the SAN — one `<project>.json` per project in the `_state` folder,
  plus an append-only `_audit.log`. An atomic `<project>.lock` prevents two workstations
  transferring the same project at once.
- **Copy-verify-delete order:** the source is deleted only after the copy is verified,
  so an interrupted transfer never loses data.

## Setup (per workstation)

1. Copy this whole folder to each PWS (e.g. `C:\Tools\CheckInOut`).
2. Edit **`CheckInOut.config.psd1`**:
   - `LocalRoot` — must be **identical on every PWS** (e.g. `E:\Projects`).
   - `SanParkRoot` / `SanStateRoot` — the NetApp UNC paths.
   - `Admins` — usernames allowed to Force-Release.
3. Double-click **`Launch-CheckInOut.cmd`**.

`LocalRoot` should match the media root your Obsidian/Templater step creates, so a
checked-out project lands exactly where the Resolve timeline expects it.

## Using it

| Button | Action |
|---|---|
| **Refresh** | Re-scan state files + folders. |
| **Check Out** | Pull selected project's media SAN → this PWS (must be `available`). |
| **Check In** | Push it back this PWS → SAN (must be checked out *here*). |
| **Register...** | Add an existing folder (SAN or local) into the tracking system. |
| **Force Release** | Admin-only: clear a stale lock. Does **not** move media — verify location after. |
| **Open Folder** | Open the project's current media folder in Explorer. |

Row colors: green = available, amber = checked-out, red = in-transit, grey = unregistered.

**Typical handoff (PWS01 → PWS02):** person on PWS01 selects the project → **Check In**.
Person on PWS02 → **Refresh** → select it → **Check Out**. Media is now local on PWS02
and the timeline relinks automatically.

## Known limits (scaffold)

- **UI blocks during a transfer** (robocopy runs synchronously, `-Wait`). The window
  will say "not responding" on large moves — it is still working. First roadmap item is
  async transfer with a live progress bar.
- **Verification** is exit-code + destination-exists, not a content hash. Add hashing for
  extra safety.
- **Single copy while checked out** — the only copy sits on one local drive. Check in
  promptly; consider a DB project backup on check-in.
- No direct PWS-to-PWS transfer yet (every handoff is two SAN transfers).

## Requirements

- Windows PowerShell 5.1 (built into Windows) — no external modules.
- `robocopy.exe` (built into Windows).
