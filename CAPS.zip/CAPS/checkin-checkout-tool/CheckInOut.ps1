#Requires -Version 5.1
<#
    Video Project Check-In / Check-Out tool  (SCAFFOLD)

    Governs where a project's MEDIA lives: parked on the SAN, or checked out to
    exactly one PWS. The Resolve project itself stays in the Project Server DB and
    is not touched by this tool.

    Model: exclusive lease, single authoritative copy.
      check-out : robocopy SAN -> local E:\Projects\<name>, then delete SAN copy
      check-in  : robocopy local -> SAN, then delete local copy
    Copy is always verified BEFORE the source is deleted, so an interrupted
    transfer never loses data.

    See README.md for deployment. Edit CheckInOut.config.psd1 for paths.
#>
[CmdletBinding()]
param(
    [string]$ConfigPath = (Join-Path $PSScriptRoot 'CheckInOut.config.psd1')
)

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# ---------------------------------------------------------------------------
# Config + identity
# ---------------------------------------------------------------------------
if (-not (Test-Path $ConfigPath)) { throw "Config not found: $ConfigPath" }
$script:Config  = Import-PowerShellDataFile -Path $ConfigPath
$script:Machine = $env:COMPUTERNAME
$script:User    = $env:USERNAME

if (-not (Test-Path $script:Config.SanStateRoot)) {
    New-Item -ItemType Directory -Path $script:Config.SanStateRoot -Force | Out-Null
}

# ---------------------------------------------------------------------------
# State helpers  (one JSON file per project on the SAN)
# ---------------------------------------------------------------------------
function Get-StatePath { param([string]$Project) Join-Path $script:Config.SanStateRoot "$Project.json" }

function Read-State {
    param([string]$Project)
    $p = Get-StatePath $Project
    if (Test-Path $p) { Get-Content $p -Raw | ConvertFrom-Json } else { $null }
}

function Write-State {
    param($State)
    ($State | ConvertTo-Json -Depth 5) | Set-Content -Path (Get-StatePath $State.project) -Encoding UTF8
}

function New-State {
    param([string]$Project, [string]$Status, [string]$Location, [string]$LockedBy = '', [string]$Machine = '')
    [pscustomobject]@{
        project  = $Project
        status   = $Status
        location = $Location
        lockedBy = $LockedBy
        machine  = $Machine
        since    = (Get-Date).ToString('s')
    }
}

function Write-Audit {
    param([string]$Message)
    $line = '{0}  {1}\{2}  {3}' -f (Get-Date).ToString('s'), $script:Machine, $script:User, $Message
    Add-Content -Path (Join-Path $script:Config.SanStateRoot '_audit.log') -Value $line
}

# ---------------------------------------------------------------------------
# Atomic transit lock — guards against two workstations moving the same
# project simultaneously. CreateNew throws if the file already exists.
# ---------------------------------------------------------------------------
function Enter-TransitLock {
    param([string]$Project)
    $lock = Join-Path $script:Config.SanStateRoot "$Project.lock"
    try {
        $fs = [System.IO.File]::Open($lock, [System.IO.FileMode]::CreateNew,
                                     [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)
        $bytes = [System.Text.Encoding]::UTF8.GetBytes("$script:Machine\$script:User $((Get-Date).ToString('s'))")
        $fs.Write($bytes, 0, $bytes.Length)
        $fs.Close()
        return $lock
    } catch {
        throw "Project '$Project' is currently being transferred by another workstation (transit lock present)."
    }
}
function Exit-TransitLock {
    param([string]$LockPath)
    if ($LockPath -and (Test-Path $LockPath)) { Remove-Item $LockPath -Force }
}

# ---------------------------------------------------------------------------
# Robocopy wrapper.  Exit codes 0-7 = success, >=8 = failure.
# ---------------------------------------------------------------------------
function Invoke-RoboMove {
    param([string]$Source, [string]$Dest)
    New-Item -ItemType Directory -Path $Dest -Force | Out-Null
    $log = Join-Path $env:TEMP ("robocopy_{0}.log" -f ([guid]::NewGuid().ToString('N')))
    $rcArgs = @(
        $Source, $Dest, '/MIR',
        "/MT:$($script:Config.RobocopyThreads)",
        "/R:$($script:Config.RobocopyRetries)",
        "/W:$($script:Config.RobocopyWait)",
        '/NP', '/NDL', "/LOG:$log"
    )
    $p = Start-Process -FilePath 'robocopy.exe' -ArgumentList $rcArgs -NoNewWindow -Wait -PassThru
    [pscustomobject]@{ Success = ($p.ExitCode -lt 8); ExitCode = $p.ExitCode; Log = $log }
}

# ---------------------------------------------------------------------------
# Discovery — merge state files with any bare SAN / local folders.
# ---------------------------------------------------------------------------
function Get-AllProjects {
    $result = @{}
    Get-ChildItem -Path $script:Config.SanStateRoot -Filter '*.json' -ErrorAction SilentlyContinue | ForEach-Object {
        $s = Get-Content $_.FullName -Raw | ConvertFrom-Json
        $result[$s.project] = $s
    }
    Get-ChildItem -Path $script:Config.SanParkRoot -Directory -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -ne '_state' } | ForEach-Object {
            if (-not $result.ContainsKey($_.Name)) {
                $result[$_.Name] = New-State -Project $_.Name -Status 'unregistered' -Location 'SAN'
            }
        }
    Get-ChildItem -Path $script:Config.LocalRoot -Directory -ErrorAction SilentlyContinue | ForEach-Object {
        if (-not $result.ContainsKey($_.Name)) {
            $result[$_.Name] = New-State -Project $_.Name -Status 'unregistered' -Location $script:Machine -Machine $script:Machine
        }
    }
    $result.Values | Sort-Object project
}

# ---------------------------------------------------------------------------
# Operations
# ---------------------------------------------------------------------------
function Register-Project {
    param([string]$Project, [string]$Location)  # Location = 'SAN' or this machine name
    if ($Location -eq 'SAN') {
        $state = New-State -Project $Project -Status 'available' -Location 'SAN'
    } else {
        $state = New-State -Project $Project -Status 'checked-out' -Location $script:Machine -LockedBy $script:User -Machine $script:Machine
    }
    Write-State $state
    Write-Audit "REGISTER        $Project  location=$Location status=$($state.status)"
}

function Invoke-Checkout {
    param([string]$Project)
    $state = Read-State $Project
    if ($null -eq $state)                 { throw "No state record for '$Project'. Register it first." }
    if ($state.status -ne 'available')    { throw "Cannot check out '$Project': status is '$($state.status)' (location $($state.location), lockedBy $($state.lockedBy))." }

    $src = Join-Path $script:Config.SanParkRoot $Project
    $dst = Join-Path $script:Config.LocalRoot   $Project
    if (-not (Test-Path $src)) { throw "SAN media folder not found: $src" }

    $lock = Enter-TransitLock $Project
    try {
        $state.status='in-transit'; $state.location='(transit)'; $state.lockedBy=$script:User; $state.machine=$script:Machine; $state.since=(Get-Date).ToString('s')
        Write-State $state
        Write-Audit "CHECKOUT start  $Project  SAN -> $script:Machine"

        $rc = Invoke-RoboMove -Source $src -Dest $dst
        if (-not $rc.Success)        { throw "Robocopy failed (exit $($rc.ExitCode)). Log: $($rc.Log). Media NOT removed from SAN." }
        if (-not (Test-Path $dst))   { throw "Destination missing after copy: $dst. Media NOT removed from SAN." }

        Remove-Item -Path $src -Recurse -Force        # verified -> safe to remove source
        $state.status='checked-out'; $state.location=$script:Machine
        Write-State $state
        Write-Audit "CHECKOUT done   $Project  now on $script:Machine"
    } finally { Exit-TransitLock $lock }
}

function Invoke-Checkin {
    param([string]$Project)
    $state = Read-State $Project
    if ($null -eq $state)                       { throw "No state record for '$Project'." }
    if ($state.status -ne 'checked-out')        { throw "Cannot check in '$Project': status is '$($state.status)'." }
    if ($state.location -ne $script:Machine)    { throw "Cannot check in '$Project': it is checked out on '$($state.location)', not this machine ($script:Machine). Run the tool there, or Force-Release." }

    $src = Join-Path $script:Config.LocalRoot   $Project
    $dst = Join-Path $script:Config.SanParkRoot $Project
    if (-not (Test-Path $src)) { throw "Local media folder not found: $src" }

    $lock = Enter-TransitLock $Project
    try {
        $state.status='in-transit'; $state.location='(transit)'; $state.since=(Get-Date).ToString('s')
        Write-State $state
        Write-Audit "CHECKIN start   $Project  $script:Machine -> SAN"

        $rc = Invoke-RoboMove -Source $src -Dest $dst
        if (-not $rc.Success)        { throw "Robocopy failed (exit $($rc.ExitCode)). Log: $($rc.Log). Media NOT removed from local." }
        if (-not (Test-Path $dst))   { throw "Destination missing after copy: $dst. Media NOT removed from local." }

        Remove-Item -Path $src -Recurse -Force
        $state.status='available'; $state.location='SAN'; $state.lockedBy=''; $state.machine=''
        Write-State $state
        Write-Audit "CHECKIN done    $Project  now on SAN"
    } finally { Exit-TransitLock $lock }
}

function Invoke-ForceRelease {
    param([string]$Project)
    if ($script:Config.Admins -notcontains $script:User) {
        throw "Force Release requires admin. '$script:User' is not in the Admins list."
    }
    $state = Read-State $Project
    if ($null -eq $state) { throw "No state record for '$Project'." }
    $state.status='available'; $state.location='SAN'; $state.lockedBy=''; $state.machine=''
    Write-State $state
    $lock = Join-Path $script:Config.SanStateRoot "$Project.lock"
    if (Test-Path $lock) { Remove-Item $lock -Force }
    Write-Audit "FORCE-RELEASE   $Project  by $script:User  (VERIFY MEDIA LOCATION MANUALLY)"
}

# ===========================================================================
# UI
# ===========================================================================
function Write-Log {
    param([string]$Text)
    $script:LogBox.AppendText(('[{0}] {1}{2}' -f (Get-Date).ToString('HH:mm:ss'), $Text, [Environment]::NewLine))
}

function Get-SelectedProject {
    if ($script:List.SelectedItems.Count -eq 0) { return $null }
    $script:List.SelectedItems[0].Text
}

function Update-List {
    $script:List.BeginUpdate()
    $script:List.Items.Clear()
    foreach ($p in Get-AllProjects) {
        $item = New-Object System.Windows.Forms.ListViewItem($p.project)
        [void]$item.SubItems.Add([string]$p.status)
        [void]$item.SubItems.Add([string]$p.location)
        [void]$item.SubItems.Add([string]$p.lockedBy)
        [void]$item.SubItems.Add([string]$p.since)
        switch ($p.status) {
            'available'    { $item.BackColor = [System.Drawing.Color]::FromArgb(224,255,224) }
            'checked-out'  { $item.BackColor = [System.Drawing.Color]::FromArgb(255,236,200) }
            'in-transit'   { $item.BackColor = [System.Drawing.Color]::FromArgb(255,224,224) }
            'unregistered' { $item.BackColor = [System.Drawing.Color]::FromArgb(230,230,230) }
        }
        [void]$script:List.Items.Add($item)
    }
    $script:List.EndUpdate()
}

function Set-ButtonsEnabled {
    param([bool]$On)
    foreach ($b in $script:ActionButtons) { $b.Enabled = $On }
}

# Runs an operation with UI guard: wait cursor, disable buttons, log, refresh.
function Invoke-Guarded {
    param([string]$What, [scriptblock]$Action)
    try {
        $script:Form.Cursor = [System.Windows.Forms.Cursors]::WaitCursor
        Set-ButtonsEnabled $false
        Write-Log "$What ..."
        & $Action
        Write-Log "$What : OK"
    } catch {
        Write-Log "ERROR: $($_.Exception.Message)"
        [void][System.Windows.Forms.MessageBox]::Show($_.Exception.Message, 'Error',
            [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
    } finally {
        Set-ButtonsEnabled $true
        $script:Form.Cursor = [System.Windows.Forms.Cursors]::Default
        Update-List
    }
}

function New-Button {
    param([string]$Text, [int]$X, [int]$Y, [scriptblock]$OnClick, [int]$Width = 120)
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $Text
    $b.Location = New-Object System.Drawing.Point($X, $Y)
    $b.Size = New-Object System.Drawing.Size($Width, 30)
    $b.Anchor = 'Top,Left'
    $b.Add_Click($OnClick)
    $b
}

$script:Form = New-Object System.Windows.Forms.Form
$script:Form.Text = "Video Project Check-In / Check-Out  —  $script:Machine  ($script:User)"
$script:Form.Size = New-Object System.Drawing.Size(940, 640)
$script:Form.StartPosition = 'CenterScreen'
$script:Form.MinimumSize = New-Object System.Drawing.Size(720, 480)

$header = New-Object System.Windows.Forms.Label
$header.Text = "Local: $($script:Config.LocalRoot)     SAN: $($script:Config.SanParkRoot)"
$header.AutoSize = $true
$header.Location = New-Object System.Drawing.Point(12, 10)
$script:Form.Controls.Add($header)

$script:List = New-Object System.Windows.Forms.ListView
$script:List.View = 'Details'
$script:List.FullRowSelect = $true
$script:List.GridLines = $true
$script:List.MultiSelect = $false
$script:List.HideSelection = $false
$script:List.Location = New-Object System.Drawing.Point(12, 36)
$script:List.Size = New-Object System.Drawing.Size(900, 300)
$script:List.Anchor = 'Top,Left,Right,Bottom'
[void]$script:List.Columns.Add('Project', 300)
[void]$script:List.Columns.Add('Status', 110)
[void]$script:List.Columns.Add('Location', 110)
[void]$script:List.Columns.Add('Locked By', 130)
[void]$script:List.Columns.Add('Since', 140)
$script:Form.Controls.Add($script:List)

$btnY = 348
$btnRefresh = New-Button 'Refresh'        12  $btnY { Update-List; Write-Log 'Refreshed.' }
$btnOut     = New-Button 'Check Out'      142 $btnY {
    $p = Get-SelectedProject; if (-not $p) { Write-Log 'Select a project first.'; return }
    Invoke-Guarded "Check out '$p'" { Invoke-Checkout $p }
}
$btnIn      = New-Button 'Check In'       272 $btnY {
    $p = Get-SelectedProject; if (-not $p) { Write-Log 'Select a project first.'; return }
    Invoke-Guarded "Check in '$p'" { Invoke-Checkin $p }
}
$btnReg     = New-Button 'Register...'    402 $btnY {
    $p = Get-SelectedProject; if (-not $p) { Write-Log 'Select an unregistered project first.'; return }
    $ans = [System.Windows.Forms.MessageBox]::Show(
        "Register '$p'.`n`nYes = it currently lives on the SAN (available).`nNo = it currently lives on THIS PWS (checked-out to you).",
        'Register project', [System.Windows.Forms.MessageBoxButtons]::YesNoCancel, [System.Windows.Forms.MessageBoxIcon]::Question)
    if ($ans -eq 'Cancel') { return }
    $loc = if ($ans -eq 'Yes') { 'SAN' } else { $script:Machine }
    Invoke-Guarded "Register '$p'" { Register-Project -Project $p -Location $loc }
}
$btnForce   = New-Button 'Force Release'  532 $btnY {
    $p = Get-SelectedProject; if (-not $p) { Write-Log 'Select a project first.'; return }
    $ans = [System.Windows.Forms.MessageBox]::Show(
        "Force-release the lock on '$p'?`n`nThis ONLY clears the lock state. It does NOT move media.`nConfirm where the media actually is afterward.",
        'Force Release', [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Warning)
    if ($ans -ne 'Yes') { return }
    Invoke-Guarded "Force-release '$p'" { Invoke-ForceRelease $p }
}
$btnOpen    = New-Button 'Open Folder'    662 $btnY {
    $p = Get-SelectedProject; if (-not $p) { return }
    $s = Read-State $p
    $path = if ($s -and $s.location -eq $script:Machine) { Join-Path $script:Config.LocalRoot $p } else { Join-Path $script:Config.SanParkRoot $p }
    if (Test-Path $path) { Start-Process explorer.exe $path } else { Write-Log "Folder not found: $path" }
}
$script:ActionButtons = @($btnRefresh, $btnOut, $btnIn, $btnReg, $btnForce, $btnOpen)
$script:Form.Controls.AddRange([System.Windows.Forms.Control[]]$script:ActionButtons)

$script:LogBox = New-Object System.Windows.Forms.TextBox
$script:LogBox.Multiline = $true
$script:LogBox.ReadOnly = $true
$script:LogBox.ScrollBars = 'Vertical'
$script:LogBox.Location = New-Object System.Drawing.Point(12, 390)
$script:LogBox.Size = New-Object System.Drawing.Size(900, 200)
$script:LogBox.Anchor = 'Left,Right,Bottom'
$script:LogBox.Font = New-Object System.Drawing.Font('Consolas', 9)
$script:Form.Controls.Add($script:LogBox)

Update-List
Write-Log "Ready. $($script:List.Items.Count) project(s). You are $script:User on $script:Machine."
[void]$script:Form.ShowDialog()
