@echo off
REM Double-click launcher for the Check-In / Check-Out tool.
REM -STA is required for WinForms; -ExecutionPolicy Bypass avoids code-signing
REM requirements on an air-gapped machine.
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0CheckInOut.ps1"
