@{
    # ---------------------------------------------------------------------------
    # Local working root on THIS workstation.
    # MUST be identical on every PWS (e.g. E:\Projects on all of them) so that
    # checked-out media always lands at the exact path Resolve already stored,
    # and no relinking is ever required.
    # ---------------------------------------------------------------------------
    LocalRoot    = 'E:\Projects'

    # ---------------------------------------------------------------------------
    # SAN (NetApp) roots.
    #   SanParkRoot  = where media for idle / parked projects lives.
    #   SanStateRoot = per-project lock/state JSON files + the audit log.
    #                  (Put it on the SAN so every PWS reads the same state.)
    # ---------------------------------------------------------------------------
    SanParkRoot  = '\\NETAPP\Video\Projects'
    SanStateRoot = '\\NETAPP\Video\Projects\_state'

    # ---------------------------------------------------------------------------
    # Robocopy tuning.
    # ---------------------------------------------------------------------------
    RobocopyThreads = 16   # /MT
    RobocopyRetries = 2    # /R  (retries on failed copies)
    RobocopyWait    = 5    # /W  (seconds between retries)

    # ---------------------------------------------------------------------------
    # Usernames (env:USERNAME) allowed to Force-Release a stale lock.
    # ---------------------------------------------------------------------------
    Admins = @('administrator')
}
