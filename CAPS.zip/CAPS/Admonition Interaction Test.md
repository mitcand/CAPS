---
cssclasses:
  - product
test_text: test text typed in native callout box shows in the test a box as well, checked boxes did not carry across to the test a but they check fine as well
time_pre_min: 30
time_prod_min: 40
time_post_min: 30
---

# Admonition interaction test

**Goal:** find out whether Meta Bind inputs, js-engine blocks, and checkboxes
render *inside* an Admonition code-block (`ad-note`) the way they do inside a
native callout. If they do, we can move the prose sections of the Product
template to the cleaner `ad-` fenced syntax.

**How to run this test:**
1. Install Admonition: Settings → Community plugins → Browse → search
   **"Admonition"** (by *ebullient*) → Install → **Enable**.
2. Open this note in **Reading view**, then also check **Live Preview**.
3. Compare the three sections below. The CONTROL should fully work (it's the
   `>` callout syntax already used in your template). The two TEST sections tell
   us whether Admonition renders the same interactive content.

> [!warning] Nesting gotcha (already applied below)
> A code block can't sit inside another code block of the **same** fence length.
> So each `ad-` block below opens with **four** backticks (` ```` `) so the
> **three**-backtick `meta-bind` / `js-engine` blocks inside it stay nested.
> Note this: even if the test passes, `ad-` sections that contain other code
> blocks need 4 backticks — slightly less clean than plain `ad-` prose.

---

## CONTROL — native callout (known to work)

> [!note] Native callout
> Meta Bind text area (type in it; it should save to the `test_text` property):
> ```meta-bind
> INPUT[textArea:test_text]
> ```
> js-engine output:
> ```js-engine
> return engine.markdown.create("**js-engine rendered inside a native callout** ✅");
> ```
> Checkboxes:
> - [x] box one
> - [x] box two

---

## TEST A — Admonition `ad-note` with interactive content

````ad-note
title: Admonition code-block
Meta Bind text area (same property — should mirror the control if it works):
```meta-bind
INPUT[textArea:test_text]
```
js-engine output:
```js-engine
return engine.markdown.create("**js-engine rendered inside ad-note** ✅");
```
Checkboxes:
- [x] box one
- [x] box two
````

---

## TEST B — Admonition `ad-tip` with plain markdown only

````ad-tip
title: Plain markdown test
This tests the *simple* case — no nested plugins, just prose.

- [x] a checkbox
- a bullet with **bold**, *italic*, and an [[internal link]]
- a bit of `inline code`
````

---

## What the result means

- **Test A renders the same as the CONTROL** → Admonition handles your
  interactive blocks. Move the prose sections (Notes / Sourcing / Coordination /
  Feedback / Journal) to `ad-` syntax; keep the Work/phase block as-is.
- **Test A shows raw code / empty boxes** but **Test B looks fine** → Admonition
  is great for *static* prose sections but can't host Meta Bind / js-engine.
  Then: use `ad-` for the plain text sections, leave interactive parts as
  callouts.
- **Even Test B looks wrong** → Admonition isn't rendering at all; check it's
  enabled and you're in Reading/Live-Preview (not source mode).

Report back what you see in each section and I'll tell you exactly which
sections of the template to convert.

---

## TEST C — the Work/tasks block, rebuilt in nested Admonition syntax

This is a faithful recreation of your template's `Work` block using Admonition's
custom `ad-subtasks` / `ad-phase` types, so you can judge the **authoring syntax**
and the **rendered look** side by side with the real thing.

> [!important] Import the types first
> This block uses `ad-subtasks` and `ad-phase`, which come from
> `admonition-types.json` (vault root). Settings → Admonition → **Import** it
> first, or these boxes render as unknown/broken.

**Watch for four things when you view this:**
1. **Backtick escalation** — in *source/edit* mode: the outer `Work` box needs
   **5** backticks (` ````` `), each phase box needs **4** (` ```` `), and the
   `js-engine` blocks inside stay at **3**. Compare that to `>`/`>>`.
2. **← THE DECIDING TEST: do the three phases sit in columns?** The column layout
   comes from `production.css`, which targets *native callout* markup
   (`.callout[data-callout="phase"]`).
   - **Columns appear** → Admonition emits native-callout markup, your existing
     CSS already matches, and the Work block could move to Admonition *for free*.
   - **They stack vertically** → Admonition emits its own markup; confirm by
     right-clicking a phase → **Inspect**, then we rewrite the CSS selectors to
     match. Note what class/attribute the wrapper `<div>` has.
3. **Do the per-phase counts (js-engine) show numbers?** I rewrote the counter to
   key off Admonition's `title:` lines instead of `[!phase]`. If your real
   template moved to Admonition, that js-engine rewrite would be *mandatory* —
   the original counters look for `[!phase]` and would read 0/0.
4. **Do the inline `VIEW[...]m` and the `-10/+10` buttons render?** Test A only
   proved a *block* `meta-bind` works inside Admonition; these are *inline*
   meta-bind fields, a different renderer. If they show as literal code, that's a
   gap.

`````ad-subtasks
title: Work
```js-engine
// Overall readout: every checkbox that sits under a phase title in THIS block.
const file = context.file;
const A = engine.app || globalThis.app;
const build = async () => {
  const lines = (await A.vault.cachedRead(file)).split("\n");
  const phases = ["Preproduction", "Production", "Postproduction"];
  let done = 0, total = 0, seen = false;
  for (const line of lines) {
    const m = line.match(/^\s*title:\s*(.+?)\s*$/);
    if (m) { seen = phases.includes(m[1]); continue; }
    if (/^\s*`{4,}/.test(line)) { seen = false; continue; }   // a phase/box fence closes the region
    if (seen && /^\s*- \[.\]/.test(line)) { total++; if (/\[[xX]\]/.test(line)) done++; }
  }
  const pct = total ? Math.round(done / total * 100) : 0;
  const fm = A.metadataCache.getFileCache(file)?.frontmatter || {};
  const mins = (Number(fm.time_pre_min) || 0) + (Number(fm.time_prod_min) || 0) + (Number(fm.time_post_min) || 0);
  const hm = (mins >= 60 ? Math.floor(mins / 60) + "h " : "") + (mins % 60) + "m";
  return engine.markdown.create("**" + pct + "%** · " + done + "/" + total + " done · " + hm);
};
const comp = engine.reactive(build);
component.registerEvent(A.metadataCache.on("changed", (f) => { if (f && f.path === file.path) comp.refresh(); }));
return comp;
```

````ad-phase
title: Preproduction
```js-engine
const file = context.file;
const A = engine.app || globalThis.app;
const phase = "Preproduction";
const build = async () => {
  const lines = (await A.vault.cachedRead(file)).split("\n");
  let done = 0, total = 0, seen = false;
  for (const line of lines) {
    const m = line.match(/^\s*title:\s*(.+?)\s*$/);
    if (m) { seen = (m[1] === phase); continue; }
    if (/^\s*`{4,}/.test(line)) { seen = false; continue; }
    if (seen && /^\s*- \[.\]/.test(line)) { total++; if (/\[[xX]\]/.test(line)) done++; }
  }
  return engine.markdown.create("**" + done + "/" + total + "**");
};
const comp = engine.reactive(build);
component.registerEvent(A.metadataCache.on("changed", (f) => { if (f && f.path === file.path) comp.refresh(); }));
return comp;
```
`VIEW[{time_pre_min}]`m · `BUTTON[t-pre-sub]` `BUTTON[t-pre-add]`

- [x] Obsidian
- [x] Project
- [ ] Files
````

````ad-phase
title: Production
```js-engine
const file = context.file;
const A = engine.app || globalThis.app;
const phase = "Production";
const build = async () => {
  const lines = (await A.vault.cachedRead(file)).split("\n");
  let done = 0, total = 0, seen = false;
  for (const line of lines) {
    const m = line.match(/^\s*title:\s*(.+?)\s*$/);
    if (m) { seen = (m[1] === phase); continue; }
    if (/^\s*`{4,}/.test(line)) { seen = false; continue; }
    if (seen && /^\s*- \[.\]/.test(line)) { total++; if (/\[[xX]\]/.test(line)) done++; }
  }
  return engine.markdown.create("**" + done + "/" + total + "**");
};
const comp = engine.reactive(build);
component.registerEvent(A.metadataCache.on("changed", (f) => { if (f && f.path === file.path) comp.refresh(); }));
return comp;
```
`VIEW[{time_prod_min}]`m · `BUTTON[t-prod-sub]` `BUTTON[t-prod-add]`

- [ ] Cut
- [x] Stab
- [x] Color
- [x] Build
- [ ] Draft
````

````ad-phase
title: Postproduction
```js-engine
const file = context.file;
const A = engine.app || globalThis.app;
const phase = "Postproduction";
const build = async () => {
  const lines = (await A.vault.cachedRead(file)).split("\n");
  let done = 0, total = 0, seen = false;
  for (const line of lines) {
    const m = line.match(/^\s*title:\s*(.+?)\s*$/);
    if (m) { seen = (m[1] === phase); continue; }
    if (/^\s*`{4,}/.test(line)) { seen = false; continue; }
    if (seen && /^\s*- \[.\]/.test(line)) { total++; if (/\[[xX]\]/.test(line)) done++; }
  }
  return engine.markdown.create("**" + done + "/" + total + "**");
};
const comp = engine.reactive(build);
component.registerEvent(A.metadataCache.on("changed", (f) => { if (f && f.path === file.path) comp.refresh(); }));
return comp;
```
`VIEW[{time_post_min}]`m · `BUTTON[t-post-sub]` `BUTTON[t-post-add]`

- [x] Render
- [x] Review
- [ ] Publish
````
`````

<!-- Time buttons (hidden), same as the real template. -->
```meta-bind-button
label: "-10"
hidden: true
id: "t-pre-sub"
style: default
action:
  type: updateMetadata
  bindTarget: time_pre_min
  evaluate: true
  value: Math.max(x - 10, 0)
```
```meta-bind-button
label: "+10"
hidden: true
id: "t-pre-add"
style: default
action:
  type: updateMetadata
  bindTarget: time_pre_min
  evaluate: true
  value: x + 10
```
```meta-bind-button
label: "-10"
hidden: true
id: "t-prod-sub"
style: default
action:
  type: updateMetadata
  bindTarget: time_prod_min
  evaluate: true
  value: Math.max(x - 10, 0)
```
```meta-bind-button
label: "+10"
hidden: true
id: "t-prod-add"
style: default
action:
  type: updateMetadata
  bindTarget: time_prod_min
  evaluate: true
  value: x + 10
```
```meta-bind-button
label: "-10"
hidden: true
id: "t-post-sub"
style: default
action:
  type: updateMetadata
  bindTarget: time_post_min
  evaluate: true
  value: Math.max(x - 10, 0)
```
```meta-bind-button
label: "+10"
hidden: true
id: "t-post-add"
style: default
action:
  type: updateMetadata
  bindTarget: time_post_min
  evaluate: true
  value: x + 10
```
