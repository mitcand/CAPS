---
tracker: reference
tags: [setup, todo]
title: Product Codes — change list
created: 2026-06-30
---

# Product Codes — where to change the placeholders

Product IDs follow the format **`<program:1><type:2><year:2><seq:3>`** — e.g. `AVD26001`
= program **A**, type **video (VD)**, year **2026**, sequence **001**. The sequence is global
across all programs/types and resets each calendar year; Templater auto-generates it.

The codes below currently ship as **placeholders**. Change them here when you know your real ones.

## 1. The only place that actually matters (functional)

**`_Templates/New Product.md`** — the config block at the top of the file:

```js
const PROGRAMS   = ["A", "B", "C"];                                   // ← your 1-char program codes
const TYPE_CODES = { video: "VD", graphic: "GR", map: "MP", report: "RP" };  // ← product_type → 2-char code
```

- **`PROGRAMS`** — replace `"A", "B", "C"` with your actual 1-character program codes. This is the
  list the "Program code" picker shows when you create a product. Add or remove as many as you like.
- **`TYPE_CODES`** — the map from each `product_type` to its 2-letter ID code. The **keys** (`video`,
  `graphic`, `map`, `report`) must exactly match the product-type options; the **values** (`VD`, `GR`,
  `MP`, `RP`) are what land in the ID. Change a value to re-letter a type; add a key to add a new type.

> ⚠️ Changing these does **not** retro-rename existing notes — it only affects products created afterward.
> IDs already assigned stay as they are (and should — they're your audit trail).

## 2. Cosmetic only — example IDs in the design docs

These use `A`/`B`/`C` and `AVD26001`-style IDs purely as **illustrations**. They don't affect behavior;
update them only if you want the docs to show your real codes:

- `Production/Production.md` — the New Product button tooltip mentions `AVD26001…`.
- `Obsidian PM Vault Plan.md` — example frontmatter / folder tree.
- `PM System Design Plan.md`, `_Setup — Variant A.md`, `Redmine Build Log.md` — prose examples.

## Quick checklist when you get the real codes
- [ ] Update `PROGRAMS` in `_Templates/New Product.md`
- [ ] Update `TYPE_CODES` values in `_Templates/New Product.md` (if type letters differ)
- [ ] (Optional) refresh the example IDs in the docs listed above
